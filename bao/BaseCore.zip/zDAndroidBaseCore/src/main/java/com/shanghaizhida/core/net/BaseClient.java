package com.shanghaizhida.core.net;

import com.shanghaizhida.ZDLogger;
import com.shanghaizhida.core.parser.NetInfoParser;
import com.shanghaizhida.core.parser.RecvStateObject;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.SocketTimeoutException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public abstract class BaseClient implements Runnable {

	private ZDLogger errorLogger = null;
	private SocketAddress socketAddr = null;

	private Thread dataFeedThread = null;

	private Thread dateSendTherad = null;

	private BlockingQueue<byte[]> sendQueue = null;

	public boolean stopFlag = true;

	public Socket receiveSocket = null;
	public boolean isSocketBroken = true;
	public RecvStateObject networkState = null;
	private OutputStream outputStream = null;

	public byte[] heartbeatMsg = null;
	public long previousTimeMillis = 0;

	public BaseClient(String serverIP, String strPort) {
		socketAddr = new InetSocketAddress(serverIP, Integer.parseInt(strPort));
		networkState = new RecvStateObject();
		networkState.parser = new NetInfoParser();
		sendQueue = new LinkedBlockingQueue<byte[]>();
	}

	public void setLogger(ZDLogger errorLogger) {
		this.errorLogger = errorLogger;
	}

	public void start() throws Exception {
		if (networkState.parser == null)
			throw new Exception(
					"BaseClient#networkState.networkParser is not initialized!");

		// assemble heartbeatMsg
		try {
			heartbeatMsg = "{(len=18)TEST0001@@@@@@@@&9}".getBytes("US-ASCII");
		} catch (Exception ex) {
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----1-----" + ex.getMessage());
		}

		stopFlag = false;
		dataFeedThread = new Thread(this);
		dataFeedThread.start();

		dateSendTherad = new Thread() {
			@Override
			public void run() {
				doSendData();
			}
		};
		dateSendTherad.start();
	}

	public void stop() {
		stopFlag = true;
		dateSendTherad.interrupt();
	}

	public void sendData(byte[] data) {
		synchronized (networkState) {
			try {
				if (data != null)
					sendQueue.put(data);
			} catch (InterruptedException ie) {
				if (errorLogger != null)
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----sendData InterruptedException-----" + ie.getStackTrace().toString());
			}
/*
			try {

				// if (data != null && outputStream != null) {
				// outputStream.write(data);
				// }
				// Modify by xiang at 20160511
				// 去掉了 <outputStream != null> 如果outputStream为空说明连接有问题
				// 就让他进Exception,重建连接
				if (data != null) {
					outputStream.write(data);
				}
			} catch (IOException ioe) {
				isSocketBroken = true;
				onConnectStateChange(ConnectionStateListener.CONNECTION_LOST,
						"connection broken!");
				if (errorLogger != null) {
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----2-----" + ioe.toString());
				}
			}
*/
		}
	}

	@Override
	public void run() {
		try {
			doRecvData();
		} catch (Exception ex) {
			// write log
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----3-----" + ex.toString());
		}
	}

	private void doSendData() {
		while (!stopFlag) {
			try {
				byte[] data = sendQueue.take();
				if (data != null) {
					outputStream.write(data);
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
				System.out.println("发送线程停止");
				break;
			} catch (IOException e) {
				isSocketBroken = true;
				onConnectStateChange(ConnectionStateListener.CONNECTION_LOST,
						"connection broken!");
				if (errorLogger != null) {
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----2-----" + e.toString());
				}
			} catch (NullPointerException e) {
				System.out.println("doSendData NullPointerException");
				isSocketBroken = true;
				onConnectStateChange(ConnectionStateListener.CONNECTION_LOST,
						"connection broken!");
			}
		}
	}

	public void doRecvData() {
		while (!stopFlag) {
			try {
				if (isSocketBroken) {
					connectHost();
					if (stopFlag)
						break;

					if (isSocketBroken) {
						try {
							Thread.sleep(3000);
						} catch (InterruptedException ie) {
						}
						continue;
					}
				} else {
					long nowTick = System.currentTimeMillis();
					if (nowTick - previousTimeMillis > 30000) {
						// send heartbeat message
						sendData(heartbeatMsg);
						// System.out.println("发送心跳");
						previousTimeMillis = nowTick;
					}
				}

				int readLen = 0;
				byte[] netMsg = networkState.parser.getRawMsg();

				if (netMsg == null) {

					try {
						readLen = networkState.inputStream
								.read(networkState.buffer);

						if (readLen > 0)
							networkState.parser.AddToParser(
									networkState.buffer, 0, readLen);
					} catch (Exception ste) {
						// ste.printStackTrace();
					}

				} else {
					onMsgReady(netMsg);
				}
			} catch (Exception ioe) {
				if (errorLogger != null)
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----4-----" + ioe.toString());

				// Reconnect
				isSocketBroken = true;
				onConnectStateChange(ConnectionStateListener.CONNECTION_LOST,
						"connection broken!");
			}
		}

		// Exit and release socket resource
		try {
			if (receiveSocket != null) {
				receiveSocket.close();
				receiveSocket = null;
			}
		} catch (IOException ioe) {
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----5-----" + ioe.toString());
		}
	}

	public void connectHost() {

		if (receiveSocket != null) {
			try{
				receiveSocket.shutdownInput();
				receiveSocket.shutdownOutput();
			}catch(Exception ex){
				if (errorLogger != null)
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----6-----" + ex.toString());
			}

			try {
				receiveSocket.close();
				receiveSocket = null;
			} catch (Exception ex) {
				if (errorLogger != null)
					errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----7-----" + ex.toString());
			}
		}

		try {
			receiveSocket = new Socket();

			receiveSocket.setTcpNoDelay(true);
			receiveSocket.setSoLinger(true, 3000);
			receiveSocket.setSoTimeout(10000);

			receiveSocket.connect(socketAddr, 10000);
			networkState.inputStream = receiveSocket.getInputStream();
			outputStream = receiveSocket.getOutputStream();
			isSocketBroken = false;

			onConnectStateChange(ConnectionStateListener.RECONNECTED,
					"connection reconnected!");
		} catch (SocketTimeoutException st) {

			if (stopFlag)
				return;

			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----8-----" + st.toString());

			isSocketBroken = true;

			System.out.println("SocketTimeoutException............");

			onConnectStateChange(ConnectionStateListener.SCOKET_CONNECTIONFAIL,
					"connection fail!");
		} catch (SocketException se) {
			// write log
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----9-----" + se.toString());

			isSocketBroken = true;

			System.out.println("SocketException............");

			onConnectStateChange(ConnectionStateListener.SCOKET_CONNECTIONFAIL,
					"connection fail!");
		} catch (IOException ioe) {
			// write log
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "BaseClient-----10-----" + ioe.toString());

			ioe.printStackTrace();

			isSocketBroken = true;

			System.out.println("IOException............");

			onConnectStateChange(ConnectionStateListener.SCOKET_CONNECTIONFAIL,
					"connection fail!");
		}

	}

	public abstract void onMsgReady(byte[] rawMsg);

	public abstract void onConnectStateChange(int code, String text);
}
