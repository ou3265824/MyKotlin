package com.shanghaizhida.core.net;

import java.io.IOException;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

import com.shanghaizhida.CommonFunction;
import com.shanghaizhida.ZDLogger;
import com.shanghaizhida.core.parser.NetInfoDecomParser;

/**
 * 绘制图形的数据返回
 * 
 * @author xiang <br>
 *         2015年8月5日 上午10:34:26
 * 
 */
public class ChartsClient extends BaseClient {

	private ConnectionStateListener connectionStateListener = null;
	public BlockingQueue<byte[]> dataQueue = null;
	private ZDLogger errorLogger = null;

	private NetInfoDecomParser decompress;

	public ChartsClient(String hostIP, String hostPort, ZDLogger errorLogger) {
		super(hostIP, hostPort);
		super.setLogger(errorLogger);

		dataQueue = new LinkedBlockingQueue<byte[]>();
		this.errorLogger = errorLogger;

		decompress = new NetInfoDecomParser();
	}

	@Override
	public void onMsgReady(byte[] rawMsg) {
		try {
			dataQueue.put(rawMsg);

		} catch (InterruptedException ie) {
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "ChartsClient-----1-----" + ie.getStackTrace().toString());
		}
	}

	@Override
	public void doRecvData() {

		while (!stopFlag) {
			try {
				if (isSocketBroken) {
					connectHost();
					if (stopFlag)
						break;

					if (isSocketBroken) {
						try {
							Thread.sleep(3000);
						} catch (InterruptedException ie) {
						}
						continue;
					}
				} else {
					long nowTick = System.currentTimeMillis();
					if (nowTick - previousTimeMillis > 40000) {
						// send heartbeat message
						sendData(heartbeatMsg);
						// System.out.println("发送心跳");
						previousTimeMillis = nowTick;
					}
				}

				int readLen = -1;

				try {
					byte[] buffer = decompress.getPackgeInfo(readLen);

					if (buffer == null) {
						readLen = networkState.inputStream
								.read(decompress.buffertemp);
						if (readLen > 0)
							decompress.addToParser(readLen);
					} else {
						// System.out.println(new String(buffer));

						onMsgReady(buffer);
					}

				} catch (Exception ste) {
					// ste.printStackTrace();
				}
			} catch (Exception ioe) {
				if (errorLogger != null)
					errorLogger.log(ZDLogger.LVL_ERROR, "ChartsClient-----4-----" + ioe.toString());

				// Reconnect
				isSocketBroken = true;
				onConnectStateChange(ConnectionStateListener.CONNECTION_LOST,
						"connection broken!");
			}
		}

		// Exit and release socket resource
		try {
			if (receiveSocket != null) {
				receiveSocket.close();
				receiveSocket = null;
			}
		} catch (IOException ioe) {
			if (errorLogger != null)
				errorLogger.log(ZDLogger.LVL_ERROR, "ChartsClient-----5-----" + ioe.toString());
		}
	}

	@Override
	public void onConnectStateChange(int code, String text) {
		if (connectionStateListener != null)
			connectionStateListener.onConnectStateChange(code, text);
	}

	public void setConnectionStateListener(ConnectionStateListener listener) {
		this.connectionStateListener = listener;
	}

	/**
	 * 发送Ascii编码的消息
	 * 
	 * @param str
	 *            消息内容
	 */
	public void sendAsciiMsg(String str) {
		byte[] reqBytes = CommonFunction.asciiStrToNetBytes(str);
		sendData(reqBytes);
	}

	/**
	 * 发送UTF-8编码的消息
	 * 
	 * @param str
	 *            消息内容
	 */
	public void sendUTF8Msg(String str) {
		byte[] reqBytes = CommonFunction.utf8StrToNetBytes(str);
		sendData(reqBytes);
	}

	/**
	 * 发送消息,不对编码进行处理
	 * 
	 * @param byteArrMsg
	 *            byte消息内容
	 */
	public void sendMsg(byte[] byteArrMsg) {
		sendData(byteArrMsg);
	}
}
