package com.shanghaizhida;

public class SimpleLogger implements ZDLogger {

	@Override
	public void log(int logLvl, String content) {
		System.out.println("[" + logLvl + "] - " + content);
	}

	@Override
	public void log(int logLvl, String classN, String method, String content) {
		System.out.println("[" + logLvl + "] - " + classN + "#" + method
				+ "() " + content);
	}

	@Override
	public void setLogLevel(int logLvl) {

	}

	@Override
	public void Dispose() {

	}

}
