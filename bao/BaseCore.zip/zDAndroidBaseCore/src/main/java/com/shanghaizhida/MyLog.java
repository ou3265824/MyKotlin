package com.shanghaizhida;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

/**
 * 带日志文件输入的，又可控开关的日志调试
 * 
 */
public class MyLog implements ZDLogger {
	private Boolean MYLOG_WRITE_TO_FILE = false; // 日志写入文件开关
	private int MYLOG_LVL = ZDLogger.LVL_DEBUG; // 输入日志级别
	private String MYLOG_PATH_SDCARD_DIR = "/sdcard/NewMtrader/writeFactoryLog"; // 日志文件在sdcard中的路径
	private int SDCARD_LOG_FILE_SAVE_DAYS = 5; // sd卡中日志文件的最多保存天数
	private String MYLOGFILEName = ".txt"; // 本类输出的日志文件名称
	private SimpleDateFormat myLogSdf = new SimpleDateFormat(
			"yyyy-MM-dd HH:mm:ss.SSS"); // 日期的输出格式
	private SimpleDateFormat logfile = new SimpleDateFormat("yyyy-MM-dd"); // 日志文件格式
	private Date nowtime = new Date();
	private String needWriteMessage;

	public MyLog() {
		File file = new File(MYLOG_PATH_SDCARD_DIR);
		if (!file.exists()) {
			try {
				file.mkdir();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 日志内容
	 * 
	 */
	@Override
	public void log(int logLvl, String content) {
		// TODO Auto-generated method stub
		needWriteMessage = "时间：" + myLogSdf.format(new Date()) + "\r\n类型："
				+ logLvl + "\r\n内容：" + content + "\r\n\r\n";
		writeLogtoFile(logLvl, needWriteMessage, nowtime);
		// System.out.println(needWriteMessage);

	}

	@Override
	public void log(int logLvl, String classN, String method, String content) {
		// TODO Auto-generated method stub
		needWriteMessage = "时间：" + myLogSdf.format(new Date()) + "\r\n类型："
				+ logLvl + "\r\n类名：" + classN + "\r\n方法：" + method + "\r\n内容："
				+ content + "\r\n\r\n";
		writeLogtoFile(logLvl, needWriteMessage, nowtime);
		// System.out.println(needWriteMessage);
	}

	/**
	 * 设置日志输出等级
	 * 
	 **/
	@Override
	public void setLogLevel(int logLvl) {
		// TODO Auto-generated method stub
		this.MYLOG_LVL = logLvl;
	}

	@Override
	public void Dispose() {
		// TODO Auto-generated method stub
	}

	/* *
	 * 新建或打开日志文件并写入日志
	 * 
	 * @return
	 */
	private void writeLogtoFile(int logLvl, String text, Date nowtime) {
		if (logLvl <= this.MYLOG_LVL) {
			if (MYLOG_WRITE_TO_FILE) {

				String needWriteFiel = logfile.format(nowtime);
				File file = new File(MYLOG_PATH_SDCARD_DIR, needWriteFiel
						+ MYLOGFILEName);
				try {
					FileWriter filerWriter = new FileWriter(file, true);// 后面这个参数代表是不是要接上文件中原来的数据，不进行覆盖
					BufferedWriter bufWriter = new BufferedWriter(filerWriter);
					bufWriter.write(text);
					bufWriter.newLine();
					bufWriter.close();
					filerWriter.close();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * 删除指定的日志文件
	 * */
	public void delFile() {
		String needDelFiel = logfile.format(getDateBefore());
		File file = new File(MYLOG_PATH_SDCARD_DIR, needDelFiel + MYLOGFILEName);
		if (file.exists()) {
			file.delete();
		}
	}

	/**
	 * 得到现在时间前的几天日期，用来得到需要删除的日志文件名
	 * */
	private Date getDateBefore() {
		Date nowtime = new Date();
		Calendar now = Calendar.getInstance();
		now.setTime(nowtime);
		now.set(Calendar.DATE, now.get(Calendar.DATE)
				- SDCARD_LOG_FILE_SAVE_DAYS);
		return now.getTime();
	}

	public void setMYLOG_WRITE_TO_FILE(Boolean mYLOG_WRITE_TO_FILE) {
		this.MYLOG_WRITE_TO_FILE = mYLOG_WRITE_TO_FILE;
	}

}
