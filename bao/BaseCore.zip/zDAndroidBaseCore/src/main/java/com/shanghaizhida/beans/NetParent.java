package com.shanghaizhida.beans;

public interface NetParent {

	String MyToString();

	void MyReadString(String temp);

	String MyPropToString();

}
