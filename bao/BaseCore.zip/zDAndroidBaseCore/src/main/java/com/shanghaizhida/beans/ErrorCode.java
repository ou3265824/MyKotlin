package com.shanghaizhida.beans;

public class ErrorCode {

	/**
	 * 根据错误代码取得错误内容
	 * 
	 * @param errorCode
	 * @return
	 */

	public static String getErrorMsgByCode(String errorCode) {
		String msg = errorCode; //"";

		if (errorCode.equals(SUCCESS)) {
			msg = SUCCESS_MSG;
		} else if (errorCode.equals(ERR_COMMON_0001)) {
			msg = ERR_COMMON_0001_MSG;
		} else if (errorCode.equals(ERR_COMMON_0002)) {
			msg = ERR_COMMON_0002_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0001)) {
			msg = ERR_LOGIN_0001_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0002)) {
			msg = ERR_LOGIN_0002_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0003)) {
			msg = ERR_LOGIN_0003_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0004)) {
			msg = ERR_LOGIN_0004_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0005)) {
			msg = ERR_LOGIN_0005_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0006)) {
			msg = ERR_LOGIN_0006_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0007)) {
			msg = ERR_LOGIN_0007_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0008)) {
			msg = ERR_LOGIN_0008_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0009)) {
			msg = ERR_LOGIN_0009_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0010)) {
			msg = ERR_LOGIN_0010_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0011)) {
			msg = ERR_LOGIN_0011_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0012)) {
			msg = ERR_LOGIN_0012_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0013)) {
			msg = ERR_LOGIN_0013_MSG;
		} else if (errorCode.equals(ERR_ORDER_0000)) {
			msg = ERR_ORDER_0000_MSG;
		} else if (errorCode.equals(ERR_ORDER_0001)) {
			msg = ERR_ORDER_0001_MSG;
		} else if (errorCode.equals(ERR_ORDER_0002)) {
			msg = ERR_ORDER_0002_MSG;
		} else if (errorCode.equals(ERR_ORDER_0003)) {
			msg = ERR_ORDER_0003_MSG;
		} else if (errorCode.equals(ERR_ORDER_0004)) {
			msg = ERR_ORDER_0004_MSG;
		} else if (errorCode.equals(ERR_ORDER_0005)) {
			msg = ERR_ORDER_0005_MSG;
		} else if (errorCode.equals(ERR_ORDER_0006)) {
			msg = ERR_ORDER_0006_MSG;
		} else if (errorCode.equals(ERR_ORDER_0007)) {
			msg = ERR_ORDER_0007_MSG;
		} else if (errorCode.equals(ERR_ORDER_0008)) {
			msg = ERR_ORDER_0008_MSG;
		} else if (errorCode.equals(ERR_ORDER_0009)) {
			msg = ERR_ORDER_0009_MSG;
		} else if (errorCode.equals(ERR_ORDER_0010)) {
			msg = ERR_ORDER_0010_MSG;
		} else if (errorCode.equals(ERR_ORDER_0011)) {
			msg = ERR_ORDER_0011_MSG;
		} else if (errorCode.equals(ERR_ORDER_0012)) {
			msg = ERR_ORDER_0012_MSG;
		} else if (errorCode.equals(ERR_ORDER_0013)) {
			msg = ERR_ORDER_0013_MSG;
		} else if (errorCode.equals(ERR_ORDER_0014)) {
			msg = ERR_ORDER_0014_MSG;
		} else if (errorCode.equals(ERR_ORDER_0015)) {
			msg = ERR_ORDER_0015_MSG;
		} else if (errorCode.equals(ERR_ORDER_0016)) {
			msg = ERR_ORDER_0016_MSG;
		} else if (errorCode.equals(ERR_ORDER_0017)) {
			msg = ERR_ORDER_0017_MSG;
		} else if (errorCode.equals(ERR_ORDER_0018)) {
			msg = ERR_ORDER_0018_MSG;
		} else if (errorCode.equals(ERR_ORDER_0019)) {
			msg = ERR_ORDER_0019_MSG;
		} else if (errorCode.equals(ERR_ORDER_0020)) {
			msg = ERR_ORDER_0020_MSG;
		} else if (errorCode.equals(ERR_ORDER_0021)) {
			msg = ERR_ORDER_0021_MSG;
		} else if (errorCode.equals(ERR_ORDER_0022)) {
			msg = ERR_ORDER_0022_MSG;
		} else if (errorCode.equals(ERR_ORDER_0023)) {
			msg = ERR_ORDER_0023_MSG;
		} else if (errorCode.equals(ERR_ORDER_0024)) {
			msg = ERR_ORDER_0024_MSG;
		} else if (errorCode.equals(ERR_ORDER_0025)) {
			msg = ERR_ORDER_0025_MSG;
		} else if (errorCode.equals(ERR_ORDER_0026)) {
			msg = ERR_ORDER_0026_MSG;
		} else if (errorCode.equals(ERR_ORDER_0027)) {
			msg = ERR_ORDER_0027_MSG;
		} else if (errorCode.equals(ERR_ORDER_0028)) {
			msg = ERR_ORDER_0028_MSG;
		} else if (errorCode.equals(ERR_ORDER_0029)) {
			msg = ERR_ORDER_0029_MSG;
		} else if (errorCode.equals(ERR_ORDER_0030)) {
			msg = ERR_ORDER_0030_MSG;
		} else if (errorCode.equals(ERR_ORDER_0031)) {
			msg = ERR_ORDER_0031_MSG;
		} else if (errorCode.equals(ERR_ORDER_0032)) {
			msg = ERR_ORDER_0032_MSG;
		} else if (errorCode.equals(ERR_ORDER_0033)) {
			msg = ERR_ORDER_0033_MSG;
		} else if (errorCode.equals(ERR_ORDER_0034)) {
			msg = ERR_ORDER_0034_MSG;
		} else if (errorCode.equals(ERR_ORDER_0035)) {
			msg = ERR_ORDER_0035_MSG;
		} else if (errorCode.equals(ERR_ORDER_0036)) {
			msg = ERR_ORDER_0036_MSG;
		} else if (errorCode.equals(ERR_ORDER_0045)) {
			msg = ERR_ORDER_0045_MSG;
		} else if (errorCode.equals(ERR_ORDER_0046)) {
			msg = ERR_ORDER_0046_MSG;
		} else if (errorCode.equals(ERR_SERVER_0000)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0001)) {
			msg = ERR_SERVER_0001_MSG;
		} else if (errorCode.equals(ERR_SERVER_0002)) {
			msg = ERR_SERVER_0002_MSG;
		} else if (errorCode.equals(ERR_SERVER_0003)) {
			msg = ERR_SERVER_0003_MSG;
		} else if (errorCode.equals(ERR_SERVER_0004)) {
			msg = ERR_SERVER_0004_MSG;
		} else if (errorCode.equals(ERR_SERVER_0005)) {
			msg = ERR_SERVER_0005_MSG;
		} else if (errorCode.equals(ERR_SERVER_0006)) {
			msg = ERR_SERVER_0006_MSG;
		} else if (errorCode.equals(ERR_SERVER_0007)) {
			msg = ERR_SERVER_0007_MSG;
		} else if (errorCode.equals(ERR_SERVER_0008)) {
			msg = ERR_SERVER_0008_MSG;
		} else if (errorCode.equals(ERR_SERVER_0009)) {
			msg = ERR_SERVER_0009_MSG;
		} else if (errorCode.equals(ERR_SERVER_0010)) {
			msg = ERR_SERVER_0010_MSG;
		} else if (errorCode.equals(ERR_SERVER_0011)) {
			msg = ERR_SERVER_0011_MSG;
		} else if (errorCode.equals(ERR_SERVER_0012)) {
			msg = ERR_SERVER_0012_MSG;
		} else if (errorCode.equals(ERR_SERVER_0013)) {
			msg = ERR_SERVER_0013_MSG;
		} else if (errorCode.equals(ERR_SERVER_0014)) {
			msg = ERR_SERVER_0014_MSG;
		} else if (errorCode.equals(ERR_SERVER_0015)) {
			msg = ERR_SERVER_0015_MSG;
		} else if (errorCode.equals(ERR_SERVER_0016)) {
			msg = ERR_SERVER_0016_MSG;
		} else if (errorCode.equals(ERR_SERVER_0017)) {
			msg = ERR_SERVER_0017_MSG;
		} else if (errorCode.equals(ERR_SERVER_0018)) {
			msg = ERR_SERVER_0018_MSG;
		} else if (errorCode.equals(ERR_SERVER_0019)) {
			msg = ERR_SERVER_0019_MSG;
		} else if (errorCode.equals(ERR_SERVER_0020)) {
			msg = ERR_SERVER_0020_MSG;
		} else if (errorCode.equals(ERR_SERVER_0021)) {
			msg = ERR_SERVER_0021_MSG;
		} else if (errorCode.equals(ERR_SERVER_0022)) {
			msg = ERR_SERVER_0022_MSG;
		} else if (errorCode.equals(ERR_SERVER_0023)) {
			msg = ERR_SERVER_0023_MSG;
		} else if (errorCode.equals(ERR_SERVER_0024)) {
			msg = ERR_SERVER_0024_MSG;
		} else if (errorCode.equals(ERR_SERVER_0025)) {
			msg = ERR_SERVER_0025_MSG;
		} else if (errorCode.equals(ERR_GUITAI_0001)) {
			msg = ERR_GUITAI_0001_MSG;
		} else if (errorCode.equals(ERR_GUITAI_0002)) {
			msg = ERR_GUITAI_0002_MSG;
		} else if (errorCode.equals(ERR_INOUT_0003)) {
			msg = ERR_INOUT_0003_MSG;
		} else if (errorCode.equals(ERR_MODIFY_001)) {
			msg = ERR_MODIFY_001_MSG;
		} else if (errorCode.equals(ERR_MODIFY_002)) {
			msg = ERR_MODIFY_002_MSG;
		} else if (errorCode.equals(ERR_MODIFY_003)) {
			msg = ERR_MODIFY_003_MSG;
		}

		return msg;
	}

	/** 根据错误代码取得错误内容（客户端用） */

	public static String getErrorMsgByCodeForClient(String errorCode) {
		String msg = "";

		if (errorCode.equals(SUCCESS)) {
			msg = SUCCESS_MSG;
		} else if (errorCode.equals(ERR_COMMON_0001)) {
			msg = ERR_COMMON_0001_MSG;
		} else if (errorCode.equals(ERR_COMMON_0002)) {
			msg = ERR_COMMON_0002_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0001)) {
			msg = ERR_LOGIN_0001_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0002)) {
			msg = ERR_LOGIN_0002_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0003)) {
			msg = ERR_LOGIN_0003_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0004)) {
			msg = ERR_LOGIN_0004_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0005)) {
			msg = ERR_LOGIN_0005_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0006)) {
			msg = ERR_LOGIN_0006_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0007)) {
			msg = ERR_LOGIN_0007_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0008)) {
			msg = ERR_LOGIN_0008_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0009)) {
			msg = ERR_LOGIN_0009_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0010)) {
			msg = ERR_LOGIN_0010_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0011)) {
			msg = ERR_LOGIN_0011_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0012)) {
			msg = ERR_LOGIN_0012_MSG;
		} else if (errorCode.equals(ERR_LOGIN_0013)) {
			msg = ERR_LOGIN_0013_MSG;
		} else if (errorCode.equals(ERR_ORDER_0000)) {
			msg = ERR_ORDER_0000_MSG;
		} else if (errorCode.equals(ERR_ORDER_0001)) {
			msg = ERR_ORDER_0001_MSG;
		} else if (errorCode.equals(ERR_ORDER_0002)) {
			msg = ERR_ORDER_0002_MSG;
		} else if (errorCode.equals(ERR_ORDER_0003)) {
			msg = ERR_ORDER_0003_MSG;
		} else if (errorCode.equals(ERR_ORDER_0004)) {
			msg = ERR_ORDER_0004_MSG;
		} else if (errorCode.equals(ERR_ORDER_0005)) {
			msg = ERR_ORDER_0005_MSG;
		} else if (errorCode.equals(ERR_ORDER_0006)) {
			msg = ERR_ORDER_0006_MSG;
		} else if (errorCode.equals(ERR_ORDER_0007)) {
			msg = ERR_ORDER_0007_MSG;
		} else if (errorCode.equals(ERR_ORDER_0008)) {
			msg = ERR_ORDER_0008_MSG;
		} else if (errorCode.equals(ERR_ORDER_0009)) {
			msg = ERR_ORDER_0009_MSG;
		} else if (errorCode.equals(ERR_ORDER_0010)) {
			msg = ERR_ORDER_0010_MSG;
		} else if (errorCode.equals(ERR_ORDER_0011)) {
			msg = ERR_ORDER_0011_MSG;
		} else if (errorCode.equals(ERR_ORDER_0012)) {
			msg = ERR_ORDER_0012_MSG;
		} else if (errorCode.equals(ERR_ORDER_0013)) {
			msg = ERR_ORDER_0013_MSG;
		} else if (errorCode.equals(ERR_ORDER_0014)) {
			msg = ERR_ORDER_0014_MSG;
		} else if (errorCode.equals(ERR_ORDER_0015)) {
			msg = ERR_ORDER_0015_MSG;
		} else if (errorCode.equals(ERR_ORDER_0016)) {
			msg = ERR_ORDER_0016_MSG;
		} else if (errorCode.equals(ERR_ORDER_0017)) {
			msg = ERR_ORDER_0017_MSG;
		} else if (errorCode.equals(ERR_ORDER_0018)) {
			msg = ERR_ORDER_0018_MSG;
		} else if (errorCode.equals(ERR_ORDER_0019)) {
			msg = ERR_ORDER_0019_MSG;
		} else if (errorCode.equals(ERR_ORDER_0020)) {
			msg = ERR_ORDER_0020_MSG;
		} else if (errorCode.equals(ERR_ORDER_0021)) {
			msg = ERR_ORDER_0021_MSG;
		} else if (errorCode.equals(ERR_ORDER_0022)) {
			msg = ERR_ORDER_0022_MSG;
		} else if (errorCode.equals(ERR_ORDER_0023)) {
			msg = ERR_ORDER_0023_MSG;
		} else if (errorCode.equals(ERR_ORDER_0024)) {
			msg = ERR_ORDER_0024_MSG;
		} else if (errorCode.equals(ERR_ORDER_0025)) {
			msg = ERR_ORDER_0025_MSG;
		} else if (errorCode.equals(ERR_ORDER_0026)) {
			msg = ERR_ORDER_0026_MSG;
		} else if (errorCode.equals(ERR_ORDER_0027)) {
			msg = ERR_ORDER_0027_MSG;
		} else if (errorCode.equals(ERR_ORDER_0028)) {
			msg = ERR_ORDER_0028_MSG;
		} else if (errorCode.equals(ERR_ORDER_0029)) {
			msg = ERR_ORDER_0029_MSG;
		} else if (errorCode.equals(ERR_ORDER_0030)) {
			msg = ERR_ORDER_0030_MSG;
		} else if (errorCode.equals(ERR_ORDER_0031)) {
			msg = ERR_ORDER_0031_MSG;
		} else if (errorCode.equals(ERR_ORDER_0032)) {
			msg = ERR_ORDER_0032_MSG;
		} else if (errorCode.equals(ERR_ORDER_0033)) {
			msg = ERR_ORDER_0033_MSG;
		} else if (errorCode.equals(ERR_ORDER_0034)) {
			msg = ERR_ORDER_0034_MSG;
		} else if (errorCode.equals(ERR_ORDER_0035)) {
			msg = ERR_ORDER_0035_MSG;
		} else if (errorCode.equals(ERR_ORDER_0036)) {
			msg = ERR_ORDER_0036_MSG;
		} else if (errorCode.equals(ERR_ORDER_0045)) {
			msg = ERR_ORDER_0045_MSG;
		} else if (errorCode.equals(ERR_ORDER_0046)) {
			msg = ERR_ORDER_0046_MSG;
		} else if (errorCode.equals(ERR_SERVER_0000)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0001)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0002)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0003)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0004)) {
			msg = ERR_SERVER_0004_MSG;
		} else if (errorCode.equals(ERR_SERVER_0005)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0006)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0007)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0008)) {
			msg = ERR_SERVER_0004_MSG;
		} else if (errorCode.equals(ERR_SERVER_0009)) {
			msg = ERR_SERVER_0000_MSG;
		} else if (errorCode.equals(ERR_SERVER_0010)) {
			msg = ERR_SERVER_0010_MSG;
		} else if (errorCode.equals(ERR_SERVER_0011)) {
			msg = ERR_SERVER_0011_MSG;
		} else if (errorCode.equals(ERR_SERVER_0012)) {
			msg = ERR_SERVER_0012_MSG;
		} else if (errorCode.equals(ERR_SERVER_0013)) {
			msg = ERR_SERVER_0013_MSG;
		} else if (errorCode.equals(ERR_SERVER_0014)) {
			msg = ERR_SERVER_0014_MSG;
		} else if (errorCode.equals(ERR_SERVER_0015)) {
			msg = ERR_SERVER_0015_MSG;
		} else if (errorCode.equals(ERR_SERVER_0016)) {
			msg = ERR_SERVER_0016_MSG;
		} else if (errorCode.equals(ERR_SERVER_0017)) {
			msg = ERR_SERVER_0017_MSG;
		} else if (errorCode.equals(ERR_SERVER_0018)) {
			msg = ERR_SERVER_0018_MSG;
		} else if (errorCode.equals(ERR_SERVER_0019)) {
			msg = ERR_SERVER_0019_MSG;
		} else if (errorCode.equals(ERR_SERVER_0020)) {
			msg = ERR_SERVER_0020_MSG;
		} else if (errorCode.equals(ERR_SERVER_0021)) {
			msg = ERR_SERVER_0021_MSG;
		} else if (errorCode.equals(ERR_SERVER_0022)) {
			msg = ERR_SERVER_0022_MSG;
		} else if (errorCode.equals(ERR_SERVER_0023)) {
			msg = ERR_SERVER_0023_MSG;
		} else if (errorCode.equals(ERR_SERVER_0024)) {
			msg = ERR_SERVER_0024_MSG;
		} else if (errorCode.equals(ERR_SERVER_0025)) {
			msg = ERR_SERVER_0025_MSG;
		} else if (errorCode.equals(ERR_GUITAI_0001)) {
			msg = ERR_GUITAI_0001_MSG;
		} else if (errorCode.equals(ERR_GUITAI_0002)) {
			msg = ERR_GUITAI_0002_MSG;
		} else if (errorCode.equals(ERR_INOUT_0003)) {
			msg = ERR_INOUT_0003_MSG;
		}

		return msg;
	}

	/** 处理成功 */
	public static String SUCCESS = "00000";

	/** 处理成功 */
	public static String SUCCESS_MSG = "处理成功";

	/** 服务器已断开 */
	public static String ERR_COMMON_0001 = "00001";

	/** 服务器已断开 */
	public static String ERR_COMMON_0001_MSG = "服务器已断开，请联系客服或者稍后重新登录系统！";

	/** 交易所返回指令错误信息 */
	public static String ERR_COMMON_0002 = "00002";

	/** 交易所返回指令错误信息 */
	public static String ERR_COMMON_0002_MSG = "指令失败，请联系客服或者稍后重新登录系统！";

	/** 账户登录错误号：账户名不正确 */
	public static String ERR_LOGIN_0001 = "10001";

	/** 账户登录错误号：账户名不正确 */
	public static String ERR_LOGIN_0001_MSG = "账户不正确";

	/** 账户登录错误号：登录密码错误 */
	public static String ERR_LOGIN_0002 = "10002";

	/** 账户登录错误号：登录密码错误 */
	public static String ERR_LOGIN_0002_MSG = "登录密码错误";

	/** 账户登录错误号：密码错误次数超限，账户已冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0003 = "10003";

	/** 账户登录错误号：密码错误次数超限，账户已冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0003_MSG = "密码错误次数超限，账户已冻结，请联系客服解冻！";

	/** 账户登录错误号：账户已被冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0004 = "10004";

	/** 账户登录错误号：账户已被冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0004_MSG = "账户已被冻结，请联系客服解冻！";

	/** 账户登录错误号：非法登录 */
	public static String ERR_LOGIN_0005 = "10005";

	/** 账户登录错误号：非法登录 */
	public static String ERR_LOGIN_0005_MSG = "非法登录！";

	/** 账户登录错误号：无接口登录权限 */
	public static String ERR_LOGIN_0006 = "10006";

	/** 账户登录错误号：无接口登录权限 */
	public static String ERR_LOGIN_0006_MSG = "无接口登录权限！";

	/** 账户登录错误号：接口登录权限过期 */
	public static String ERR_LOGIN_0007 = "10007";

	/** 账户登录错误号：接口登录权限过期 */
	public static String ERR_LOGIN_0007_MSG = "接口登录权限过期！";

	/** 账户登录错误号：验证错误次数超限，用户已冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0008 = "10008";

	/** 账户登录错误号：验证错误次数超限，用户已冻结，请联系客服解冻 */
	public static String ERR_LOGIN_0008_MSG = "验证错误次数超限，用户已冻结，请联系客服解冻！";

	/** 账户登录错误号：密保问题答案设置错误，请联系客服 */
	public static String ERR_LOGIN_0009 = "10009";

	/** 账户登录错误号：密保问题答案设置错误，请联系客服 */
	public static String ERR_LOGIN_0009_MSG = "密保问题答案设置错误，请联系客服！";

	/** 账户登录错误号：手机验证码发送失败 */
	public static String ERR_LOGIN_0010 = "10010";

	/** 账户登录错误号：手机验证码发送失败 */
	public static String ERR_LOGIN_0010_MSG = "手机验证码发送失败！";

	/** 用户登录错误号：密保问题错误 */
	public static String ERR_LOGIN_0011 = "10011";
	public static String ERR_LOGIN_0011_MSG = "密保问题错误！";

	/** 用户登录错误号：密保答案错误 */
	public static String ERR_LOGIN_0012 = "10012";
	public static String ERR_LOGIN_0012_MSG = "密保答案错误！";

	/** 用户登录错误号：手机验证码错误 */
	public static String ERR_LOGIN_0013 = "10013";
	public static String ERR_LOGIN_0013_MSG = "手机验证码错误！";

	/** 下单错误号：下单失败 */
	public static String ERR_ORDER_0000 = "20000";

	/** 下单错误号：下单失败 */
	public static String ERR_ORDER_0000_MSG = "下单失败";

	/** 下单错误号：资金不足 */
	public static String ERR_ORDER_0001 = "20001";

	/** 下单错误号：资金不足 */
	public static String ERR_ORDER_0001_MSG = "资金不足";

	/** 下单错误号：交易服务器未连接 */
	public static String ERR_ORDER_0002 = "20002";

	/** 下单错误号：交易服务器未连接 */
	public static String ERR_ORDER_0002_MSG = "交易服务器未连接";

	/** 下单错误号：您已被禁止交易，请联系客服解禁 */
	public static String ERR_ORDER_0003 = "20003";

	/** 下单错误号：您已被禁止交易，请联系客服解禁 */
	public static String ERR_ORDER_0003_MSG = "您已被禁止交易，请联系客服解禁";

	/** 下单错误号：下单被拒绝 */
	public static String ERR_ORDER_0004 = "20004";

	/** 下单错误号：下单被拒绝 */
	public static String ERR_ORDER_0004_MSG = "下单被拒绝";

	/** 下单错误号：系统号生成失败 */
	public static String ERR_ORDER_0005 = "20005";

	/** 下单错误号：系统号生成失败 */
	public static String ERR_ORDER_0005_MSG = "系统号生成失败";

	/** 下单错误号：您的资金账户中没有该合约交易所需的币种 */
	public static String ERR_ORDER_0006 = "20006";

	/** 下单错误号：您的资金账户中没有该合约交易所需的币种 */
	public static String ERR_ORDER_0006_MSG = "您的资金账户中没有该合约交易所需的币种";

	/** 下单错误号：该合约已经到期，不能交易 */
	public static String ERR_ORDER_0007 = "20007";

	/** 下单错误号：该合约已经到期，不能交易 */
	public static String ERR_ORDER_0007_MSG = "该合约已经到期，不能交易";

	/** 下单错误号：该交易市场未开市，不能交易 */
	public static String ERR_ORDER_0008 = "20008";

	/** 下单错误号：该交易市场未开市，不能交易 */
	public static String ERR_ORDER_0008_MSG = "该交易市场未开市，不能交易";

	/** 下单错误号：该交易市场已闭市，不能交易 */
	public static String ERR_ORDER_0009 = "20009";

	/** 下单错误号：该交易市场已闭市，不能交易 */
	public static String ERR_ORDER_0009_MSG = "该交易市场已闭市，不能交易";

	/** 下单错误号：下单价格超出限定范围 */
	public static String ERR_ORDER_0010 = "20010";

	/** 下单错误号：下单价格超出限定范围 */
	public static String ERR_ORDER_0010_MSG = "下单价格超出限定范围";

	/** 下单错误号：下单数量过大 */
	public static String ERR_ORDER_0011 = "20011";

	/** 下单错误号：下单数量过大 */
	public static String ERR_ORDER_0011_MSG = "下单数量过大";

	/** 下单错误号：您被禁止交易该合约，请联系客服 */
	public static String ERR_ORDER_0012 = "20012";

	/** 下单错误号：您被禁止交易该合约，请联系客服 */
	public static String ERR_ORDER_0012_MSG = "您被禁止交易该合约，请联系客服";

	/** 下单错误号：您的资金账户风险率过高，已被禁止交易 */
	public static String ERR_ORDER_0013 = "20013";

	/** 下单错误号：您的资金账户风险率过高，已被禁止交易 */
	public static String ERR_ORDER_0013_MSG = "您的资金账户风险率过高，已被禁止交易";

	/** 下单错误号：定单已成交，撤单失败 */
	public static String ERR_ORDER_0014 = "20014";

	/** 下单错误号：定单已成交，撤单失败 */
	public static String ERR_ORDER_0014_MSG = "撤单失败";

	/** 下单错误号：您的账户交易数据出现异常，暂停交易 */
	public static String ERR_ORDER_0015 = "20015";

	/** 下单错误号：您的账户交易数据出现异常，暂停交易 */
	public static String ERR_ORDER_0015_MSG = "您的账户交易数据出现异常，暂停交易";

	/** 改单错误号：改单失败 */
	public static String ERR_ORDER_0016 = "20016";

	/** 改单错误号：改单失败 */
	public static String ERR_ORDER_0016_MSG = "改单失败";

	/** 止损止盈错误号：止损止盈设置失败 */
	public static String ERR_ORDER_0017 = "20017";

	/** 止损止盈错误号：止损止盈设置失败 */
	public static String ERR_ORDER_0017_MSG = "止损止盈设置失败";

	/** 止损止盈错误号：止损止盈设置删除失败 */
	public static String ERR_ORDER_0018 = "20018";

	/** 止损止盈错误号：止损止盈设置删除失败 */
	public static String ERR_ORDER_0018_MSG = "止损止盈设置删除失败";

	/** 下单错误号：下单数量超过客户持仓限量 */
	public static String ERR_ORDER_0019 = "20019";

	/** 下单错误号：下单数量超过客户持仓限量 */
	public static String ERR_ORDER_0019_MSG = "下单数量超过客户持仓限量";

	/** 下单错误号：下单数量超过客户可下单买量 */
	public static String ERR_ORDER_0020 = "20020";

	/** 下单错误号：下单数量超过客户可下单买量 */
	public static String ERR_ORDER_0020_MSG = "下单数量超过客户可下单买量";

	/** 下单错误号：下单数量超过客户可下单卖量 */
	public static String ERR_ORDER_0021 = "20021";

	/** 下单错误号：下单数量超过客户可下单卖量 */
	public static String ERR_ORDER_0021_MSG = "下单数量超过客户可下单卖量";

	/** 下单错误号：下单数量超过公司持仓限量 */
	public static String ERR_ORDER_0022 = "20022";

	/** 下单错误号：下单数量超过客户持仓限量 */
	public static String ERR_ORDER_0022_MSG = "下单数量超过公司持仓限量";

	/** 下单错误号：下单数量超过公司可下单买量 */
	public static String ERR_ORDER_0023 = "20023";

	/** 下单错误号：下单数量超过公司可下单买量 */
	public static String ERR_ORDER_0023_MSG = "下单数量超过公司可下单买量";

	/** 下单错误号：下单数量超过公司可下单卖量 */
	public static String ERR_ORDER_0024 = "20024";

	/** 下单错误号：下单数量超过公司可下单卖量 */
	public static String ERR_ORDER_0024_MSG = "下单数量超过公司可下单卖量";

	/** 下单错误号：Dealer下单数量超过最大可下单数量 */
	public static String ERR_ORDER_0025 = "20025";

	/** 下单错误号：Dealer下单数量超过最大可下单数量 */
	public static String ERR_ORDER_0025_MSG = "Dealer下单数量超过最大可下单数量";

	/** 下单错误号：合约临近交割，只可平仓，不能开仓 */
	public static String ERR_ORDER_0026 = "20026";

	/** 下单错误号：合约临近交割，只可平仓，不能开仓 */
	public static String ERR_ORDER_0026_MSG = "合约临近交割，只可平仓，不能开仓";

	/** 下单错误号：该合约已过最后交易日时间，禁止电子盘交易 */
	public static String ERR_ORDER_0027 = "20027";

	/** 下单错误号：该合约已过最后交易日时间，禁止电子盘交易 */
	public static String ERR_ORDER_0027_MSG = "该合约已过最后交易日时间，禁止电子盘交易";

	/** 下单错误号：商品未开放，禁止交易 */
	public static String ERR_ORDER_0028 = "20028";

	/** 下单错误号：商品未开放，禁止交易 */
	public static String ERR_ORDER_0028_MSG = "商品未开放，禁止交易";

	/** 下单错误号：下单数量超过该商品单笔最大可下单数 */
	public static String ERR_ORDER_0029 = "20029";

	/** 下单错误号：下单数量超过该商品单笔最大可下单数 */
	public static String ERR_ORDER_0029_MSG = "单笔下单数量超过该商品单笔最大可下单数";

	/** 下单错误号：条件单设置失败 */
	public static String ERR_ORDER_0030 = "20030";

	/** 下单错误号：条件单设置失败 */
	public static String ERR_ORDER_0030_MSG = "条件单设置失败";

	/** 下单错误号：条件单删除失败 */
	public static String ERR_ORDER_0031 = "20031";

	/** 下单错误号：条件单删除失败 */
	public static String ERR_ORDER_0031_MSG = "条件单删除失败";

	/** 下单错误号：持仓不足，平仓失败 */
	public static String ERR_ORDER_0032 = "20032";
	public static String ERR_ORDER_0032_MSG = "持仓不足，平仓失败";

	/** 下单错误号：您不能交易该商品,请联系客服开通 */
	public static String ERR_ORDER_0033 = "20033";
	public static String ERR_ORDER_0033_MSG = "您不能交易该商品,请联系客服开通";

	/** 请求CME行情错误号：请求CME行情失败 */
	public static String ERR_ORDER_0034 = "20034";
	public static String ERR_ORDER_0034_MSG = "请求CME行情错误号：请求CME行情失败";

	/** 下单失败：不支持的下单类型 */
	public static String ERR_ORDER_0035 = "20035";
	public static String ERR_ORDER_0035_MSG = "不支持的下单类型";

	/** 下单失败：非法操作人员发送交易指令 */
	public static String ERR_ORDER_0036 = "20036";
	public static String ERR_ORDER_0036_MSG = "非法操作人员发送交易指令";

	/* 下单失败：超过FCM固定额度，只可平仓，不能再加仓 */
	public static String ERR_ORDER_0045 = "20045";
	public static String ERR_ORDER_0045_MSG = "超过FCM固定额度，只可平仓，不能再加仓";

	/* 下单失败：没有卖空期权权限 */
	public static String ERR_ORDER_0046 = "20046";
	public static String ERR_ORDER_0046_MSG = "没有卖空期权权限";

	/** 服务器错误号：交易服务器已断开 */
	public static String ERR_SERVER_0000 = "30000";

	/** 服务器错误号：交易服务器已断开 */
	public static String ERR_SERVER_0000_MSG = "交易服务器已断开";

	/** 服务器错误号：前置机已断开 */
	public static String ERR_SERVER_0001 = "30001";

	/** 服务器错误号：前置机已断开 */
	public static String ERR_SERVER_0001_MSG = "前置机已断开";

	/** 服务器错误号：交易服务器已断开 */
	public static String ERR_SERVER_0002 = "30002";

	/** 服务器错误号：交易服务器已断开 */
	public static String ERR_SERVER_0002_MSG = "交易服务器已断开";

	/** 服务器错误号：通信网关已断开 */
	public static String ERR_SERVER_0003 = "30003";

	/** 服务器错误号：通信网关已断开 */
	public static String ERR_SERVER_0003_MSG = "通信网关已断开";

	/** 服务器错误号：行情服务器已断开 */
	public static String ERR_SERVER_0004 = "30004";

	/** 服务器错误号：行情服务器已断开 */
	public static String ERR_SERVER_0004_MSG = "行情服务器已断开";

	/** 服务器错误号：中间件服务器已断开 */
	public static String ERR_SERVER_0005 = "30005";

	/** 服务器错误号：中间件服务器已断开 */
	public static String ERR_SERVER_0005_MSG = "中间件服务器已断开";

	/** 服务器错误号：数据库服务器已断开 */
	public static String ERR_SERVER_0006 = "30006";

	/** 服务器错误号：数据库服务器已断开 */
	public static String ERR_SERVER_0006_MSG = "数据库服务器已断开";

	/** 服务器错误号：通信网关与上手服务器已断开 */
	public static String ERR_SERVER_0007 = "30007";

	/** 服务器错误号：通信网关与上手服务器已断开 */
	public static String ERR_SERVER_0007_MSG = "通信网关与上手服务器已断开";

	/** 服务器错误号：行情服务器与上手服务器已断开 */
	public static String ERR_SERVER_0008 = "30008";

	/** 服务器错误号：行情服务器与上手服务器已断开 */
	public static String ERR_SERVER_0008_MSG = "行情服务器与上手服务器已断开";

	/** 服务器错误号：数据库读写出错 */
	public static String ERR_SERVER_0009 = "30009";

	/** 服务器错误号：数据库读写出错 */
	public static String ERR_SERVER_0009_MSG = "数据库读写出错";

	/** 服务器错误号：交易服务器定单请求处理异常 */
	public static String ERR_SERVER_0010 = "30010";

	/** 服务器错误号：交易服务器定单请求处理异常 */
	public static String ERR_SERVER_0010_MSG = "交易服务器定单请求处理异常";

	/** 服务器错误号：交易服务器定单确认处理异常 */
	public static String ERR_SERVER_0011 = "30011";

	/** 服务器错误号：交易服务器定单确认处理异常 */
	public static String ERR_SERVER_0011_MSG = "交易服务器定单确认处理异常";

	/** 服务器错误号：交易服务器定单成交处理异常 */
	public static String ERR_SERVER_0012 = "30012";

	/** 服务器错误号：交易服务器定单成交处理异常 */
	public static String ERR_SERVER_0012_MSG = "交易服务器定单成交处理异常";

	/** 服务器错误号：交易服务器撤单处理异常 */
	public static String ERR_SERVER_0013 = "30013";

	/** 服务器错误号：交易服务器撤单处理异常 */
	public static String ERR_SERVER_0013_MSG = "交易服务器撤单处理异常";

	/** 服务器错误号：通信网关定单确认处理异常 */
	public static String ERR_SERVER_0014 = "30014";

	/** 服务器错误号：通信网关定单确认处理异常 */
	public static String ERR_SERVER_0014_MSG = "通信网关定单确认处理异常";

	/** 服务器错误号：通信网关定单成交处理异常 */
	public static String ERR_SERVER_0015 = "30015";

	/** 服务器错误号：通信网关定单成交处理异常 */
	public static String ERR_SERVER_0015_MSG = "通信网关定单成交处理异常";

	/** 服务器错误号：通信网关撤单成功处理异常 */
	public static String ERR_SERVER_0016 = "30016";

	/** 服务器错误号：通信网关撤单成功处理异常 */
	public static String ERR_SERVER_0016_MSG = "通信网关撤单成功处理异常";

	/** 服务器错误号：通信网关定单错误处理异常 */
	public static String ERR_SERVER_0017 = "30017";

	/** 服务器错误号：通信网关定单错误处理异常 */
	public static String ERR_SERVER_0017_MSG = "通信网关定单错误处理异常";

	/** 服务器错误号：通信网关撤单错误处理异常 */
	public static String ERR_SERVER_0018 = "30018";

	/** 服务器错误号：通信网关撤单错误处理异常 */
	public static String ERR_SERVER_0018_MSG = "通信网关撤单错误处理异常";

	/** 服务器错误号：行情服务器接收行情处理异常 */
	public static String ERR_SERVER_0019 = "30019";

	/** 服务器错误号：行情服务器接收行情处理异常 */
	public static String ERR_SERVER_0019_MSG = "行情服务器接收行情处理异常";

	/** 服务器错误号：行情服务器发送行情处理异常 */
	public static String ERR_SERVER_0020 = "30020";

	/** 服务器错误号：行情服务器发送行情处理异常 */
	public static String ERR_SERVER_0020_MSG = "行情服务器发送行情处理异常";

	/** 服务器错误号：中间件数据处理异常 */
	public static String ERR_SERVER_0021 = "30021";

	/** 服务器错误号：中间件数据处理异常 */
	public static String ERR_SERVER_0021_MSG = "中间件数据处理异常";

	/** 服务器错误号：盈损服务器断开异常 */
	public static String ERR_SERVER_0022 = "30022";

	/** 服务器错误号：盈损服务器断开异常 */
	public static String ERR_SERVER_0022_MSG = "盈损服务器断开异常";

	/** 服务器错误号：盈损服务器处理异常 */
	public static String ERR_SERVER_0023 = "30023";

	/** 服务器错误号：盈损服务器处理异常 */
	public static String ERR_SERVER_0023_MSG = "盈损服务器处理异常";

	/** 服务器错误号：数据压缩异常 */
	public static String ERR_SERVER_0024 = "30024";
	public static String ERR_SERVER_0024_MSG = "数据压缩异常";

	/** 服务器错误号：数据解压异常 */
	public static String ERR_SERVER_0025 = "30025";
	public static String ERR_SERVER_0025_MSG = "数据解压异常";

	/** 账户修改密码错误 */
	public static String ERR_MODIFY_001 = "30026";
	public static String ERR_MODIFY_001_MSG = "账户旧密码错误";

	/** 修改密码出错 */
	public static String ERR_MODIFY_002 = "30027";
	public static String ERR_MODIFY_002_MSG = "修改密码出错";

	/** 修改密码出错 */
	public static String ERR_MODIFY_003 = "30028";
	public static String ERR_MODIFY_003_MSG = "修改密码与历史3次相同";

	/** 柜台错误号：冻结客户失败 */
	public static String ERR_GUITAI_0001 = "40001";

	/** 柜台错误号：冻结客户失败 */
	public static String ERR_GUITAI_0001_MSG = "冻结客户失败";

	/** 柜台错误号：冻结客户资金失败 */
	public static String ERR_GUITAI_0002 = "40002";

	/** 柜台错误号：冻结客户资金失败 */
	public static String ERR_GUITAI_0002_MSG = "冻结客户资金失败";

	/** 出入金错误号：出入金申请失败 */
	public static String ERR_INOUT_0003 = "40003";

	/** 出入金错误号：出入金申请失败 */
	public static String ERR_INOUT_0003_MSG = "出入金申请失败";
}
