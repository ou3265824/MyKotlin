package com.shanghaizhida;

public interface ZDLogger {
	public static final int LVL_DEBUG = 4;
	public static final int LVL_TRACE = 3;
	public static final int LVL_CRITCAL = 2;
	public static final int LVL_ERROR = 1;

	public void log(int logLvl, String content);

	public void log(int logLvl, String classN, String method, String content);

	public void setLogLevel(int logLvl);

	public void Dispose();
}
