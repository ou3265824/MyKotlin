package com.sc.batch;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;

public class Test {

	public static void main(String[] args) throws UnsupportedEncodingException {
//		BigDecimal nowPrice = new BigDecimal(3143.000);
//		BigDecimal costPrice = new BigDecimal(3150.000);
//		BigDecimal upperTick = new BigDecimal(1.00000000);
//		BigDecimal lowerTick = new BigDecimal(1);
//		BigDecimal productDot = new BigDecimal(10.00000000);
//		double dotNum = 0;
//		BigDecimal volume = new BigDecimal(10);
//		BigDecimal direct = new BigDecimal(1);
//		BigDecimal profit = (nowPrice.subtract(costPrice)).divide(upperTick).multiply(lowerTick)
//				.divide(new BigDecimal(Math.pow(10.0, dotNum))).multiply(productDot).multiply(volume).multiply(direct);
//		System.out.println(profit);
		
		
		BigDecimal nowPrice = new BigDecimal(3193.2);
		BigDecimal costPrice = new BigDecimal(2885);
		BigDecimal upperTick = new BigDecimal(0.2);
		BigDecimal lowerTick = new BigDecimal(10);
		BigDecimal productDot = new BigDecimal(300);
		double dotNum = 1;
		BigDecimal volume = new BigDecimal(1);
		BigDecimal direct = new BigDecimal(1);
		BigDecimal profit = (nowPrice.subtract(costPrice)).divide(upperTick,10,BigDecimal.ROUND_FLOOR).multiply(lowerTick)
				.divide(new BigDecimal(Math.pow(10.0, dotNum)),10,BigDecimal.ROUND_FLOOR).multiply(productDot).multiply(volume).multiply(direct);
		System.out.println(profit);
	}
}
