package com.sc.batch.business.service;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.sc.batch.business.dao.ScReleaseDao;
import com.sc.batch.business.dao.ScReleaseUserDao;
import com.sc.batch.business.entity.ScAFutures;
import com.sc.batch.business.entity.ScAStock;
import com.sc.batch.business.entity.ScRelease;
import com.sc.batch.business.entity.ScReleaseDetails;
import com.sc.batch.business.entity.ScReleaseUser;
import com.sc.batch.business.quota.QuotaUtils;
import com.sc.batch.common.enums.CommodityTypeEnum;
import com.sc.batch.common.enums.DictEnum;
import com.sc.batch.common.utils.PinyinUtils;
import com.sc.batch.common.utils.TimeUtil;
import com.sc.batch.common.utils.json.JacksonUtil;
import com.sc.batch.common.utils.redis.RedisService;

@Service
public class TaskService {

	@Autowired
	private ScReleaseDao releaseDao;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScReleaseUserDao releaseUserDao;

	@Transactional
	public boolean calcProfit() {
		// 获取所有正在进行中的策略
		Set<ScRelease> releaseSet = findByStatusAndDelFlag(DictEnum.ing.value, DictEnum.not_del.value);
		String key = null;
		List<ScReleaseDetails> detailsList = Lists.newArrayList();
		if (releaseSet != null && releaseSet.size() > 0) {
			for (ScRelease release : releaseSet) {
				if (release.getCollectMoney().compareTo(new BigDecimal(0.00)) == 0) {
					continue;
				}
				List<String> hisProfitRateList = Lists.newArrayList();
				BigDecimal totalProfit = new BigDecimal(0.00);
				BigDecimal close_totalProfit = new BigDecimal(0.00);
				detailsList = release.getDetails();
				// 更新策略中商品的价格和收益
				if (detailsList != null && detailsList.size() > 0) {
					for (ScReleaseDetails details : detailsList) {
						if (StringUtils.isNotBlank(details.getCloseFlag())
								&& details.getCloseFlag().equals(DictEnum.close.value)) {
							close_totalProfit = close_totalProfit.add(details.getProfit());
							continue;
						}
						if (details.getCostPrice().compareTo(new BigDecimal(0.00)) == 0) {
							continue;
						}
						// 根据商品code查找该商品是否在redis中存在
						key = DictEnum.redis_market_prefix.value + "-" + details.getCode() + "-" + details.getName()
								+ "-" + PinyinUtils.converterToFirstSpell(details.getName());
						BigDecimal profit = details.getProfit();
						float profitRate = details.getProfitRate();
						if (redisService.exists(key)) {
							BigDecimal nowPrice = new BigDecimal(0.00);
							// 判断是股票还是期货
							if (details.getType().equals(CommodityTypeEnum.内盘期货.value)) {
								ScAFutures futures = JacksonUtil.jsonToObj(String.valueOf(redisService.get(key)),
										ScAFutures.class);
								nowPrice = QuotaUtils.getNowPrice(futures.getCode(), CommodityTypeEnum.内盘期货.value);
								profit = (nowPrice.subtract(details.getCostPrice())).divide(futures.getFUpperTick())
										.multiply(new BigDecimal(futures.getFLowerTick())
												.divide(new BigDecimal(Math.pow(10.0, futures.getFDotNum()))))
										.multiply(futures.getFProductDot())
										.multiply(new BigDecimal(details.getVolume()))
										.multiply(new BigDecimal(buysell(details.getDirect())));
							} else if (details.getType().equals(CommodityTypeEnum.内盘股票.value)) {
								ScAStock stock = JacksonUtil.jsonToObj(String.valueOf(redisService.get(key)),
										ScAStock.class);
								nowPrice = QuotaUtils.getNowPrice(stock.getType() + stock.getCode(),
										CommodityTypeEnum.内盘股票.value);
								profit = (nowPrice.subtract(details.getCostPrice()))
										.multiply(new BigDecimal(details.getVolume()));
							}
							profit = profit.setScale(2, BigDecimal.ROUND_FLOOR);
							profitRate = profit.divide(details.getTotalCost(), 4, BigDecimal.ROUND_FLOOR)
									.floatValue();
							details.setNowPrice(nowPrice);
							details.setProfit(profit);
							details.setProfitRate(profitRate);
							details.setUpdateValue(details, DictEnum.batch_id.value);
							totalProfit = totalProfit.add(profit);
						}
					}
					totalProfit = totalProfit.add(close_totalProfit);
					release.setDetails(detailsList);
					release.setProfit(totalProfit);
					release.setProfitRate(
							totalProfit.divide(release.getCollectMoney(), 4, BigDecimal.ROUND_FLOOR).floatValue());
					// 设置历史收益率
					String day = TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat);
					if (release.getHisProfitRate().indexOf(day) == -1) {
						release.setHisProfitRate(
								release.getHisProfitRate() + "," + day + "@@" + release.getProfitRate());
					} else {
						String[] arr = release.getHisProfitRate().split(",");
						for (int i = 0; i < arr.length; i++) {
							if (arr[i].indexOf(day) != -1) {
								arr[i] = arr[i].split("@@")[0] + "@@" + release.getProfitRate();
							}
							hisProfitRateList.add(arr[i]);
						}
						release.setHisProfitRate(Joiner.on(",").join(hisProfitRateList));
					}
					release.setUpdateValue(release, DictEnum.batch_id.value);
					releaseDao.save(release);
					// 计算每个人的收益
					calcUserProfit(release);
				}
			}
		}
		return true;
	}

	// 计算每个人的收益
	public void calcUserProfit(ScRelease release) {
		List<ScReleaseUser> list = releaseUserDao.findByReleaseId(release.getReleaseId());
		if (list != null && list.size() > 0) {
			for (ScReleaseUser sc : list) {
				// 更新每个验证者的收益
				BigDecimal rate = sc.getAmount().divide(release.getCollectMoney(), 10, BigDecimal.ROUND_FLOOR);
				sc.setProfit(rate.multiply(release.getProfit()).setScale(2, BigDecimal.ROUND_FLOOR));
				releaseUserDao.save(sc);
			}
		}
	}

	/**
	 * 根据买卖方向获取计算的乘数因子 买1 卖-1 用于计算收益（当前价-成本价）
	 * 
	 * @param type
	 * @return
	 */
	public int buysell(String type) {
		if (StringUtils.isNotBlank(type) && type.equals(DictEnum.sell.value)) {
			return -1;
		}
		return 1;
	}

	/**
	 * 根据策略状态来查询有效的策略数据
	 * 
	 * @param status
	 * @param delFlag
	 * @return
	 */
	public Set<ScRelease> findByStatusAndDelFlag(String status, String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _status = root.get("status");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_status, status));
				predicates.add(cb.equal(_delFlag, delFlag));
				return query.where(predicates.toArray(new Predicate[] {})).getRestriction();
			}

		};
		return releaseDao.findAll(specification);
	}
}
