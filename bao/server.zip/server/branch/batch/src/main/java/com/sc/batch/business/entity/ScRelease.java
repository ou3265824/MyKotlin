package com.sc.batch.business.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.sc.batch.common.enums.DictEnum;
import com.sc.batch.common.utils.ArithDecimal;

@Table
@Entity
public class ScRelease extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int releaseId;
	private String releaseName;
	private String intro;
	private int groupId;
	private int userId;
	private String status;
	private BigDecimal collectMoney;
	private BigDecimal profit;
	private Float profitRate;
	private List<ScReleaseDetails> details;
	private String startDate;
	private String endDate;
	private String delFlag;
	private String hisProfitRate;
	
	public String getHisProfitRate() {
		return hisProfitRate;
	}
	public void setHisProfitRate(String hisProfitRate) {
		this.hisProfitRate = hisProfitRate;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "releaseId")
	public List<ScReleaseDetails> getDetails() {
		return details;
	}
	public void setDetails(List<ScReleaseDetails> details) {
		this.details = details;
	}
	public Float getProfitRate() {
		return Float.parseFloat(ArithDecimal.roundByScale(profitRate, 4));
	}
	public void setProfitRate(Float profitRate) {
		this.profitRate = profitRate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}
	public String getReleaseName() {
		return releaseName;
	}
	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getCollectMoney() {
		return collectMoney;
	}
	public void setCollectMoney(BigDecimal collectMoney) {
		this.collectMoney = collectMoney;
	}
	public BigDecimal getProfit() {
		return profit;
	}
	public void setProfit(BigDecimal profit) {
		this.profit = profit;
	}
	
	@Override
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setStatus(DictEnum.moren.value);
		this.setCollectMoney(new BigDecimal(0.00));
		this.setProfit(new BigDecimal(0.00));
		this.setProfitRate(0.00f);
		this.setDelFlag(DictEnum.not_del.value);
		this.setHisProfitRate(this.getCreateDate().substring(0, 10).replace("-", "")+"@@"+this.getProfitRate());
	}
}
