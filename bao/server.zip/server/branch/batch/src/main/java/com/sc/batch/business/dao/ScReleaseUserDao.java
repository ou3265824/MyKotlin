package com.sc.batch.business.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sc.batch.business.entity.ScReleaseUser;

public interface ScReleaseUserDao extends JpaRepository<ScReleaseUser, Integer>{

	List<ScReleaseUser> findByReleaseId(int releaseId);
}
