
package com.sc.batch.business.entity;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sc.batch.common.utils.StringUtils;

/**
 * 注册用户Entity
 */

@Table
@Entity
public class ScUser implements Serializable {

	/**
	 * 唯一标识
	 */
	private static final long serialVersionUID = 2205393907497644586L;
	private int userId;
	private String userName; // 用户名
	private String mobile; // 手机号码
	private String openId;//微信号
	private String gender;//性别
	private BigDecimal amount;//账户余额
	private String firstLogin;//是否第一次登录
	private String createDate; // 创建日期
	private String updateDate; // 更新日期
	private String intro;//用户简介
	private String groupLimit;//是否可以创建圈子
	private BigDecimal ableAmount;//可用资金
	
	public BigDecimal getAbleAmount() {
		return ableAmount;
	}

	public void setAbleAmount(BigDecimal ableAmount) {
		this.ableAmount = ableAmount;
	}

	public String getGroupLimit() {
		return groupLimit;
	}

	public void setGroupLimit(String groupLimit) {
		this.groupLimit = groupLimit;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCreateDate() {
		return (StringUtils.isBlank(createDate)) ? createDate : createDate.replace(".0", "");
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return (StringUtils.isBlank(updateDate)) ? updateDate : updateDate.replace(".0", "");
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getFirstLogin() {
		return firstLogin;
	}

	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
}