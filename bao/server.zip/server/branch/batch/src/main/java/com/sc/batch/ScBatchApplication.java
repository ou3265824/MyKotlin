package com.sc.batch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.sc.batch.frame.config.AppConfig;

@SpringBootApplication
@EnableScheduling
@Import(AppConfig.class)
public class ScBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(ScBatchApplication.class, args);
	}
}
