package com.sc.batch.frame.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;

import com.sc.batch.common.utils.redis.RedisConfig;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@EnableAutoConfiguration
public class AppConfig {
	
	@Autowired
	private RedisConfig redisConfig;
	
	@Bean(name = "jedisConnectionFactory")
	public JedisConnectionFactory jedisConnectionFactory() {
		JedisConnectionFactory jcf = new JedisConnectionFactory();
		jcf.setHostName(redisConfig.getHost());
		jcf.setPassword(redisConfig.getPassword());
		jcf.setPort(Integer.valueOf(redisConfig.getPort()));
		jcf.setUsePool(true);
		return jcf;
	}

	@Bean(name="jedisPool")
	public JedisPool jedisPool(){
		JedisPoolConfig jedisPoolConfig=new JedisPoolConfig();
		jedisPoolConfig.setMinIdle(redisConfig.getPool().getMinIdle());
		jedisPoolConfig.setMaxIdle(redisConfig.getPool().getMaxIdle());
		jedisPoolConfig.setMaxWaitMillis(redisConfig.getPool().getMaxWait());
		jedisPoolConfig.setTestOnBorrow(true);
		jedisPoolConfig.setTestOnReturn(true);
		JedisPool jedisPool=new JedisPool(jedisPoolConfig,redisConfig.getHost(),redisConfig.getPort(),redisConfig.getTimeout());
		return jedisPool;
	}
}
