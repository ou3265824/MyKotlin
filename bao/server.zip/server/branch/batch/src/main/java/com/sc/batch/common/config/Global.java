package com.sc.batch.common.config;

public class Global {
	
}
