package com.sc.batch.business.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sc.batch.business.entity.ScUser;

public interface ScUserDao extends JpaRepository<ScUser, Integer>{

}
