package com.sc.batch.common.enums;

public enum CommodityTypeEnum {
	
	内盘股票("11"),
	外盘股票("10"),
	内盘期货("01"),
	外盘期货("00");
	
	public String value;
	
	private CommodityTypeEnum(String value){
		this.value=value;
	}
	
}
