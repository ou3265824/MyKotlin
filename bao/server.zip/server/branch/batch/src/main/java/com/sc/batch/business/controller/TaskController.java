package com.sc.batch.business.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sc.batch.business.service.TaskService;

@RestController
public class TaskController {

	@Autowired
	private TaskService taskService;
	
	/**
	 * 计算收益
	 * @return
	 */
	@PostMapping("/calc/profit")
	public boolean calcProfit(){
		return taskService.calcProfit();
	}
	
	/*
	 * 每天15点30启动
	 */
	@Scheduled(cron = "0 30 15 * * ?")
	public void everyDayStart(){
		taskService.calcProfit();
	}
}
