package com.sc.batch.common.enums;

public enum DictEnum {
	
	del("数据逻辑删除","1"),
	not_del("数据正常","0"),
	apply("申请中","0"),
	audit_pass("审核通过","1"),
	audit_refuse("审核拒绝","2"),
	ignore("忽略","1"),
	not_ignore("不忽略","0"),
	free("免费","0"),
	charge("收费","1"),
	moren("默认","D"),
	ing("进行中","I"),
	end("结束","E"),
	all("所有","A"),
	positive("是","T"),
	negative("否","F"),
	secret("保密","0"),
	male("男","1"),
	female("女","2"),
	picFormat("JPG格式",".jpg"),
	my("我的","0"),
	success("成功","success"),
	join("加入","join"),
	quit("退出","quit"),
	batch_id("批处理ID","batch"),
	open("开启","0"),
	close("关闭","1"),
	buy("买","1"),
	sell("卖","2"),
	redis_market_prefix("REDIS内存储的行情基本数据的前缀","market_!@#sc"),
	index_code_prefix("指数code的前缀","CFF_RE_");
	
	public String desc;
	public String value;
	
	private DictEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	
	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
	
	public static void main(String[] args) {
		System.out.println(DictEnum.del.value);
	}
}
