package com.sc.batch.business.quota;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.sc.batch.common.enums.CommodityTypeEnum;
import com.sc.batch.common.enums.DictEnum;
import com.sc.batch.common.utils.HttpUtils;

public class QuotaUtils {

	/**
	 * 调用新浪接口获取商品现价
	 * @return
	 */
	public static BigDecimal getNowPrice(String quotaCode,String commodityType){
		String result=HttpUtils.getHttp("http://hq.sinajs.cn/list="+quotaCode);
		if(StringUtils.isNotBlank(result)){
			String[] arr=result.substring(result.indexOf("\"")+1, result.lastIndexOf("\"")).split(",");
			if(arr!=null && arr.length>3){
				if(commodityType.equals(CommodityTypeEnum.内盘期货.value)){
					if(quotaCode.indexOf(DictEnum.index_code_prefix.value)!=-1){
						return new BigDecimal(arr[3]);
					}
					return new BigDecimal(arr[8]);
				}else if(commodityType.equals(CommodityTypeEnum.内盘股票.value)){
					return new BigDecimal(arr[3]);
				}
			}
		}
		return new BigDecimal(0.00);
	}
}
