/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.common.beanvalidator;

/**
 * 默认Bean验证组
 * @author jeeplus
 */
public interface DefaultGroup {

}
