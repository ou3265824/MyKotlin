package com.jeeplus.modules.iim.entity;

public class Friend {
	
	private String id;
	
	private String name;
	
	private String face;

	public void setId(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setFace(String face) {
		this.face = face;
	}

	public String getFace() {
		return face;
	}

}
