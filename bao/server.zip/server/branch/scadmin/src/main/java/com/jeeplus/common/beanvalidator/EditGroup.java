/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.common.beanvalidator;

/**
 * 编辑Bena验证组
 * @author jeeplus
 */
public interface EditGroup {

}
