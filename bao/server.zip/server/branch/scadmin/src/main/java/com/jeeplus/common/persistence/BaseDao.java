/**
 * Copyright &copy; 2015-2020 <a href="http://www.jeeplus.org/">JeePlus</a> All rights reserved.
 */
package com.jeeplus.common.persistence;

/**
 * DAO支持类实现
 * @author jeeplus
 * @version 2014-05-16
 */
public interface BaseDao {

}