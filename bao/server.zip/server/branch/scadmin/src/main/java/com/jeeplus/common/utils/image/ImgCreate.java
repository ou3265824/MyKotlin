package com.jeeplus.common.utils.image;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

public class ImgCreate {

	public void createImage(String path,String content,String mobile){
		Random random=new Random();
		Identicon identicon = new Identicon(content, new Color(random.nextInt(256),random.nextInt(256),random.nextInt(256)));
		try {
			identicon.saveToPath(path);
			Pic pic = new Pic();			  
	        BufferedImage img = pic.loadImageLocal(path+"\\identicon.jpg"); 
	        String fileName=mobile+"img.jpg";
	        pic.writeImageLocal(path+"\\"+fileName,pic.modifyImage(img,content,600,600)); 
		}
		catch (IOException e) {			
			e.printStackTrace();
		}
	}
	
}
