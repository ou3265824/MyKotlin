package com.jeeplus.common.utils;

import java.io.File;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

public class Upload {
	public static String upload(HttpServletRequest request, HttpServletResponse response) throws Exception{	    	
    	MultipartHttpServletRequest multipartRequest =(MultipartHttpServletRequest) request;
        MultipartFile file = multipartRequest.getFile("image_file");
       
    	 String path = request.getSession().getServletContext().getRealPath("/WEB-INF/userfiles/upload");// 文件保存目录，也可自定为绝对路径
         String fileName = file.getOriginalFilename();// getOriginalFilename和getName是不一样的哦
         //System.out.println(path);        
               
         File targetFile = new File(path, fileName);  
         if(!targetFile.exists()){  
             targetFile.mkdirs();  
         }  
   
         //保存  
         try {  
             file.transferTo(targetFile);  
         } catch (Exception e) {  
             e.printStackTrace();  
         }  
        return path+File.separator+fileName;
    }
}
