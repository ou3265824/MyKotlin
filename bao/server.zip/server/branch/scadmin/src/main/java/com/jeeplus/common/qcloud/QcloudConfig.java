package com.jeeplus.common.qcloud;

public class QcloudConfig {

	public static final int appid=1400031021;
	public static final String appkey="b2fa2bd80331879c3c0c02cc39fdc4e9";
	public static final int tmplId = 22043;
	public static final String nationCode="86";
	public static final String signName="直达国际";
}
