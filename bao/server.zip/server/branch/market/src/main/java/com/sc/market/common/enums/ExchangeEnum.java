package com.sc.market.common.enums;

public enum ExchangeEnum {

	中国金融期货交易所("CFFEX"),
	上海期货交易所("SHFE"),
	大连商品交易所("DCE"),
	郑州商品交易所("CZCE");
	
	public String value;
	
	private ExchangeEnum(String value){
		this.value=value;
	}
}
