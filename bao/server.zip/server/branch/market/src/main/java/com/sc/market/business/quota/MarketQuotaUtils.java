package com.sc.market.business.quota;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.joda.time.DateTime;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.sc.market.business.dao.ScAFuturesDao;
import com.sc.market.business.entity.ScAFutures;
import com.sc.market.business.entity.ScAStock;
import com.sc.market.common.enums.CommodityTypeEnum;
import com.sc.market.common.enums.DictEnum;
import com.sc.market.common.enums.ExchangeEnum;
import com.sc.market.common.utils.StringUtils;
import com.sc.market.common.utils.TimeUtil;
import com.sc.market.common.utils.json.JacksonUtil;
import com.sc.market.common.utils.pinyin.PinyinUtils;
import com.sc.market.common.utils.redis.RedisService;

@Service
public class MarketQuotaUtils {

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScAFuturesDao scAFuturesDao;

	/**
	 * 抓取网页数据
	 * 
	 * @param url
	 * @param charSet
	 * @return
	 */
	public String sendGet(String url, String charSet) { // 定义一个字符串用来存储网页内容
		String result = "";
		// 定义一个缓冲字符输入流
		BufferedReader in = null;
		try {
			// 将string转成url对象
			URL realUrl = new URL(url);
			// 初始化一个链接到那个url的连接
			URLConnection connection = realUrl.openConnection();
			// 开始实际的连接
			connection.connect();
			// 初始化 BufferedReader输入流来读取URL的响应
			in = new BufferedReader(new InputStreamReader(connection.getInputStream(), charSet));
			// 用来临时存储抓取到的每一行的数据
			String line;
			while ((line = in.readLine()) != null) {
				// 遍历抓取到的每一行并将其存储到result里面
				result += line;
			}
		} catch (Exception e) {
			System.out.println("发送GET请求出现异常！" + e);
			e.printStackTrace();
		} // 使用finally来关闭输入流
		finally {
			try {
				if (in != null) {
					in.close();
				}
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		return result;
	}

	/**
	 * 通过抓取东财的网页数据来获取所有A股的代码和名称，然后保存至REDIS
	 * 
	 * @return
	 * @throws IOException
	 */
	public boolean saveAllAStockBaseInfo() {
		// 定义即将访问的链接
		String url = "http://quote.eastmoney.com/stocklist.html";
		// 访问链接并获取页面内容
		String result = sendGet(url, "gb2312");
		Document document = Jsoup.parse(result);
		// 获得文档下所有div标签，返回的是一个标签的集合
		Elements elements = document.select("a[target=_blank]a[href~=^http://quote.eastmoney.com/s]");
		// 定义一个标签对象
		Element element = null;
		// 从这一个标签集合中一个一个的取出
		ScAStock sc = new ScAStock();
		for (int i = 0; i < elements.size(); i++) {
			element = elements.get(i);
			String href = element.attr("href");
			String value = element.html();
			if (StringUtils.isNotBlank(href) && (href.startsWith("http://quote.eastmoney.com/sh")
					|| href.startsWith("http://quote.eastmoney.com/sz"))) {
				href = href.substring(href.lastIndexOf("/") + 1, href.indexOf(".html"));
				value = value.substring(0, value.indexOf("("));
				sc.setType(href.substring(0, 2));
				sc.setCode(href.substring(2, href.length()));
				sc.setName(value);
				sc.setCommodityType(CommodityTypeEnum.内盘股票.value);
				sc.setNowPrice(new BigDecimal(0.00));
				// redis中保存，key为代码+“-”+名称+“-”+“首字母简拼（大写）”，value为实体类的JSON字符串
				if (!redisService.exists(DictEnum.redis_market_prefix.value + "-" + sc.getCode() + "-" + sc.getName()
						+ "-" + PinyinUtils.converterToFirstSpell(value))) {
					redisService.set(DictEnum.redis_market_prefix.value + "-" + sc.getCode() + "-" + sc.getName() + "-"
							+ PinyinUtils.converterToFirstSpell(value), JacksonUtil.objToJson(sc));
				}
			}
		}
		return true;
	}

	/**
	 * 从数据库中获取期货的基本信息，保存至redis
	 * 
	 * @return
	 */
	public boolean saveAllAFuturesBaseInfo() {
		String[] exchanges = new String[] { ExchangeEnum.上海期货交易所.value, ExchangeEnum.中国金融期货交易所.value,
				ExchangeEnum.大连商品交易所.value, ExchangeEnum.郑州商品交易所.value };
		String FRegDate_old = "19000101";
		if (redisService.exists(DictEnum.aFutures_regDate.value)
				&& StringUtils.isNotBlank(String.valueOf(redisService.get(DictEnum.aFutures_regDate.value)))) {
			FRegDate_old = (String) redisService.get(DictEnum.aFutures_regDate.value);
		}
		String FRegDate_new = "19000101";
		for (String exchangeNo : exchanges) {
			Set<ScAFutures> set = findByFExchangeNoAndFRegDate(exchangeNo, FRegDate_old);
			for (ScAFutures sc : set) {
				if (sc.getCode().indexOf("_") == -1 && TimeUtil.daysBetween(
						TimeUtil.str2DateTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat),
								TimeUtil.DBdayFormat),
						TimeUtil.str2DateTime(sc.getFExpiryDate(), TimeUtil.DBdayFormat)) >= 0) {
					String code = sc.getCode().substring(sc.getCode().indexOf("-") + 1, sc.getCode().length())
							.toUpperCase();
					String contractFName = sc.getContractFName().substring(sc.getContractFName().indexOf("-") + 1,
							sc.getContractFName().length());
					if(exchangeNo.equals(ExchangeEnum.中国金融期货交易所.value)){
						code=DictEnum.index_code_prefix.value+code;
					}
					String jmpn = PinyinUtils.converterToFirstSpell(contractFName);
					sc.setCode(code);
					sc.setCommodityType(CommodityTypeEnum.内盘期货.value);
					sc.setContractFName(contractFName);
					sc.setNowPrice(new BigDecimal(0.00));
					redisService.set(DictEnum.redis_market_prefix.value + "-" + code + "-" + contractFName + "-" + jmpn,
							JacksonUtil.objToJson(sc),
							(TimeUtil.daysBetween(
									TimeUtil.str2DateTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat),
											TimeUtil.DBdayFormat),
									TimeUtil.str2DateTime(sc.getFExpiryDate(), TimeUtil.DBdayFormat)) + 1)  * 60
									* 60 * 24);
					if (Long.parseLong(sc.getFRegDate()) >= Long.parseLong(FRegDate_new)) {
						FRegDate_new = sc.getFRegDate();
					}
				}
			}
		}
		redisService.set(DictEnum.aFutures_regDate.value,
				TimeUtil.dateTime2Str(
						TimeUtil.minusTime(TimeUtil.str2DateTime(FRegDate_new, TimeUtil.DBdayFormat), 1, TimeUtil.DAYS),
						TimeUtil.DBdayFormat));
		return true;
	}

	public Set<ScAFutures> findByFExchangeNoAndFRegDate(String FExchangeNo, String FRegDate) {
		Specification<ScAFutures> specification = new Specification<ScAFutures>() {
			@Override
			public Predicate toPredicate(Root<ScAFutures> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _FExchangeNo = root.get("FExchangeNo");
				Path<String> _FRegDate = root.get("FRegDate");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_FExchangeNo, FExchangeNo));
				predicates.add(cb.greaterThan(_FRegDate, FRegDate));
				return query.where(predicates.toArray(new Predicate[] {})).getRestriction();
			}

		};
		return scAFuturesDao.findAll(specification);
	}

}
