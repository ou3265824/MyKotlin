package com.sc.market.common.enums;

public enum ReturnMsgEnum {
	
	
	operateSuccess("操作成功"),
	operateFail("操作失败"),
	paramsNull("参数为必填项"),
	paramsError("参数填写错误"),
	mobileOrPwdError("手机号或密码错误"),
	userNameNull("用户名为必填项"),
	userNameExist("该用户名已被使用"),
	userNotExist("用户不存在"),
	passwordOldError("原密码填写错误"),
	passwordReError("两次密码输入不一致"),
	mobileNull("手机号码为必填项"),
	mobileExist("该手机号码已注册"),
	tokenIllegal("请先登录"),
	tokenInvalid("请先登录"),
	sysExeption("系统异常"),
	smsException("短信发送异常"),
	loginFail("登陆失败"),
	loginSuccess("登陆成功"),
	logout("登出成功"),
	logoutException("登出异常"),
	resetpwdSuccess("密码修改成功"),
	resetpwdFail("密码修改失败"),
	validCodeTypeNull("验证码类型为必填项"),
	validCodeTypeError("验证码类型错误"),
	nondata("无数据"),
	sendsmsLimit("操作过频，请稍后申领！"),
	groupNotExist("圈子不存在"),
	alreadyInGroup("已加入圈子"),
	easeUserNotExist("环信用户不存在"),
	easeCreateGroupError("创建环信群组失败"),
	nopermission("无权限"),
	refuseQuit("群组拥有者或有正在进行的策略，不能退出"),
	releaseNotExist("策略不存在");
	
	private ReturnMsgEnum(String message) {
		this.message = message;
	}
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return this.message;
	}
	
}
