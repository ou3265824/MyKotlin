package com.sc.market.common.enums;

public enum DictEnum {

	redis_market_prefix("REDIS内存储的行情基本数据的前缀","market_!@#sc"),
	aFutures_regDate("内盘期货更新日期","aFutures_regDate"),
	index_code_prefix("指数code的前缀","CFF_RE_");

	public String desc;
	public String value;
	
	private DictEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	
	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
}
