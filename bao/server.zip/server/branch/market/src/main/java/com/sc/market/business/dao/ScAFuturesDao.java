package com.sc.market.business.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.sc.market.business.entity.ScAFutures;

public interface ScAFuturesDao extends JpaRepository<ScAFutures,String>,SpecificationDao<ScAFutures>{

}
