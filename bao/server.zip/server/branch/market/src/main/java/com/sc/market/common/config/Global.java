package com.sc.market.common.config;

public class Global {
	
}
