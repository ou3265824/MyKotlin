package com.sc.market.business.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sc.market.business.quota.MarketQuotaUtils;

@RestController
@RequestMapping("/save/market")
public class SaveMarketController {

	@Autowired
	private MarketQuotaUtils marketQuotaUtils;
	
	/**
	 * 保存所有A股的代码和名称
	 * @return
	 */
	@PostMapping("/astock")
	public boolean saveAllAStockBaseInfo(){
		return marketQuotaUtils.saveAllAStockBaseInfo();
	}
	
	/**
	 * 保存所有国内期货合约的信息
	 * @return
	 */
	@PostMapping("/afutures")
	public boolean saveAllAFuturesBaseInfo(){
		return marketQuotaUtils.saveAllAFuturesBaseInfo();
	}
}
