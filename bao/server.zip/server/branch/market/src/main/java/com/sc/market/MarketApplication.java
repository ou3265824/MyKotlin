package com.sc.market;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.sc.market.frame.config.AppConfig;

@SpringBootApplication
@EnableScheduling
@Import(AppConfig.class)
public class MarketApplication {

	    
	public static void main(String[] args) {
		SpringApplication.run(MarketApplication.class, args);
	}
}
