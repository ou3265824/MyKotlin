package com.sc.market.business.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.market.business.quota.MarketQuotaUtils;

@Service
public class TaskService {

	@Autowired
	private MarketQuotaUtils marketQuotaUtils;
	
	/**
	 * 保存所有A股的代码和名称
	 * @return
	 */
	public boolean saveAllAStockBaseInfo(){
		return marketQuotaUtils.saveAllAStockBaseInfo();
	}
	
	/**
	 * 保存所有国内期货合约的信息
	 * @return
	 */
	public boolean saveAllAFuturesBaseInfo(){
		return marketQuotaUtils.saveAllAFuturesBaseInfo();
	}
}
