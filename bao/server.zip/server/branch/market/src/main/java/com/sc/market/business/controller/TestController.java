package com.sc.market.business.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


/**
 * Created by user on 2017/12/8.
 */
@RestController
@RequestMapping("/test")
public class TestController {
	
	@GetMapping("")
    public boolean test(String no){
		return true;
    }
    
	@GetMapping("/aaa")
    public boolean aaa(String key){
		return true;
    }
}
