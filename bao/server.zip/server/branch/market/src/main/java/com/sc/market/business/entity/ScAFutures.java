package com.sc.market.business.entity;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sc.market.business.base.MarketInfo;

@Entity
@Table(name="S_ZD_GetAllUseContract")
public class ScAFutures extends MarketInfo{

	private String FExchangeNo;//交易所代码
	private String ContractFName;//合约名称
	private BigDecimal FProductDot;//跳点价值
	private BigDecimal FUpperTick;//调点
	private String FExpiryDate;//过期日
	private String FRegDate;//记录更新日期
	private int FDotNum;//小数点位数
	private int FLowerTick;//进阶单位
	@Id
	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	@Column(name="FExchangeNo")
	public String getFExchangeNo() {
		return FExchangeNo;
	}

	public void setFExchangeNo(String fExchangeNo) {
		FExchangeNo = fExchangeNo;
	}

	@Column(name="ContractFName")
	public String getContractFName() {
		return ContractFName;
	}

	public void setContractFName(String contractFName) {
		ContractFName = contractFName;
	}

	@Column(name="FProductDot")
	public BigDecimal getFProductDot() {
		return FProductDot;
	}

	public void setFProductDot(BigDecimal fProductDot) {
		FProductDot = fProductDot;
	}

	@Column(name="FUpperTick")
	public BigDecimal getFUpperTick() {
		return FUpperTick;
	}

	public void setFUpperTick(BigDecimal fUpperTick) {
		FUpperTick = fUpperTick;
	}

	@Column(name="FExpiryDate")
	public String getFExpiryDate() {
		return FExpiryDate;
	}

	public void setFExpiryDate(String fExpiryDate) {
		FExpiryDate = fExpiryDate;
	}

	@Column(name="FRegDate")
	public String getFRegDate() {
		return FRegDate;
	}

	public void setFRegDate(String fRegDate) {
		FRegDate = fRegDate;
	}

	@Column(name="FDotNum")
	public int getFDotNum() {
		return FDotNum;
	}

	public void setFDotNum(int fDotNum) {
		FDotNum = fDotNum;
	}

	@Column(name="FLowerTick")
	public int getFLowerTick() {
		return FLowerTick;
	}

	public void setFLowerTick(int fLowerTick) {
		FLowerTick = fLowerTick;
	}


}
