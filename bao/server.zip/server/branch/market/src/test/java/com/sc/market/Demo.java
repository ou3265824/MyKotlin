package com.sc.market;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.net.URL;
import java.net.URLConnection;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.sc.market.business.entity.ScAStock;
import com.sc.market.common.enums.CommodityTypeEnum;
import com.sc.market.common.utils.StringUtils;
import com.sc.market.common.utils.pinyin.PinyinUtils;


public class Demo {

	static String sendGet(String url)
		{ // 定义一个字符串用来存储网页内容
			String result = "";
			// 定义一个缓冲字符输入流
			BufferedReader in = null;
			try
			{
				// 将string转成url对象
				URL realUrl = new URL(url);
				// 初始化一个链接到那个url的连接
				URLConnection connection = realUrl.openConnection();
				// 开始实际的连接
				connection.connect();
				// 初始化 BufferedReader输入流来读取URL的响应
				in = new BufferedReader(new InputStreamReader(connection.getInputStream(),"gb2312"));
				// 用来临时存储抓取到的每一行的数据
				String line;
				while ((line = in.readLine()) != null)
				{
					// 遍历抓取到的每一行并将其存储到result里面
					result += line;
				}
			} catch (Exception e)
			{
				System.out.println("发送GET请求出现异常！" + e);
				e.printStackTrace();
			} // 使用finally来关闭输入流
			finally
			{
				try
				{
					if (in != null)
					{
						in.close();
					}
				} catch (Exception e2)
				{
					e2.printStackTrace();
				}
			}
			return result;
		}

	static String RegexString(String targetStr, String patternStr)
	{
		// 定义一个样式模板，此中使用正则表达式，括号中是要抓的内容
		// 相当于埋好了陷阱匹配的地方就会掉下去
		Pattern pattern = Pattern.compile(patternStr);
		// 定义一个matcher用来做匹配
		Matcher matcher = pattern.matcher(targetStr);
		// 如果找到了
		if (matcher.find())
		{
			// 打印出结果
			return matcher.group(1);
		}
		return "Nothing";
	}

		public static void main(String[] args) throws IOException
		{
			// 定义即将访问的链接
			String url = "http://quote.eastmoney.com/stocklist.html";
			// 访问链接并获取页面内容
			String result = sendGet(url);
			System.out.println(result);
			Document document = Jsoup.parse(result); 
			//获得文档下所有div标签，返回的是一个标签的集合    
			Elements elements = document.select("a[target=_blank]a[href~=^http://quote.eastmoney.com/s]");    
			//定义一个标签对象    
			Element element=null;    
	        ScAStock sc=new ScAStock();
			//从这一个标签集合中一个一个的取出    
			for (int i = 0; i < elements.size(); i++) {    
			    element= elements.get(i);
			    String href=element.attr("href");
			    String value=element.html();
//			    if(StringUtils.isNotBlank(href) && (href.startsWith("http://quote.eastmoney.com/sh") || href.startsWith("http://quote.eastmoney.com/sz"))){
//			    	System.out.println(href.substring(href.lastIndexOf("/")+1, href.indexOf(".html"))+"==="+value.substring(0, value.indexOf("(")));
//				    bw.write(href.substring(href.lastIndexOf("/")+1, href.indexOf(".html"))+"==="+value.substring(0, value.indexOf("("))) ;  
//		            bw.newLine() ;  
//			    }
			    
			    if(StringUtils.isNotBlank(href) && (href.startsWith("http://quote.eastmoney.com/sh") || href.startsWith("http://quote.eastmoney.com/sz"))){
			    	href=href.substring(href.lastIndexOf("/")+1, href.indexOf(".html"));
			    	value=value.substring(0, value.indexOf("("));
		    		sc.setType(href.substring(0,2));
				    sc.setCode(href.substring(2,href.length()));
				    sc.setName(value);
				    sc.setCommodityType(CommodityTypeEnum.内盘股票.value);
				    sc.setNowPrice(new BigDecimal(0.00));
				    //redis中保存，key为代码+“-”+名称+“-”+“首字母简拼（大写）”，value为实体类的JSON字符串
				    String key=sc.getCode()+"-"+sc.getName()+"-"+PinyinUtils.converterToFirstSpell(value);
				    System.out.println(key);
			    }
			}    
		}
}
