package com.sc.market;

public class Test {
	public static void main(String[] args) {
		System.out.println(Long.parseLong("20171207")>Long.parseLong("20171207"));
	}
}
