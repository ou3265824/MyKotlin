package com.sc.td;

import java.io.IOException;

public class Test {

	public static String test() {

		return "test";
	}
	int i;

	public static void main(String[] args) throws IOException, InterruptedException {
//		ScRelease r1=new ScRelease();
//		r1.setReleaseId(1);
//		r1.setStatus("I");
//		r1.setProfitRate(0.5f);
//		ScRelease r2=new ScRelease();
//		r2.setReleaseId(2);
//		r2.setStatus("D");
//		r2.setProfitRate(0.2f);
//		ScRelease r3=new ScRelease();
//		r3.setReleaseId(3);
//		r3.setStatus("I");
//		r3.setProfitRate(0.4f);
//		ScRelease r4=new ScRelease();
//		r4.setReleaseId(4);
//		r4.setStatus("E");
//		r4.setProfitRate(0.7f);
//		ScRelease r5=new ScRelease();
//		r5.setReleaseId(5);
//		r5.setStatus("I");
//		r5.setProfitRate(0.6f);
//		ScRelease r6=new ScRelease();
//		r6.setReleaseId(6);
//		r6.setStatus("D");
//		r6.setProfitRate(0.5f);
//		ScRelease r7=new ScRelease();
//		r7.setReleaseId(7);
//		r7.setStatus("E");
//		r7.setProfitRate(0.5f);
//		TreeSet<ScRelease> set=Sets.newTreeSet();
//		set.add(r1);
//		set.add(r1);
//		set.add(r2);
//		set.add(r3);
//		set.add(r4);
//		set.add(r5);
//		set.add(r6);
//		set.add(r7);
//		for(ScRelease sc:set){
//			System.out.println(sc.getStatus()+"=="+sc.getProfitRate());
//		}
//		String str="d0J6tHp/tNHR8bzyKQOA6dryUasEgW2jZ8jf6re71vhkMw29pNRylsuUYZX5HhuxmRXIbk/gk6SwioKJPNi1DKHrpTZgFIMw6+YRZ+lJJ+7h61WEcFUZtRhVrmeTsaqAl0pjX89+428ZpPv4YY72O8vuKwHGpWG3c/SmMTmgsmg=";
//		System.out.println(URLEncoder.encode(str,"UTF-8"));
//		
//		JSONObject jb=new JSONObject();
//		jb.put("aaa", "ada");
//		System.out.println(jb.get("aaa"));
//		System.out.println(jb);
//		JSONObject jb1=new JSONObject();
//		jb1.put("test", jb);
//		System.out.println(jb1);
//		JSONObject jb2=new JSONObject();
//		jb2.put("test", jb.toJSONString());
//		System.out.println(jb2);
//		
		
	}
	
}
