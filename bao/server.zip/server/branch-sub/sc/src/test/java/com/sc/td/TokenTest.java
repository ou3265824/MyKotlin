package com.sc.td;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.easemob.token.EasemobTokenCreator;
import com.sc.td.easemob.token.EasemobTokenManager;
import com.sc.td.easemob.util.Easemob4jSettings;

/**
 *
 * @className TokenTest
 * @author jinyu(foxinmy@gmail.com)
 * @date 2015年1月28日
 * @since JDK 1.7
 * @see
 */
public class TokenTest {

	protected EasemobTokenManager tokenHolder;

	@Before
	public void setUp() {
		Easemob4jSettings settings = new Easemob4jSettings();
		tokenHolder = new EasemobTokenManager(new EasemobTokenCreator(
				settings.getAccount()), settings.getCacheStorager0());
	}

	@Test
	public void test() throws EasemobException {
		Assert.assertNotNull(tokenHolder.getCache());
	}
}
