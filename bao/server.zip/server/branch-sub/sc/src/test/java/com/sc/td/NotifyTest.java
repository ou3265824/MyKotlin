package com.sc.td;

import org.junit.Before;
import org.junit.Test;

import com.sc.td.easemob.api.NotifyApi;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.easemob.message.Notify;
import com.sc.td.easemob.message.NotifyMessage;
import com.sc.td.easemob.message.Text;
import com.sc.td.easemob.model.MultSearcher;
import com.sc.td.easemob.type.TargetType;

/**
 * 消息相关测试
 *
 * @className NotifyTest
 * @author jinyu(foxinmy@gmail.com)
 * @date 2015年03月18日
 * @since JDK 1.7
 * @see
 */
public class NotifyTest extends TokenTest {
//	private NotifyApi notifyApi;
//
//	@Before
//	public void init() {
//		notifyApi = new NotifyApi(tokenHolder);
//	}
//
//	@Test
//	public void sendNotify() throws EasemobException {
//		Notify notify = new Text("test...");
//		NotifyMessage message = new NotifyMessage(TargetType.users, notify, "1");
//		message.setFrom("2");
//		System.err.println(notifyApi.sendNotify(message));
//		System.err.println(notifyApi.sendNotify(message));
//	}
//
//	@Test
//	public void getMessages() throws EasemobException {
//		MultSearcher searcher = MultSearcher.custom().build();
//		System.err.println(notifyApi.getMessages(searcher));
//	}
}
