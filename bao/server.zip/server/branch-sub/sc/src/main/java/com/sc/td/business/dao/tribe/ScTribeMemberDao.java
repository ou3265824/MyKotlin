package com.sc.td.business.dao.tribe;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.tribe.ScTribeMember;

public interface ScTribeMemberDao extends BaseDao<ScTribeMember>,SpecificationDao<ScTribeMember> {

	List<ScTribeMember> findByUserIdAndDelFlagOrderByUpdateDateDesc(int userId,String delFlag);
	
	Long countByTribeIdAndDelFlag(int tribeId,String delFlag);
	
	ScTribeMember findByTribeIdAndUserIdAndDelFlag(int tid,int uid,String delFlag);
	
	@Query(value="select t1.tribe_id,t1.user_id,t1.weibo_limit,t1.weibo_comment_limit,t1.del_flag,"
			+ " t1.create_by,t1.create_date,t1.update_by,t1.update_date"
			+ " from sc_tribe_member t1 join sc_tribe_user_role t2 on t1.user_id=t2.user_id "
			+ "join sc_tribe_role t3 on t2.role_id=t3.id where t1.tribe_id=?1 and t3.type=?2",nativeQuery=true)
	List<ScTribeMember> findByTribeIdAndRoleType(int tribeId,String type);
	
	@Query(value="select tribe_id,user_id,weibo_limit,weibo_comment_limit,del_flag,"
			+ " create_by,create_date,update_by,update_date "
			+ "from sc_tribe_member where user_id not in (select t1.user_id from sc_tribe_member t1 "
			+ "join sc_tribe_user_role t2 on t1.user_id=t2.user_id and t1.tribe_id=t2.tribe_id join sc_tribe_role t3 on t2.role_id=t3.id "
			+ "where t1.tribe_id=?1 and (t3.type<>?2 or t3.type<>?3)) and tribe_id=?1",nativeQuery=true)
	List<ScTribeMember> findByTribeIdAndRoleType(int tribeId,String type1,String type2);
}
