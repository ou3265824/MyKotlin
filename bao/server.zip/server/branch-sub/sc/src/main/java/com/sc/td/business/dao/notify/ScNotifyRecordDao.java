package com.sc.td.business.dao.notify;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.notify.ScNotifyRecord;

public interface ScNotifyRecordDao extends BaseDao<ScNotifyRecord>,SpecificationDao<ScNotifyRecord> {
	
	long countByUserIdAndTypeAndReadFlag(int userId,String type,String readFlag); 
	
	List<ScNotifyRecord> findByUserIdAndTypeAndReadFlag(int userId,String type,String readFlag);
	
	@Query(value="select t2.*,t1.status from sc_notify t1,sc_notify_record t2 where t1.id=t2.sc_notify_id "
			+ "and t2.user_id=?1 and t2.type=?2 and t1.status=?3 order by t1.update_date DESC limit ?4,?5",nativeQuery=true)
	List<ScNotifyRecord> findByUserIdAndTypeAndStatusOrderDESC(int userId,String type,String notifyStatus,int index,int size);
}
