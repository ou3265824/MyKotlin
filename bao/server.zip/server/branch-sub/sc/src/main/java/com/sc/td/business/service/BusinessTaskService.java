package com.sc.td.business.service;

import java.util.Map;
import java.util.Map.Entry;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.group.ScGroupMemberDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.group.ScGroupMember;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.easemob.api.GroupApi;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.easemob.model.Group;

@Service
public class BusinessTaskService extends BaseService {

	private static Logger log = LoggerFactory.getLogger(BusinessTaskService.class);

	@Autowired
	private RedisService redisService;

	@Autowired
	private GroupApi groupApi;

	@Autowired
	private ScGroupMemberDao memberDao;

	@Autowired
	private ScUserDao userDao;

	@Autowired
	private ScGroupDao groupDao;

	public void unifyApp2Ease() throws EasemobException {
		// 处理注册失败的环信用户
		Map<String, String> registerMap = redisService.hgetAll(DictEnum.redisRegisterExceptionKey.value);
		if (registerMap != null && registerMap.size() > 0) {
			for (Entry<String, String> entry : registerMap.entrySet()) {
				// key为用户ID，value为用户手机号
				if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())
						&& entry.getKey().indexOf("null") == -1 && entry.getValue().indexOf("null") == -1) {
					// 判断用户是否存在
					ScUser user = userDao.findByUserId(Integer.parseInt(entry.getKey()));
					if (user == null) {
						redisService.hdel(DictEnum.redisRegisterExceptionKey.value, entry.getKey());
						continue;
					}
					try {
						checkEaseUser(user);
						redisService.hdel(DictEnum.redisRegisterExceptionKey.value, entry.getKey());
					} catch (Exception e) {
						log.error(e.getMessage());
					}
				} else {
					redisService.hdel(DictEnum.redisRegisterExceptionKey.value, entry.getKey());
				}
			}
		}

		// 处理创建环信群组失败的用户
		Map<String, String> createMap = redisService.hgetAll(DictEnum.redisCreateExceptionKey.value);
		if (createMap != null && createMap.size() > 0) {
			for (Entry<String, String> entry : createMap.entrySet()) {
				// key为用户ID，value为圈子ID
				if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())
						&& entry.getKey().indexOf("null") == -1 && entry.getValue().indexOf("null") == -1) {
					// 判断用户和圈子是否存在
					ScUser user = userDao.findByUserId(Integer.parseInt(entry.getKey()));
					ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(entry.getValue()),
							DictEnum.not_del.value);
					if (user == null || group == null) {
						redisService.hdel(DictEnum.redisCreateExceptionKey.value, entry.getKey());
						continue;
					}
					// 创建群组
					String easeUserId = redisService.hget(DictEnum.redisAppEaseUserKey.value, entry.getKey());
					try {
						Group easeGroup = easeGroup(group.getGroupName(), easeUserId);
						groupApi.createGroup(easeGroup);
						redisService.hdel(DictEnum.redisCreateExceptionKey.value, entry.getKey());
					} catch (Exception e) {
						log.error(e.getMessage());
					}
				} else {
					redisService.hdel(DictEnum.redisCreateExceptionKey.value, entry.getKey());
				}
			}
		}
		// 同步尚未加入环信群组的用户
		Map<String, String> joinMap = redisService.hgetAll(DictEnum.redisJoinExceptionKey.value);
		if (joinMap != null && joinMap.size() > 0) {
			for (Entry<String, String> entry : joinMap.entrySet()) {
				// key为环信用户ID，value为环信群组ID
				if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())
						&& entry.getKey().indexOf("null") == -1 && entry.getValue().indexOf("null") == -1) {
					// 判断用户和圈子是否存在,以及该用户是否已经在该圈子内
					String userId = redisService.hget(DictEnum.redisEaseAppUserKey.value, entry.getKey());
					String groupId = redisService.hget(DictEnum.redisEaseAppGroupKey.value, entry.getValue());
					ScUser user = userDao.findByUserId(Integer.parseInt(userId));
					ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
					ScGroupMember sc = memberDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId),
							Integer.parseInt(userId), DictEnum.not_del.value);
					if (user == null || group == null || sc != null) {
						redisService.hdel(DictEnum.redisJoinExceptionKey.value, entry.getKey());
						continue;
					}
					// 将该用户加入环信群组
					try {
						groupApi.addGroupMember(entry.getKey(), entry.getValue());
					} catch (Exception e) {
						log.error(e.getMessage());
					} finally {
						redisService.hdel(DictEnum.redisJoinExceptionKey.value, entry.getKey());
					}

				}else{
					redisService.hdel(DictEnum.redisJoinExceptionKey.value, entry.getKey());
				}
			}
		}
		// 同步尚未退出环信群组的用户
		Map<String, String> quitMap = redisService.hgetAll(DictEnum.redisQuitExceptionKey.value);
		if (quitMap != null && quitMap.size() > 0) {
			for (Entry<String, String> entry : quitMap.entrySet()) {
				// key为环信用户ID，value为环信群组ID
				if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())
						&& entry.getKey().indexOf("null") == -1 && entry.getValue().indexOf("null") == -1) {
					// 首先判断该用户是否在APP群内
					String userId = redisService.hget(DictEnum.redisAppEaseUserKey.value, entry.getKey());
					String groupId = redisService.hget(DictEnum.redisAppEaseGroupKey.value, entry.getValue());
					ScGroupMember sc = memberDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId),
							Integer.parseInt(userId), DictEnum.not_del.value);
					ScUser user = userDao.findByUserId(Integer.parseInt(userId));
					if (sc != null || user == null) {
						redisService.hdel(DictEnum.redisQuitExceptionKey.value, entry.getKey());
						continue;
					}
					// 将该用户加入环信群组
					try {
						groupApi.deleteGroupMember(entry.getKey(), entry.getValue());
					} catch (Exception e) {
						log.error(e.getMessage());
					} finally {
						redisService.hdel(DictEnum.redisQuitExceptionKey.value, entry.getKey());
					}

				}else{
					redisService.hdel(DictEnum.redisQuitExceptionKey.value, entry.getKey());
				}
			}
		}
	}
}
