package com.sc.td.business.entity.groupauth;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;

@IdClass(ScGroupRoleAuthPk.class)
@Entity
public class ScGroupRoleAuth {

	private int roleId;
	private int authId;
	
	@Id
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	@Id
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
}
