package com.sc.td.business.dao.tribe;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.tribe.ScTribeRole;

public interface ScTribeRoleDao extends BaseDao<ScTribeRole> {

	List<ScTribeRole> findByType(String type);
}
