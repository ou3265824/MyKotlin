package com.sc.td.business.controller.search;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.sc.td.business.service.search.SearchService;
import com.sc.td.easemob.exception.EasemobException;

@Controller
@RequestMapping("/operate/search")
public class SearchController {

	@Autowired
	private SearchService searchService;
	
	/**
	 * 根据名字搜索圈子或策略
	 * 当type为0时，表示搜索用户加入的圈子及圈子内的策略
	 * 当type为1时，表示只搜索热门的圈子
	 * @param jsonText
	 * @param request
	 * @return
	 * @throws EasemobException
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value="/group/release/{type}/{userId}/{name}",method = {RequestMethod.POST,RequestMethod.GET},produces = "application/json; charset=utf-8")
	@ResponseBody
    public String groupOrRelease(@PathVariable String type,@PathVariable String userId,@PathVariable String name) throws EasemobException, UnsupportedEncodingException{
		return searchService.groupOrRelease(type,userId,URLDecoder.decode(name,"UTF-8"));
	}
	
	/**
	 * 在特定圈子内搜索策略
	 * @param userId 当前操作用户的ID
	 * @param groupId
	 * @param name
	 * @return
	 * @throws EasemobException
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value="/release/{userId}/{groupId}/{name}",method = {RequestMethod.POST,RequestMethod.GET},produces = "application/json; charset=utf-8")
	@ResponseBody
    public String release(@PathVariable String userId,@PathVariable String groupId,@PathVariable String name) throws EasemobException, UnsupportedEncodingException{
		return searchService.release(userId,groupId,URLDecoder.decode(name,"UTF-8"));
	}
	
	/**
	 * 所有圈子中搜索和“我”相关的策略
	 * @param userId
	 * @param name
	 * @return
	 * @throws EasemobException
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value="/release/my/{userId}/{name}",method = {RequestMethod.POST,RequestMethod.GET},produces = "application/json; charset=utf-8")
	@ResponseBody
    public String release(@PathVariable String userId,@PathVariable String name) throws EasemobException, UnsupportedEncodingException{
		return searchService.myRelease(userId,URLDecoder.decode(name,"UTF-8"));
	}
	
	/**
	 * 搜索商品
	 * @param key
	 * @return
	 * @throws EasemobException
	 * @throws UnsupportedEncodingException
	 */
	@RequestMapping(value="/marketInfo/{key}",method = {RequestMethod.POST,RequestMethod.GET},produces = "application/json; charset=utf-8")
	@ResponseBody
    public String marketInfo(@PathVariable String key) throws EasemobException, UnsupportedEncodingException{
		return searchService.marketInfo(URLDecoder.decode(key,"UTF-8"));
	}
}
