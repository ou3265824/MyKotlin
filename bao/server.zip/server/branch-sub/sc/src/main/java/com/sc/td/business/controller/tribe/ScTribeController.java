package com.sc.td.business.controller.tribe;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.tribe.ScTribeService;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.frame.annotation.TribeAuthCheck;

@Controller
@RequestMapping("/operate/tribe")
public class ScTribeController {

	@Autowired
	private ScTribeService tribeService;
	
	/**
	 * 创建部落
	 * @param jsonText
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping(value="/create_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String create(HttpServletRequest request,String jsonText) throws IOException{
		return tribeService.create(request,jsonText);
	}
	
	/**
	 * 上传头像
	 * @param jsonText
	 * @param request
	 * @return
	 * @throws IOException
	 */
	@RequestMapping(value="/uploadImg_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String uploadImg(String jsonText,HttpServletRequest request) throws IOException{
		return tribeService.uploadImg(jsonText, request);
	}
	
	/**
	 * 修改部落信息
	 * @param jsonText
	 * @return
	 * @throws IOException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws EasemobException
	 */
	@RequestMapping(value="/modify_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String modify(String jsonText) throws IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		return tribeService.modify(jsonText);
	}
	
	/**
	 * 根据部落ID获取部落信息
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/find/{tribeId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String tribeById(HttpServletRequest request,@PathVariable String tribeId){
		return tribeService.tribeById(request,tribeId);
	}
	
	/**
	 * 生成邀请码
	 * @param tribeId
	 * @return
	 */
	@RequestMapping(value="/generate/code/{tribeId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@TribeAuthCheck("sc:tribe:generate:code")
    public String generateCode(@PathVariable Integer tribeId,HttpServletRequest request,HttpServletResponse response){
		return tribeService.generateCode(tribeId);
	}
	
	/**
	 * 获取邀请码
	 * @param tribeId
	 * @return
	 */
	@RequestMapping(value="/obtain/code/{tribeId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String obtainCode(@PathVariable Integer tribeId){
		return tribeService.obtainCode(tribeId);
	}
	
	/**
	 * 根据邀请码加入部落
	 * @param userId
	 * @param code
	 * @return
	 */
	@RequestMapping(value="/join/{userId}/{code}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String joinByCode(@PathVariable Integer userId,@PathVariable String code){
		return tribeService.joinByCode(userId, code);
	}
	
	/**
	 * 退出部落
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/quit/{tribeId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String quit(@PathVariable String tribeId,@PathVariable String userId){
		return tribeService.quit(tribeId, userId);
	}
	
	/**
	 * 部落成员
	 * @param tribeId
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/member/{tribeId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String tribeMember(@PathVariable Integer tribeId,@PathVariable String index,@PathVariable String size){
		return tribeService.tribeMember(tribeId, index, size);
	}
	
	/**
	 * “我”加入的部落
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/my/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String my(@PathVariable String userId){
		return tribeService.my(userId);
	}
	
	/**
	 * 所有管理员(非创建者)
	 * @param tribeId
	 * @return
	 */
	@RequestMapping(value="/managers/{tribeId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllManager(@PathVariable Integer tribeId){
		return tribeService.getAllManager(tribeId);
	}
	
	/**
	 * 所有非管理员
	 * @param tribeId
	 * @return
	 */
	@RequestMapping(value="/not/managers/{tribeId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllNotManager(@PathVariable Integer tribeId){
		return tribeService.getAllNotManager(tribeId);
	}
	
	/**
	 * 用户在部落内的权限
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/auth/{tribeId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllUserAuth(@PathVariable Integer tribeId,@PathVariable Integer userId){
		return tribeService.getAllUserAuth(tribeId, userId);
	}
	
	/**
	 * 分配管理员
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/allot/manager/{tribeId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@TribeAuthCheck("sc:tribe:allot:manager")
    public String allotManager(@PathVariable Integer tribeId,@PathVariable Integer userId,HttpServletRequest request,HttpServletResponse response){
		return tribeService.allotManager(tribeId, userId);
	}
	
	/**
	 * 移除管理员
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/remove/manager/{tribeId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@TribeAuthCheck("sc:tribe:remove:manager")
    public String removeManager(@PathVariable Integer tribeId,@PathVariable Integer userId,HttpServletRequest request,HttpServletResponse response){
		return tribeService.removeManager(tribeId, userId);
	}
}
