package com.sc.td.business.entity.tribe;

public enum ScTribeAuthEnum {
	
	weiboPublish("发布微博","sc:weibo:publish"),
	weiboDelete("删除微博","sc:weibo:delete"),
	weiboCommentDelete("删除微博评论","sc:weibo:comment:delete"),
	tribeAllotManager("分配管理员","sc:tribe:allot:manager"),
	tribeRemoveManager("移除管理员","sc:tribe:remove:manager"),
	tribeGenerateCode("生成邀请码","sc:tribe:generate:code");
	
	
	public String desc;
	public String value;
	
	private ScTribeAuthEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	
	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
}
