package com.sc.td.business.dao.tribe;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.tribe.ScTribeUserRole;

public interface ScTribeUserRoleDao extends BaseDao<ScTribeUserRole> {
	
	@Query(value="select t1.tribe_id,t1.user_id,t1.role_id from sc_tribe_user_role t1 join sc_tribe_role t2 on t1.role_id=t2.id "
			+ "where t1.tribe_id=?1 and t1.user_id=?2 and t2.type=?3",nativeQuery=true)
	List<ScTribeUserRole> findByTribeIdAndUserIdAndType(int tribeId,int userId,String type);
	
	@Query(value="select count(t1.user_id) as count from sc_tribe_user_role t1 join sc_tribe_role t2 on t1.role_id=t2.id "
			+ "where t1.tribe_id=?1 and t1.user_id=?2 and t2.type=?3",nativeQuery=true)
	Long countByTribeIdAndUserIdAndType(int tribeId,int userId,String type);
}
