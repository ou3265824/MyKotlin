package com.sc.td.common.qcloud;

import java.util.ArrayList;
import com.qcloud.sms.SmsSingleSender;
import com.qcloud.sms.SmsSingleSenderResult;

public class SmsDemo {
	 public static void main(String[] args) {
	    	try {
	    		//请根据实际 appid 和 appkey 进行开发，以下只作为演示 sdk 使用
	    		int appid = 1400031021;
	    		String appkey = "b2fa2bd80331879c3c0c02cc39fdc4e9";
	    		
	    		String phoneNumber1 = "18721983489";
	    		int tmplId = 22043;

	    		 //初始化单发
		    	SmsSingleSender singleSender = new SmsSingleSender(appid, appkey);
		    	SmsSingleSenderResult singleSenderResult;
		
//		    	 //普通单发
//		    	singleSenderResult = singleSender.send(0, "86", phoneNumber1, "您注册的验证码：1234", "", "");
//		    	System.out.println(singleSenderResult);
		
		    	 //指定模板单发
		    	 //假设短信模板 id 为 1，模板内容为：测试短信，{1}，{2}，{3}，上学。
		    	ArrayList<String> params = new ArrayList<>();
		    	params.add("1234");
		    	singleSenderResult = singleSender.sendWithParam("86", phoneNumber1, tmplId, params, "", "", "");
		    	System.out.println(singleSenderResult);
		    	
	    		
				
	    		
	    	} catch (Exception e) {
				e.printStackTrace();
			}
	    }
}
