package com.sc.td.business.entity.weibo;

import java.io.Serializable;

@SuppressWarnings("serial")
public class WeiboLikePk implements Serializable{

	private int weiboId;
	private int userId;
	public WeiboLikePk() {
	}
	public int getWeiboId() {
		return weiboId;
	}
	public void setWeiboId(int weiboId) {
		this.weiboId = weiboId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + userId;
		result = prime * result + weiboId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WeiboLikePk other = (WeiboLikePk) obj;
		if (userId != other.userId)
			return false;
		if (weiboId != other.weiboId)
			return false;
		return true;
	}
}
