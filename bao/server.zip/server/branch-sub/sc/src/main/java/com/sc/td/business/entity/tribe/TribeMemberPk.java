package com.sc.td.business.entity.tribe;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TribeMemberPk implements Serializable{

	private int tribeId;
	private int userId;
	public TribeMemberPk() {
	}
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + tribeId;
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TribeMemberPk other = (TribeMemberPk) obj;
		if (tribeId != other.tribeId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
	
}
