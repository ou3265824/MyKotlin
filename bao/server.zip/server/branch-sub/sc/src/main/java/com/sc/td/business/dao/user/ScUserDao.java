package com.sc.td.business.dao.user;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.user.ScUser;

@Service("userDao")
public interface ScUserDao extends BaseDao<ScUser> {

	ScUser findByMobileAndPassword(String mobile,String password);
	
	ScUser findByMobile(String mobile);

	ScUser findByUserId(int id);
	
	List<ScUser> findByUserName(String userName);
}
