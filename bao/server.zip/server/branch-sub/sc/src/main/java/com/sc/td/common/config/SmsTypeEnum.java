package com.sc.td.common.config;

public enum SmsTypeEnum {

	login,reg,fgtPwd,resetPwd
}
