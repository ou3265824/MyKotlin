package com.sc.td.business.base;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.group.ScGroupMemberDao;
import com.sc.td.business.dao.groupauth.ScGroupUserRoleDao;
import com.sc.td.business.dao.notify.ScNotifyRecordDao;
import com.sc.td.business.dao.release.ScReleaseDao;
import com.sc.td.business.dao.release.ScReleaseDetailsDao;
import com.sc.td.business.dao.release.ScReleaseUserDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.group.ScGroupMember;
import com.sc.td.business.entity.money.ScMoney;
import com.sc.td.business.entity.notify.ScNotify;
import com.sc.td.business.entity.notify.ScNotifyRecord;
import com.sc.td.business.entity.release.ScRelease;
import com.sc.td.business.entity.release.ScReleaseDetails;
import com.sc.td.business.entity.release.ScReleaseUser;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.CommodityTypeEnum;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.Global;
import com.sc.td.common.config.MsgEnum;
import com.sc.td.common.config.SystemConfig;
import com.sc.td.common.quota.QuotaUtils;
import com.sc.td.common.utils.IdGen;
import com.sc.td.common.utils.PinyinUtils;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.encrypt.Des3Encrypt;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.jwt.Jwt;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.easemob.api.ApiResult;
import com.sc.td.easemob.api.GroupApi;
import com.sc.td.easemob.api.UserApi;
import com.sc.td.easemob.model.Group;
import com.sc.td.easemob.model.User;

@Service
public class BaseService {

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScNotifyRecordDao scNotifyRecordDao;

	@Autowired
	private ScReleaseDao releaseDao;

	@Autowired
	private ScReleaseUserDao releaseUserDao;

	@Autowired
	private ScReleaseDetailsDao releaseDetailsDao;
	
	@Autowired
	private ScGroupDao groupDao;

	@Autowired
	private ScGroupMemberDao groupMemberDao;

	@Autowired
	private ScUserDao userDao;

	@Autowired
	private UserApi userApi;

	@Autowired
	private GroupApi groupApi;

	@Autowired
	private ScGroupUserRoleDao groupUserRoleDao;

	@Autowired
	private SystemConfig sysCfg;
	
	/**
	 * 拉取行情计算单个策略收益
	 * 
	 * @return
	 */
	@Transactional
	public boolean calcProfit(ScRelease release) {
		String key = null;
		List<ScReleaseDetails> detailsList = Lists.newArrayList();
		if (release != null && StringUtils.isNotBlank(release.getStatus())
				&& release.getStatus().equals(DictEnum.ing.value)
				&& release.getCollectMoney().compareTo(new BigDecimal(0.00)) > 0) {
			List<String> hisProfitRateList = Lists.newArrayList();
			BigDecimal totalProfit = new BigDecimal(0.00);
			BigDecimal close_totalProfit = new BigDecimal(0.00);
			detailsList = releaseDetailsDao.findByReleaseId(release.getReleaseId());
			// 更新策略中商品的价格和收益
			if (detailsList != null && detailsList.size() > 0) {
				for (ScReleaseDetails details : detailsList) {
					if (StringUtils.isNotBlank(details.getCloseFlag())
							&& details.getCloseFlag().equals(DictEnum.close.value)) {
						close_totalProfit = close_totalProfit.add(details.getProfit());
						continue;
					}
					if (details.getCostPrice().compareTo(new BigDecimal(0.00)) == 0) {
						continue;
					}
					// 根据商品code查找该商品是否在redis中存在
					key = DictEnum.redis_market_prefix.value + "-" + details.getCode() + "-" + details.getName() + "-"
							+ PinyinUtils.converterToFirstSpell(details.getName());
					BigDecimal profit = details.getProfit();
					float profitRate = details.getProfitRate();
					if (redisService.exists(key)) {
						BigDecimal nowPrice = new BigDecimal(0.00);
						// 判断是股票还是期货
						if (details.getType().equals(CommodityTypeEnum.内盘期货.value)) {
							ScAFutures futures = JacksonUtil.jsonToObj(String.valueOf(redisService.get(key)),
									ScAFutures.class);
							nowPrice = QuotaUtils.getNowPrice(futures.getCode(), CommodityTypeEnum.内盘期货.value);
							profit = (nowPrice.subtract(details.getCostPrice())).divide(futures.getFUpperTick())
									.multiply(new BigDecimal(futures.getFLowerTick())
											.divide(new BigDecimal(Math.pow(10.0, futures.getFDotNum()))))
									.multiply(futures.getFProductDot()).multiply(new BigDecimal(details.getVolume()))
									.multiply(new BigDecimal(buysell(details.getDirect())));
						} else if (details.getType().equals(CommodityTypeEnum.内盘股票.value)) {
							ScAStock stock = JacksonUtil.jsonToObj(String.valueOf(redisService.get(key)),
									ScAStock.class);
							nowPrice = QuotaUtils.getNowPrice(stock.getType() + stock.getCode(),
									CommodityTypeEnum.内盘股票.value);
							profit = (nowPrice.subtract(details.getCostPrice()))
									.multiply(new BigDecimal(details.getVolume()));
						}
						profit = profit.setScale(2, BigDecimal.ROUND_FLOOR);
						profitRate = profit.divide(details.getTotalCost(), 4, BigDecimal.ROUND_FLOOR).floatValue();
						details.setNowPrice(nowPrice);
						details.setProfit(profit);
						details.setProfitRate(profitRate);
						details.setUpdateValue(details, String.valueOf(release.getUserId()));
						totalProfit = totalProfit.add(profit);
					}
				}
				totalProfit = totalProfit.add(close_totalProfit);
				release.setDetails(detailsList);
				release.setProfit(totalProfit);
				release.setProfitRate(
						totalProfit.divide(release.getCollectMoney(), 4, BigDecimal.ROUND_FLOOR).floatValue());
				// 设置历史收益率
				String day = TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat);
				if (release.getHisProfitRate().indexOf(day) == -1) {
					release.setHisProfitRate(release.getHisProfitRate() + "," + day + "@@" + release.getProfitRate());
				} else {
					String[] arr = release.getHisProfitRate().split(",");
					for (int i = 0; i < arr.length; i++) {
						if (arr[i].indexOf(day) != -1) {
							arr[i] = arr[i].split("@@")[0] + "@@" + release.getProfitRate();
						}
						hisProfitRateList.add(arr[i]);
					}
					release.setHisProfitRate(Joiner.on(",").join(hisProfitRateList));
				}
				release.setUpdateValue(release, String.valueOf(release.getUserId()));
				releaseDao.save(release);
				// 计算每个人的收益
				calcUserProfit(release);
			}
		}
		return true;
	}

	// 计算每个人的收益
	public void calcUserProfit(ScRelease release) {
		List<ScReleaseUser> list = releaseUserDao.findByReleaseIdAndDelFlag(release.getReleaseId(),
				DictEnum.not_del.value);
		if (list != null && list.size() > 0) {
			for (ScReleaseUser sc : list) {
				// 更新每个验证者的收益
				BigDecimal rate = sc.getAmount().divide(release.getCollectMoney(), 10, BigDecimal.ROUND_FLOOR);
				sc.setProfit(rate.multiply(release.getProfit()).setScale(2, BigDecimal.ROUND_FLOOR));
				releaseUserDao.save(sc);
			}
		}
	}

	/**
	 * 根据买卖方向获取计算的乘数因子 买1 卖-1 用于计算收益（当前价-成本价）
	 * 
	 * @param type
	 * @return
	 */
	public int buysell(String type) {
		if (StringUtils.isNotBlank(type) && type.equals(DictEnum.sell.value)) {
			return -1;
		}
		return 1;
	}

	/**
	 * 新建出入金记录，并设置公共属性（不包含金额money、备注） 出入金状态默认为接受
	 * 
	 * @param scUser
	 */
	public ScMoney setInitScMoney(ScUser scUser) {
		ScMoney scMoney = new ScMoney();
		scMoney.setId(IdGen.uuid());
		scMoney.setUserId(scUser.getUserId());
		scMoney.setApplyTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
		scMoney.setAcceptTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
		scMoney.setApplyUserName(scUser.getUserName());
		scMoney.setAcceptUserName(scUser.getUserName());
		scMoney.setAcceptStatus("1");
		scMoney.setInitValue(scMoney, String.valueOf(scUser.getUserId()));
		return scMoney;
	}

	/**
	 * 创建token
	 * 
	 * @param scUser
	 * @return
	 */
	public String createToken(ScUser scUser) {
		String token = "";
		ConcurrentHashMap<String, Object> payload = new ConcurrentHashMap<String, Object>();
		Date date = new Date();
		payload.put("userId", scUser.getUserId());// 用户id
		payload.put("mobile", scUser.getMobile());// 用户手机号
		payload.put("iat", date.getTime());// 生成时间:当前
		if ("1".equals(Global.token_expire)) {
			payload.put("ext", date.getTime() + Integer.parseInt(Global.token_expire_long) * 1000 * 60 * 60);// 过期时间2小时
		}
		token = Jwt.createToken(payload);
		redisService.hset("token", scUser.getMobile(), token);
		return token;
	}

	/**
	 * 创建环信群组 500人的群
	 * 
	 * @return
	 */
	public Group easeGroup(String groupName, String owner) {
		Group group = new Group();
		group.setAllowInvites(true);
		group.setDesc("create group");
		group.setGroupName(groupName);
		group.setMaxUsers(500);
		group.setMembersOnly(true);
		group.setOwner(owner);
		group.setPublic(true);
		return group;
	}

	/**
	 * 创建环信用户
	 * 
	 * @param scUser
	 * @return
	 * @throws Exception
	 */
	public ScUser checkEaseUser(ScUser scUser) throws Exception {
		// 首先判断该用户是否已经在环信中注册
		boolean b = false;
		try {
			ApiResult easeUserResult = userApi.getUser(scUser.getMobile());
			if (easeUserResult != null && easeUserResult.getStatusCode() == 0) {
				b = true;
				redisService.hset(DictEnum.redisEaseAppUserKey.value,
						String.valueOf(easeUserResult.getEntities().get(0).getString("username")),
						String.valueOf(scUser.getUserId()));
				redisService.hset(DictEnum.redisAppEaseUserKey.value, String.valueOf(scUser.getUserId()),
						String.valueOf(easeUserResult.getEntities().get(0).getString("username")));
				scUser.setEaseName(String.valueOf(easeUserResult.getEntities().get(0).getString("username")));
				scUser.setEasePassword(Des3Encrypt.encode(scUser.getMobile()));
			}
		} catch (Exception e) {
			b = false;
		}
		if (!b) {
			try {
				// 创建一个环信的用户
				// 以手机号作为名称和密码
				User easeUser = new User(scUser.getMobile(), Des3Encrypt.encode(scUser.getMobile()),
						getUserName(scUser));
				ApiResult result = userApi.createUser(easeUser);
				if (result.getStatusCode() == 0) {
					// 将环信的用户名和APP用户ID绑定
					redisService.hset(DictEnum.redisEaseAppUserKey.value,
							String.valueOf(result.getEntities().get(0).getString("username")),
							String.valueOf(scUser.getUserId()));
					redisService.hset(DictEnum.redisAppEaseUserKey.value, String.valueOf(scUser.getUserId()),
							String.valueOf(result.getEntities().get(0).getString("username")));
					scUser.setEaseName(String.valueOf(result.getEntities().get(0).getString("username")));
					scUser.setEasePassword(Des3Encrypt.encode(scUser.getMobile()));
				}
			} catch (Exception e) {
				redisService.hset(DictEnum.redisRegisterExceptionKey.value, String.valueOf(scUser.getUserId()),
						scUser.getMobile());
			}
		}
		return scUser;
	}

	/**
	 * 创建环信群组
	 * 
	 * @param group
	 * @return
	 */
	public ScGroup checkEaseGroup(ScGroup group) {
		String easeGId = redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(group.getGroupId()));
		if (StringUtils.isBlank(easeGId)) {
			/*
			 * 创建环信群聊 （1）首先通过APP的用户ID找到对应的环信用户名 （2）创建环信群聊，成功后绑定APP的圈子ID和环信的群聊ID
			 */
			try {
				String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value,
						String.valueOf(group.getUserId()));
				ScUser user = userDao.findByUserId(group.getUserId());
				if (StringUtils.isBlank(easeUserName)) {
					redisService.hset(DictEnum.redisRegisterExceptionKey.value, String.valueOf(user.getUserId()),
							user.getMobile());
				} else {
					Group easeGroup = easeGroup(group.getGroupName(), easeUserName);
					ApiResult createGroup = groupApi.createGroup(easeGroup);
					if (createGroup != null && createGroup.getData() != null) {
						String easeGroupId = (String) createGroup.getData().get("groupid");
						if (StringUtils.isNotBlank(easeGroupId)) {
							redisService.hset(DictEnum.redisEaseAppGroupKey.value, easeGroupId,
									String.valueOf(group.getGroupId()));
							redisService.hset(DictEnum.redisAppEaseGroupKey.value, String.valueOf(group.getGroupId()),
									easeGroupId);
							group.setEaseGroupId(easeGroupId);
						}
					} else {
						redisService.hset(DictEnum.redisCreateExceptionKey.value, String.valueOf(group.getUserId()),
								String.valueOf(group.getGroupId()));
					}
				}
			} catch (Exception e) {
				redisService.hset(DictEnum.redisCreateExceptionKey.value, String.valueOf(group.getUserId()),
						String.valueOf(group.getGroupId()));
			}
		} else {
			group.setEaseGroupId(easeGId);
		}
		return group;
	}

	/**
	 * 接口中checkToken配合锁，防止多并发插入多条相同数据
	 * 
	 * @param token
	 * @param mobile
	 * @return
	 */
	public boolean checkToken(String token, String mobile) {
		boolean b = false;
		// 判断token在redis中是否存在
		String token_old = redisService.hget("token", mobile);
		if (StringUtils.isNotBlank(token) && StringUtils.isNotBlank(token_old) && token.equals(token_old)) {
			b = true;
		}
		return b;
	}

	/**
	 * 获取页面的index和size
	 * 
	 * @param index
	 * @param size
	 */
	public PageInfo getPageIndexAndSize(String index, String size) {
		PageInfo page = new PageInfo(PageInfo.index, PageInfo.pageno, PageInfo.size);
		page.set_pageno(PageInfo.getPageNo(index));
		page.set_size(PageInfo.getSize(size));
		return page;
	}

	/**
	 * 查詢数据库的sql中的index和size
	 * 
	 * @param index
	 * @param size
	 */
	public PageInfo getSQLIndexAndSize(String index, String size) {
		PageInfo page = new PageInfo(PageInfo.index, PageInfo.pageno, PageInfo.size);
		page.set_index(PageInfo.getIndex(Integer.parseInt(index), Integer.parseInt(size)));
		page.set_size(PageInfo.getSize(size));
		return page;
	}

	/**
	 * 获取用户头像的完整访问路径 用户头像以用户手机号命名
	 * 
	 * @param user
	 * @return
	 */
	public String getUserImagePath(String picName) {
		String time = redisService.hget(DictEnum.redisUserImageTimestamp.value, picName);
		String path = sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/images/" + picName + DictEnum.picFormat.value + "?" + time;
		return path;
	}

	/**
	 * 获取圈子头像的访问路径
	 * 
	 * @return
	 */
	public String getGroupImagePath() {
		return sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder() + "/group/";
	}

	/**
	 * 获取圈子头像的访问路径(带图片名)
	 * 
	 * @return
	 */
	public String getGroupImagePath(String picName) {
		String time = redisService.hget(DictEnum.redisGroupImageTimestampKey.value, picName);
		String path = sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/group/" + picName + DictEnum.picFormat.value + "?" + time;
		return path;
	}

	/**
	 * 获取示例圈子头像的访问路径
	 * 
	 * @return
	 */
	public String getExampleGroupImagePath() {
		return sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/group/example/";
	}

	/**
	 * 获取示例圈子头像的访问路径(带图片名)
	 * 
	 * @return
	 */
	public String getExampleGroupImagePath(String picName) {
		String time = redisService.hget(DictEnum.redisExampleGroupImageTimestampKey.value, picName);
		String path = sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/group/example/" + picName + DictEnum.picFormat.value + "?" + time;
		return path;
	}

	/**
	 * 获取部落头像的访问路径(带图片名)
	 * 
	 * @return
	 */
	public String getTribeImagePath(String picName) {
		String time = redisService.hget(DictEnum.redisTribeImageTimestampKey.value, picName);
		String path = sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/tribe/" + picName + DictEnum.picFormat.value + "?" + time;
		return path;
	}
	
	
	/**
	 * 获取微博图片的访问路径(带图片名)
	 * 
	 * @return
	 */
	public String getWeiboImagePath(String dir,String picName) {
		String path = sysCfg.getProtocol() + sysCfg.getNginx_path() + sysCfg.getNginx_project_folder() + sysCfg.getNginx_user_folder()
				+ "/weibo/" + dir + "/" + picName;
		return path;
	}
	
	
	/**
	 * 获取用户名 当用户名为空时默认为“user”+手机号
	 * 
	 * @param user
	 * @return
	 */
	public String getUserName(ScUser user) {
		if (user != null) {
			String name = "oct" + String.format("%05d", user.getUserId()) + "v";
			return StringUtils.isBlank(user.getUserName()) ? name : user.getUserName();
		}
		return null;
	}

	/**
	 * 创建消息
	 * 
	 * @param userId
	 * @param title
	 * @param content
	 */
	public void createNotify(String userId, String type, String title, String content) {
		ScNotify sc = new ScNotify();
		sc.setId(IdGen.uuid());
		sc.setTitle(title);
		sc.setContent(content);
		sc.setInitValue(sc, userId);
		sc.setStatus(MsgEnum.publish.value);
		ScNotifyRecord scNotifyRecord = new ScNotifyRecord();
		scNotifyRecord.setId(IdGen.uuid());
		scNotifyRecord.setScNotify(sc);
		scNotifyRecord.setType(type);
		scNotifyRecord.setUserId(Integer.parseInt(userId));
		scNotifyRecord.setReadFlag(MsgEnum.not_read.value);
		scNotifyRecordDao.save(scNotifyRecord);
	}

	/**
	 * 判断策略是否和该客户有关
	 * 
	 * @param releaseId
	 * @param userId
	 * @param groupId
	 * @return
	 */
	public boolean checkRel(int releaseId, int userId, int groupId) {
		// 首先为验证的策略
		Long count = releaseUserDao.countByReleaseIdAndUserIdAndGroupIdAndDelFlagAndAmountGreaterThan(releaseId, userId,
				groupId, DictEnum.not_del.value, new BigDecimal(0.00));
		// 发布的策略
		Long count2 = releaseDao.countByReleaseIdAndUserIdAndGroupIdAndDelFlag(releaseId, userId, groupId,
				DictEnum.not_del.value);
		// 是否管理员
		Long countAdmin = groupUserRoleDao.countByGroupIdAndUserIdAndType(groupId, userId, DictEnum.admin.value);
		Long countManager = groupUserRoleDao.countByGroupIdAndUserIdAndType(groupId, userId, DictEnum.manager.value);
		//是否策略提出人
		Long countProducer=releaseDao.countByReleaseIdAndProducerAndDelFlag(releaseId, userId, DictEnum.not_del.value);
		if (count > 0 || count2 > 0 || countAdmin > 0 || countManager > 0 || countProducer>0) {
			return true;
		}
		return false;
	}

	/**
	 * 处理策略数据的返回形式（加上圈子图片、名称、创建人）
	 * 
	 * @param dataList
	 * @return
	 */
	public TreeSet<ScRelease> handlerReturnData(TreeSet<ScRelease> set, int userId) {
		if (set != null && set.size() > 0) {
			for (ScRelease sc : set) {
				sc = getProducerInfo(sc);
				ScGroup group = groupDao.findByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value);
				if (group != null) {
					sc.setGroupImage(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
					sc.setGroupName(group.getGroupName());
				}
				ScUser user = userDao.findByUserId(sc.getUserId());// 策略发布人
				if (user != null) {
					sc.setUserName(getUserName(user));
					sc.setUserImage(getUserImagePath(user.getMobile()));
				}
				ScUser producer = userDao.findByUserId(sc.getProducer());// 策略提出人
				if (producer != null) {
					sc.setProducerName(producer.getUserName());
					sc.setProducerImage(getUserImagePath(producer.getMobile()));
				}
				if (checkRel(sc.getReleaseId(), userId, group.getGroupId())) {
					sc.setRel(true);
				} else {
					sc.setRel(false);
				}
			}
		}
		return set;
	}

	/**
	 * 处理策略数据的返回形式（加上圈子图片、名称、创建人） 只针对和用户相关的策略
	 * 
	 * @param dataList
	 * @return
	 */
	public TreeSet<ScRelease> handlerReturnDataMy(TreeSet<ScRelease> set, int userId) {
		if (set != null && set.size() > 0) {
			Iterator<ScRelease> it = set.iterator();
			while (it.hasNext()) {
				ScRelease sc = it.next();
				sc = getProducerInfo(sc);
				ScGroup group = groupDao.findByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value);
				if (group != null) {
					sc.setGroupImage(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
					sc.setGroupName(group.getGroupName());
				}
				ScUser user = userDao.findByUserId(sc.getUserId());// 策略发布人
				if (user != null) {
					sc.setUserName(getUserName(user));
					sc.setUserImage(getUserImagePath(user.getMobile()));
				}
				ScUser producer = userDao.findByUserId(sc.getProducer());// 策略提出人
				if (producer != null) {
					sc.setProducerName(producer.getUserName());
					sc.setProducerImage(getUserImagePath(producer.getMobile()));
				}
				if (checkRel(sc.getReleaseId(), userId, group.getGroupId())) {
					sc.setRel(true);
				} else {
					it.remove();
				}
			}
		}
		return set;
	}

	/**
	 * 获取策略发起人名称
	 * 
	 * @param release
	 * @return
	 */
	public ScRelease getProducerInfo(ScRelease release) {
		if (release != null) {
			ScUser user = userDao.findByUserId(release.getProducer());
			if (user != null) {
				release.setProducerName(getUserName(user));
				release.setProducerImage(getUserImagePath(user.getMobile()));
			}
		}
		return release;
	}

	/**
	 * 将首字母大写
	 * 
	 * @param key
	 * @return
	 */
	public String toUpperKey(String key) {
		if (StringUtils.isNotBlank(key)) {
			key = key.substring(0, 1).toUpperCase() + key.substring(1, key.length());
			return key;
		}
		return null;
	}

	/**
	 * 判断用户是否加入圈子
	 * 
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public boolean checkInGroup(int groupId, int userId) {
		ScGroupMember groupMember = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(groupId, userId,
				DictEnum.not_del.value);
		if (groupMember != null) {
			return true;
		}
		return false;
	}

	/**
	 * 设置系统消息的数据体
	 * 
	 * @param imgPath
	 * @param title
	 * @param content
	 * @param time
	 * @return
	 */
	public String setSysContent(String imgPath, String title, String content, String time) {
		Map<String, String> map = Maps.newHashMap();
		map.put("imgPath", imgPath);
		map.put("title", title);
		map.put("content", content);
		map.put("time", time);
		return JacksonUtil.objToJson(map);
	}

	@SuppressWarnings("unchecked")
	public ScUser userByToken(HttpServletRequest request){
		try {
			String token = request.getHeader("token");
			Map<String, Object> resultMap = Jwt.validToken(token);
			Map<String, String> dataMap = new HashMap<String, String>();
			dataMap = (HashMap<String, String>) resultMap.get("data");
			String mobile = dataMap.get("mobile");
			ScUser user=userDao.findByMobile(mobile);
			return user;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
