package com.sc.td.business.base;

import java.math.BigDecimal;

public class MarketInfo {

	protected String code;//代码
	private BigDecimal nowPrice;//最新价
	private String commodityType;//内外盘标志
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public BigDecimal getNowPrice() {
		return nowPrice;
	}
	public void setNowPrice(BigDecimal nowPrice) {
		this.nowPrice = nowPrice;
	}
	public String getCommodityType() {
		return commodityType;
	}
	public void setCommodityType(String commodityType) {
		this.commodityType = commodityType;
	}
	
	
}
