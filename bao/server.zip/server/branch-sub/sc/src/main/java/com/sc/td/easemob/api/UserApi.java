package com.sc.td.easemob.api;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Maps;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.easemob.model.User;

@Service("userApi")
public class UserApi extends BaseApi {

	/**
	 * 创建用户
	 *
	 * @param user
	 *            单个或者多个用户
	 * @return 操作结果
	 * @see <a
	 *      href="http://www.easemob.com/docs/rest/userapi/#im">创建单个或者多个用户</a>
	 * @throws EasemobException
	 */
	public ApiResult createUser(User... user) throws EasemobException {
		String create_user_url = getRequestUri0("create_user_url");
		JSONObject response = post(create_user_url, JSON.toJSONString(user));
		return JSON.toJavaObject(response, ApiResult.class);
	}

	
	/**
	 * 获取环信用户信息
	 * @param username
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult getUser(String username) throws EasemobException {
		String create_user_url = getRequestUri1("operate_user_url",username);
		JSONObject response = get(create_user_url, null);
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	
	/**
	 * 修改用户昵称
	 * @param user
	 * @param nickName
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult modifyNickName(String username,String nickName) throws EasemobException {
		String create_user_url = getRequestUri1("operate_user_url",username);
		Map<String,String> map=Maps.newHashMap();
		map.put("nickname", nickName);
		JSONObject response = post(create_user_url, JSON.toJSONString(map));
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	/**
	 * 添加好友
	 *
	 * @param ownerName
	 *            我的昵称
	 * @param friendName
	 *            好友昵称
	 * @return 操作结果
	 * @see <a
	 *      href="http://www.easemob.com/docs/rest/userapi/#contactsfriend">添加好友</a>
	 * @throws EasemobException
	 */
	public ApiResult contactFriend(String ownerName, String friendName)
			throws EasemobException {
		String contact_friend_url = getRequestUri1("contact_friend_url",
				ownerName, friendName);
		JSONObject response = post(contact_friend_url, null);
		return JSON.toJavaObject(response, ApiResult.class);
	}
}
