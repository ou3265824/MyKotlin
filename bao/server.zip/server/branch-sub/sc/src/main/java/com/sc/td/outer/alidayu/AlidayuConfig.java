package com.sc.td.outer.alidayu;


public class AlidayuConfig {
	public static final String url="http://gw.api.taobao.com/router/rest";
	public static final String appkey="23817838";
	public static final String secret="d4fa8e6c9b0c9f3f88a14dc1b29a70f0";
	public static final String smsType="normal";
	public static final String successKey="alibaba_aliqin_fc_sms_num_send_response";
	public static final String errorKey="error_response";
	public static final String successCode="0";
	
}
