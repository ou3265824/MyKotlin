package com.sc.td.business.controller.notify;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.sc.td.business.service.notify.ScNotifyService;

@Controller
@RequestMapping("/operate/notify")
public class ScNotifyController {

	@Autowired
	private ScNotifyService scNotifyService;
	
	/**
	 * 根据userId获取系统消息和验证消息的个数
	 */
	@RequestMapping(value = "/user/{userId}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String getCount(@PathVariable Integer userId) {
		return scNotifyService.getCount(userId);
	}
	
	/**
	 * 根据userID获取验证消息
	 * @param jsonText
	 * @return
	 */
	@RequestMapping(value = "/user/check/{userId}/{index}/{size}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String joinApplyNotify(@PathVariable Integer userId,@PathVariable String index,@PathVariable String size) {
		return scNotifyService.joinApplyNotify(userId,index,size);
	}
	
	/**
	 * 根据userId和消息类型获取消息
	 * @param userId
	 * @param type
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value = "/user/type/{userId}/{type}/{index}/{size}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String getNotifyInfo(@PathVariable Integer userId,@PathVariable String type,@PathVariable String index,@PathVariable String size) {
		return scNotifyService.getNotifyInfo(userId,type,index,size);
	}
}
