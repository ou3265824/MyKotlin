package com.sc.td.common.utils;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.zip.GZIPInputStream;

public class FileUtils extends org.apache.commons.io.FileUtils{

	/**
	 * 获取文件个数
	 * @param path
	 * @return
	 */
	public static int countFile(String path){
		int fileCount = 0;  
		File d = new File(path);  
		File list[] = d.listFiles();  
		for(int i = 0; i < list.length; i++){  
		    if(list[i].isFile()){  
		        fileCount++;  
		    }
		}  
		return fileCount;
	}
	
	/**
	 * 解压gz文件
	 * @param sourcedir
	 */
	public static void unGzipFile(String sourcedir) {
	    String ouputfile = "";
	    try {  
	        //建立gzip压缩文件输入流 
	        FileInputStream fin = new FileInputStream(sourcedir);   
	        //建立gzip解压工作流
	        GZIPInputStream gzin = new GZIPInputStream(fin);   
	        //建立解压文件输出流  
	        ouputfile = sourcedir.substring(0,sourcedir.lastIndexOf('.'));
	        FileOutputStream fout = new FileOutputStream(ouputfile);   
	        int num;
	        byte[] buf=new byte[1024];

	        while ((num = gzin.read(buf,0,buf.length)) != -1)
	        {   
	            fout.write(buf,0,num);   
	        }

	        gzin.close();   
	        fout.close();   
	        fin.close();   
	    } catch (Exception ex){  
	        System.err.println(ex.toString());  
	    }  
	    return;
	}  
	
	/**
	 * 网络下载文件
	 * @param fileUrl
	 * @param fileLocal
	 * @throws Exception
	 */
	public static void downloadFile(String fileUrl,String fileLocal) throws Exception {
	     URL url = new URL(fileUrl);
	     HttpURLConnection urlCon = (HttpURLConnection) url.openConnection();
	     urlCon.setConnectTimeout(6000);
	     urlCon.setReadTimeout(6000);
	     int code = urlCon.getResponseCode();
	     if (code != HttpURLConnection.HTTP_OK) {
	    	 throw new Exception("文件读取失败");
	     }
	     //读文件流
	     DataInputStream in = new DataInputStream(urlCon.getInputStream());
	     DataOutputStream out = new DataOutputStream(new FileOutputStream(fileLocal));
	     byte[] buffer = new byte[2048];
	     int count = 0;
	     while ((count = in.read(buffer)) > 0) {
	    	 out.write(buffer, 0, count);
	     }
	     out.close();
	     in.close();
	}
}
