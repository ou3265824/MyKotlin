package com.sc.td.common.config;

public enum FileFormatEnum {

	AVI
}
