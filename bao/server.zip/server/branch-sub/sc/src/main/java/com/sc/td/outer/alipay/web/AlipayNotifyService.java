package com.sc.td.outer.alipay.web;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.DecimalFormat;
import java.util.Map;
import javax.transaction.Transactional;
import org.dom4j.DocumentException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.alipay.api.AlipayApiException;
import com.alipay.api.internal.util.AlipaySignature;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.money.ScMoneyDao;
import com.sc.td.business.dao.order.ScOrderDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.money.ScMoney;
import com.sc.td.business.entity.order.ScOrder;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.IdGen;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.outer.alipay.config.AlipayConfig;
import com.sc.td.outer.alipay.core.AlipaySubmit;
import com.sc.td.outer.alipay.core.Trade;
import com.sc.td.outer.alipay.core.TradeStatus;

@Service
public class AlipayNotifyService extends BaseService{
	
	private static final Logger log=LoggerFactory.getLogger(AlipayNotifyService.class);
	
	@Autowired
	private ScUserDao userDao;
	
	@Autowired
	private ScMoneyDao moneyDao;
	
	@Autowired
	private ScOrderDao orderDao;
	
	/**
	 * 客户端请求
	 * @param jsonText
	 * @return
	 * @throws MalformedURLException
	 * @throws DocumentException
	 * @throws IOException
	 * @throws AlipayApiException 
	 */
	@Transactional
	public String request(String jsonText) throws MalformedURLException, DocumentException, IOException, AlipayApiException {
		Trade trade = JacksonUtil.jsonToObj(jsonText, Trade.class);
		DecimalFormat df = new DecimalFormat("#.##");
		if (trade != null && StringUtils.isNotBlank(trade.getTotal_amount())) {
			ScUser scUser=userDao.findByUserId(trade.getUserId());
			if(scUser==null){
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			String total_amount = trade.getTotal_amount();
			String outTradeNo=IdGen.uuid();
			trade.setTotal_amount(df.format(Double.parseDouble(total_amount)));
			trade.setOut_trade_no(outTradeNo);
			Map<String, String> map = AlipaySubmit.buildParamsMap(trade);
			//创建一个订单
			ScOrder sc=new ScOrder();
			sc.setOut_trade_no(outTradeNo);
			sc.setSeller_id(AlipayConfig.seller_id);
			sc.setApp_id(AlipayConfig.app_id);
			sc.setUser_id(trade.getUserId());
			sc.setTrade_status(TradeStatus.WAIT_BUYER_PAY.name());
			sc.setSubject(trade.getSubject());
			sc.setTotal_amount(df.format(Double.parseDouble(total_amount)));
			sc.setInitValue(sc, String.valueOf(trade.getUserId()));
			orderDao.save(sc);
			return CreateJson.createObjJson(map, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 支付宝异步通知
	 * @param request
	 * @param response
	 * @return
	 * @throws AlipayApiException
	 * @throws IOException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 */
	@Transactional
	public synchronized String notify(Map<String, String> params) throws AlipayApiException,
			IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		String result = "";
		boolean signVerified = AlipaySignature.rsaCheckV1(params, AlipayConfig.alipay_public_key, AlipayConfig.charset); // 调用SDK验证签名
		if (signVerified) {
			// 验签成功后
			log.info("验签成功!");
			// 1、验证该通知数据中的out_trade_no是否为商户系统中创建的订单号
			// 2、判断total_amount是否确实为该订单的实际金额（即商户订单创建时的金额）
			// 3、校验通知中的seller_id（或者seller_email) 是否为out_trade_no这笔单据的对应的操作方
			// 4、验证app_id是否为该商户本身
			ScOrder scOrder = new ScOrder();
			synchronized (scOrder) {
				Class<ScOrder> clazz = ScOrder.class;
				Method[] methods = clazz.getMethods();
				for (Map.Entry<String, String> entry : params.entrySet()) {
					String key = "set" + toUpperKey(entry.getKey());
					for (Method method : methods) {
						if (key.equals(method.getName())) {
							method.invoke(scOrder, entry.getValue());
							break;
						}
					}
				}
				if (scOrder != null) {
					ScOrder sc = orderDao.findByOutTradeNo(scOrder.getOut_trade_no());
					String moenyId=IdGen.uuid();
					if (sc != null && sc.getTotal_amount().equals(scOrder.getTotal_amount())
							&& sc.getSeller_id().equals(scOrder.getSeller_id())
							&& sc.getApp_id().equals(scOrder.getApp_id()) && sc.getTrade_status().equals(TradeStatus.WAIT_BUYER_PAY.name())) {
						//验证成功后,保存支付宝返回的订单信息
						sc.setTrade_status(scOrder.getTrade_status());
						sc.setTrade_no(scOrder.getTrade_no());
						sc.setReceipt_amount(scOrder.getReceipt_amount());
						sc.setBuyer_pay_amount(scOrder.getBuyer_pay_amount());
						sc.setSubject(scOrder.getSubject());
						sc.setBody(moenyId);
						sc.setGmt_create(scOrder.getGmt_create());
						sc.setGmt_payment(scOrder.getGmt_payment());
						sc.setUpdateValue(sc, String.valueOf(sc.getUser_id()));
						//保存成功后，更新用户的账户资金，出入金表添加记录
						if(orderDao.save(sc)!=null){
							ScUser user=userDao.findByUserId(sc.getUser_id());
							user.setAbleAmount(user.getAbleAmount().add(new BigDecimal(sc.getTotal_amount())));
							user.setAmount(user.getAmount().add(new BigDecimal(sc.getTotal_amount())));
							user.setCostAmount(user.getCostAmount().add(new BigDecimal(sc.getTotal_amount())));
							userDao.save(user);
							ScMoney money=setInitScMoney(user);
							money.setRemark(AlipayConfig.money_remark);
							money.setMoney(new BigDecimal(sc.getTotal_amount()));
							moneyDao.save(money);
						}
						result = "success";
					} else {
						result = "failure";
					}
				}
			}
		} else {
			// 验签失败则记录异常日志，并在response中返回failure.
			log.error("验签失败!");
			result = "failure";
		}
		return result;
	}
	
	
	/**
	 * 将首字母大写
	 * 
	 * @param key
	 * @return
	 */
	public String toUpperKey(String key) {
		if (StringUtils.isNotBlank(key)) {
			key = key.substring(0, 1).toUpperCase() + key.substring(1, key.length());
			return key;
		}
		return null;
	}
	
}
