package com.sc.td.business.entity.user.dto;

import com.sc.td.common.utils.datetime.TimeUtil;

public class GroupUserDto implements Comparable<GroupUserDto>{

	private int userId;
	private String userName; // 用户名
	private String image;//头像
	private boolean isAdmin;//是否是圈子超级管理员
	private boolean isManager;//是否是圈子管理员
	private String joinTime;//加入圈子的时间

	public String getJoinTime() {
		return joinTime;
	}

	public void setJoinTime(String joinTime) {
		this.joinTime = joinTime;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isManager() {
		return isManager;
	}

	public void setManager(boolean isManager) {
		this.isManager = isManager;
	}

	@Override
	public int compareTo(GroupUserDto o) {
		if(this.isAdmin || (this.isManager && !o.isAdmin)){
			return -1;
		}else{
			if(TimeUtil.compare(TimeUtil.str2DateTime(this.joinTime, TimeUtil.DSPdaytimeFormat), TimeUtil.str2DateTime(o.joinTime, TimeUtil.DSPdaytimeFormat))>0){
				return 1;
			}
		}
		return -1;
	}

}
