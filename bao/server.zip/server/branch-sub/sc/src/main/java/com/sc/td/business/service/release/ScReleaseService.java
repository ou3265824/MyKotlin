package com.sc.td.business.service.release;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.base.ScAFutures;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.group.ScGroupMemberDao;
import com.sc.td.business.dao.money.ScMoneyDao;
import com.sc.td.business.dao.release.ScReleaseAmountDao;
import com.sc.td.business.dao.release.ScReleaseDao;
import com.sc.td.business.dao.release.ScReleaseDetailsDao;
import com.sc.td.business.dao.release.ScReleaseUserDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.group.ScGroupMember;
import com.sc.td.business.entity.money.ScMoney;
import com.sc.td.business.entity.release.ScRelease;
import com.sc.td.business.entity.release.ScReleaseAmount;
import com.sc.td.business.entity.release.ScReleaseDetails;
import com.sc.td.business.entity.release.ScReleaseUser;
import com.sc.td.business.entity.release.dto.ReleaseDetailsReq;
import com.sc.td.business.entity.release.dto.ReleaseDto;
import com.sc.td.business.entity.release.dto.ReleaseUserDto;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.CommodityTypeEnum;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.MsgEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.BeanUtils;
import com.sc.td.common.utils.PinyinUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.jwt.Jwt;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;

@Service
public class ScReleaseService extends BaseService {

	@Autowired
	private ScReleaseDao releaseDao;

	@Autowired
	private ScGroupMemberDao groupMemberDao;

	@Autowired
	private ScReleaseUserDao releaseUserDao;

	@Autowired
	private ScGroupDao groupDao;

	@Autowired
	private ScUserDao userDao;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScReleaseDetailsDao releaseDetailsDao;

	@Autowired
	private ScMoneyDao moneyDao;

	@Autowired
	private ScReleaseAmountDao releaseAmountDao;

	/**
	 * 创建策略
	 * 
	 * @param json
	 * @return
	 */
	@Transactional
	public String create(String json, HttpServletRequest request) {
		ScRelease release = JacksonUtil.jsonToObj(json, ScRelease.class);
		if (release != null && StringUtils.isNotBlank(release.getReleaseName())
				&& StringUtils.isNotBlank(String.valueOf(release.getGroupId()))
				&& StringUtils.isNotBlank(String.valueOf(release.getUserId()))) {
			// 判断用户是否存在
			ScUser user = userDao.findByUserId(release.getUserId());
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			ScGroup group = groupDao.findByGroupIdAndDelFlag(release.getGroupId(), DictEnum.not_del.value);
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			// 判断策略名是否重复
			List<ScRelease> findByReleaseName = releaseDao.findByReleaseName(release.getReleaseName());
			if (findByReleaseName != null && findByReleaseName.size() > 0) {
				return CreateJson.createTextJson(ReturnMsgEnum.releaseNameExist.getMessage(), false);
			}
			release.setInitValue(release, String.valueOf(release.getUserId()));
			if (release.getProducer() == null) {
				release.setProducer(release.getUserId());
			}
			if (releaseDao.save(release) != null) {
				release.setUserName(getUserName(user));
				release.setUserImage(getUserImagePath(user.getMobile()));
				return CreateJson.createObjJson(release, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 修改策略
	 * 
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public String modify(String jsonText) throws Exception {
		ScRelease release = JacksonUtil.jsonToObj(jsonText, ScRelease.class);
		if (release != null) {
			ScRelease sc = releaseDao.findByReleaseIdAndDelFlag(release.getReleaseId(), DictEnum.not_del.value);
			if (sc != null) {
				if (release.getGroupId() != null) {
					ScGroup group = groupDao.findByGroupIdAndDelFlag(release.getGroupId(), DictEnum.not_del.value);
					if (group == null) {
						return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
					}
				}
				if (release.getUserId() != null) {
					ScUser user = userDao.findByUserId(release.getUserId());
					if (user == null) {
						return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
					}
				}
				if (release.getProducer() != null) {
					ScUser user = userDao.findByUserId(release.getProducer());
					if (user == null) {
						return CreateJson.createTextJson(ReturnMsgEnum.producerNotExist.getMessage(), false);
					}
				}
				BeanUtils.copyBeanNotNull2Bean(release, sc);
				sc.setUpdateValue(sc, String.valueOf(sc.getUserId()));
				releaseDao.save(sc);
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 开始策略
	 * 
	 * @param releaseId
	 * @return
	 */
	@Transactional
	public String begin(Integer releaseId) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
		}
		if (StringUtils.isBlank(release.getStatus()) || !release.getStatus().equals(DictEnum.moren.value)) {
			return CreateJson.createObjJson(ReturnMsgEnum.operateInvalid.getMessage(), false);
		}
		List<ScReleaseUser> list = releaseUserDao.findByReleaseIdAndDelFlag(release.getReleaseId(),
				DictEnum.not_del.value);
		if (list == null || list.size() < 1) {
			return CreateJson.createObjJson(ReturnMsgEnum.nonBet.getMessage(), false);
		}
		Long count = releaseUserDao.countByReleaseIdAndUserAbleAmountLessZero(releaseId);
		if (count > 0) {
			return CreateJson.createObjJson(ReturnMsgEnum.betMoneyNotEnough.getMessage(), false);
		} else {
			for (ScReleaseUser sc : list) {
				ScUser user = userDao.findByUserId(sc.getUserId());
				if (user != null && user.getAbleAmount().compareTo(new BigDecimal(0.00)) >= 0) {
					sc.setStatus(DictEnum.ing.value);
					sc.setIsPay(DictEnum.positive.value);
					releaseUserDao.save(sc);
					// 出入金表添加出金记录
					ScMoney scMoney = setInitScMoney(user);
					scMoney.setMoney(new BigDecimal(0.00).subtract(sc.getAmount()));
					scMoney.setRemark("支付策略\"" + release.getReleaseName() + "\"的验证费");
					moneyDao.save(scMoney);
				}
			}
			release.setStatus(DictEnum.ing.value);
			release.setUpdateValue(release, String.valueOf(release.getUserId()));
			release.setHisProfitRate(
					TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat) + "@@" + release.getProfitRate());
			releaseDao.save(release);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
	}

	/**
	 * 结束策略，并计算投注人收益
	 * 
	 * @param releaseId
	 * @return
	 */
	@Transactional
	public String end(Integer releaseId) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release != null) {
			Long count = releaseDetailsDao.countByReleaseIdAndCloseFlag(releaseId, DictEnum.open.value);
			if (count > 0) {
				return CreateJson.createTextJson(ReturnMsgEnum.notAllCloseDetails.getMessage(), false);
			}
			release.setUpdateValue(release, String.valueOf(release.getUserId()));
			release.setStatus(DictEnum.end.value);
			releaseDao.save(release);
			if (release.getProfit().compareTo(new BigDecimal(0.00)) > 0) {
				// 管理费和收益奖励
				ScReleaseAmount ra = new ScReleaseAmount();
				ra.setReleaseId(release.getReleaseId());
				ra.setManagerAmount(release.getProfit().multiply(new BigDecimal(DictEnum.releaseManagerRatio.value)));
				ra.setManagerRatio(Float.valueOf(DictEnum.releaseManagerRatio.value));
				ra.setRewardAmount(release.getProfit().multiply(new BigDecimal(DictEnum.releaseRewardRatio.value)));
				ra.setRewardRatio(Float.valueOf(DictEnum.releaseRewardRatio.value));
				releaseAmountDao.save(ra);
				ScUser user = userDao.findByUserId(release.getProducer());
				if (user != null) {
					user.setAbleAmount(user.getAbleAmount().add(ra.getRewardAmount()));
					user.setAmount(user.getAmount().add(ra.getRewardAmount()));
					userDao.save(user);
					ScMoney money = setInitScMoney(user);
					money.setRemark("策略\"" + release.getReleaseName() + "\"结束，收到策略鼓励金。");
					money.setMoney(ra.getRewardAmount().setScale(2, BigDecimal.ROUND_FLOOR));
					moneyDao.save(money);
					// 创建消息
					ScGroup group = groupDao.findByGroupIdAndDelFlag(release.getGroupId(), DictEnum.not_del.value);
					String content = setSysContent(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()),
							group.getGroupName(),
							"策略\"" + release.getReleaseName() + "\"结束，收到策略鼓励金" + ra.getRewardAmount().setScale(2, BigDecimal.ROUND_FLOOR) + ",可在个人账户中查看",
							TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
					createNotify(String.valueOf(user.getUserId()), MsgEnum.sys.value, MsgEnum.sys.desc, content);
				}
			}
			List<ScReleaseUser> list = releaseUserDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
			if (list != null && list.size() > 0) {
				for (ScReleaseUser sc : list) {
					sc.setStatus(DictEnum.end.value);
					ScUser user = userDao.findByUserId(sc.getUserId());
					if (sc.getProfit().add(sc.getAmount()).compareTo(new BigDecimal(0.00)) > 0) {
						sc.setProfit(sc.getProfit().multiply(new BigDecimal(DictEnum.releaseProfitRatio.value)));
						user.setAmount(user.getAmount().add(sc.getAmount()).add(sc.getProfit()));
						user.setAbleAmount(user.getAbleAmount().add(sc.getAmount()).add(sc.getProfit()));
						userDao.save(user);
						ScMoney money = setInitScMoney(user);
						money.setRemark("策略\"" + release.getReleaseName() + "\"结束，归还本金。");
						money.setMoney(sc.getAmount().setScale(2, BigDecimal.ROUND_FLOOR));
						moneyDao.save(money);
						ScMoney money1 = setInitScMoney(user);
						money1.setRemark("策略\"" + release.getReleaseName() + "\"结束，结算收益。");
						money1.setMoney(sc.getProfit().setScale(2, BigDecimal.ROUND_FLOOR));
						moneyDao.save(money1);
						// 创建消息
						ScGroup group = groupDao.findByGroupIdAndDelFlag(release.getGroupId(), DictEnum.not_del.value);
						String content = setSysContent(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()),
								group.getGroupName(),
								"策略\"" + release.getReleaseName() + "\"结束，归还本金："+sc.getAmount().setScale(2, BigDecimal.ROUND_FLOOR)+",结算收益：" + sc.getProfit().setScale(2, BigDecimal.ROUND_FLOOR)
										+ ",可在个人账户中查看",
								TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
						createNotify(String.valueOf(user.getUserId()), MsgEnum.sys.value, MsgEnum.sys.desc, content);
					}
					releaseUserDao.save(sc);
				}
			}
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 在策略未开始时废弃策略
	 * 
	 * @param releaseId
	 * @return
	 */
	@Transactional
	public String abort(Integer releaseId) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release != null && release.getStatus().equals(DictEnum.moren.value)) {
			release.setStatus(DictEnum.end.value);
			release.setUpdateValue(release, String.valueOf(release.getUserId()));
			releaseDao.save(release);
			List<ScReleaseUser> list = releaseUserDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
			if (list != null && list.size() > 0) {
				for (ScReleaseUser sc : list) {
					sc.setStatus(DictEnum.end.value);
					releaseUserDao.save(sc);
					ScUser user = userDao.findByUserId(sc.getUserId());
					if (user != null) {
						user.setAbleAmount(user.getAbleAmount().add(sc.getAmount()));
						userDao.save(user);
					}
				}
			}
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 查询“我”的策略 所有圈子
	 * 
	 * @param userId
	 * @return
	 */
	public String my(String userId, String type) {
		String status = DictEnum.end.value;// 默认查询未结束的
		if (StringUtils.isNotBlank(type) && type.equals(DictEnum.all.value)) {
			// 查询所有
			status = DictEnum.all.value;
		}
		if (StringUtils.isBlank(userId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		int id = Integer.parseInt(userId);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		// 首先为验证的策略
		List<ScReleaseUser> list = releaseUserDao.findByUserIdAndDelFlagAndStatusNot(id, DictEnum.not_del.value,
				status);
		if (list != null && list.size() > 0) {
			for (ScReleaseUser sc : list) {
				ScRelease release = releaseDao.findByReleaseIdAndDelFlag(sc.getReleaseId(), DictEnum.not_del.value);
				if (release != null) {
					set.add(release);
				}
			}
		}
		// 发布的策略
		TreeSet<ScRelease> releaseSet = releaseDao.findByUserIdAndDelFlagAndStatusNot(id, DictEnum.not_del.value,
				status);
		set.addAll(releaseSet);
		handlerReturnData(set, id);
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 根据策略状态查询“我”的策略 所有圈子
	 * 
	 * @param userId
	 * @return
	 */
	public String myByStatus(String userId, String status) {
		if (StringUtils.isBlank(userId) || StringUtils.isBlank(status)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		int id = Integer.parseInt(userId);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		// 首先为验证的策略
		Set<ScReleaseUser> set1 = releaseUserDao.findByUserIdAndDelFlagAndStatus(id, DictEnum.not_del.value, status);
		if (set1 != null && set1.size() > 0) {
			for (ScReleaseUser sc : set1) {
				ScRelease release = releaseDao.findByReleaseIdAndDelFlag(sc.getReleaseId(), DictEnum.not_del.value);
				if (release != null) {
					set.add(release);
				}
			}
		}
		// 发布的策略
		TreeSet<ScRelease> releaseSet = releaseDao.findByUserIdAndDelFlagAndStatus(id, DictEnum.not_del.value, status);
		set.addAll(releaseSet);
		handlerReturnData(set, id);
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 查询“我”的策略（包括验证的和发起的正在进行中的策略） 特定圈子
	 * 
	 * @param userId
	 * @return
	 */
	public String myByGroupId(String userId, String groupId) {
		if (StringUtils.isBlank(groupId) || StringUtils.isBlank(userId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		int id = Integer.parseInt(userId);
		int gid = Integer.parseInt(groupId);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		// 首先为验证的策略
		List<ScReleaseUser> list = releaseUserDao.findByUserIdAndGroupIdAndDelFlagAndStatusNot(id, gid,
				DictEnum.not_del.value, DictEnum.end.value);
		if (list != null && list.size() > 0) {
			for (ScReleaseUser sc : list) {
				ScRelease release = releaseDao.findByReleaseIdAndDelFlag(sc.getReleaseId(), DictEnum.not_del.value);
				if (release != null) {
					set.add(release);
				}
			}
		}
		// 发布的策略
		TreeSet<ScRelease> releaseSet = releaseDao.findByUserIdAndGroupIdAndDelFlagAndStatusNot(id, gid,
				DictEnum.not_del.value, DictEnum.end.value);
		set.addAll(releaseSet);
		handlerReturnData(set, id);
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 获取策略排行榜
	 * 
	 * @param index
	 * @param size
	 * @return
	 */
	public String rank(String userId, String index1, String size1) {
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		List<ScRelease> list = rankAndDelFlag(DictEnum.ing.value, pageInfo.get_pageno(), pageInfo.get_size(),
				DictEnum.not_del.value);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		set.addAll(list);
		handlerReturnData(set, Integer.parseInt(userId));
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 用户加入的圈子中 根据圈子ID获取策略（不包括已结束的策略）
	 * 
	 * @param userId
	 *            当前请求的用户
	 * @param groupId
	 * @return
	 */
	public String findByGroupId(String userId, String groupId, String index1, String size1) {
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		if (StringUtils.isBlank(groupId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(Integer.parseInt(userId));
		if (user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		List<ScRelease> list = findByGroupIdNotEndAndDelFlag(Integer.parseInt(groupId), pageInfo.get_pageno(),
				pageInfo.get_size(), DictEnum.not_del.value);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		set.addAll(list);
		handlerReturnData(set, Integer.parseInt(userId));
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 用户加入的圈子中 根据圈子ID和策略状态获取策略
	 * 
	 * @param groupId
	 * @return
	 */
	public String findByGroupIdAndStatus(String userId, String groupId, String status, String index1, String size1) {
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		if (StringUtils.isBlank(groupId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		List<ScRelease> list = findByGroupIdAndStatusAndDelFlag(Integer.parseInt(groupId), status,
				pageInfo.get_pageno(), pageInfo.get_size(), DictEnum.not_del.value);
		TreeSet<ScRelease> set = Sets.newTreeSet();
		set.addAll(list);
		handlerReturnData(set, Integer.parseInt(userId));
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 在“我的”页面查看“策略收益” （1）总的投注金额（正在进行中的策略）和收益 （2）单个策略收益
	 * 
	 * @param userId
	 * @return
	 */
	public String myReleaseProfit(String userId) {
		if (StringUtils.isNotBlank(userId)) {
			int uid = Integer.parseInt(userId);
			ScUser user = userDao.findByUserId(uid);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			Set<ScReleaseUser> set = releaseUserDao.findByUserIdAndDelFlagAndStatus(uid, DictEnum.not_del.value,
					DictEnum.ing.value);
			if (set != null && set.size() > 0) {
				BigDecimal totalAmount = new BigDecimal(0.00);// 总投注额
				BigDecimal totalProfit = new BigDecimal(0.00);// 总收益
				for (ScReleaseUser sc : set) {
					ScGroup group = groupDao.findByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value);// 圈子创建人
					if (group != null) {
						sc.setGroupName(group.getGroupName());
					}
					ScRelease release = releaseDao.findByReleaseIdAndDelFlag(sc.getReleaseId(), DictEnum.not_del.value);
					release = getProducerInfo(release);
					if (release != null) {
						sc.setReleaseName(release.getReleaseName());
					}
					totalAmount = totalAmount.add(sc.getAmount());
					totalProfit = totalProfit.add(sc.getProfit());
				}
				Map<String, Object> map = Maps.newHashMap();
				map.put("releaseUser", set);
				map.put("totalAmount", totalAmount);
				map.put("totalProfit", totalProfit);
				return CreateJson.createObjJson(map, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 策略详情
	 * 
	 * @param releaseId
	 * @param userId
	 * @return
	 */
	public String releaseDetails(String releaseId, String userId) {
		if (StringUtils.isNotBlank(releaseId) && StringUtils.isNotBlank(userId)) {
			int uid = Integer.parseInt(userId);
			int rid = Integer.parseInt(releaseId);
			ScUser user = userDao.findByUserId(uid);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			ScRelease release = releaseDao.findByReleaseIdAndDelFlag(rid, DictEnum.not_del.value);
			if (release == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
			}
			ScUser createUser = userDao.findByUserId(release.getUserId());
			ScGroupMember groupMember = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(release.getGroupId(), uid,
					DictEnum.not_del.value);
			String isInGroup = DictEnum.negative.value;
			if (groupMember != null) {
				isInGroup = DictEnum.positive.value;
			}
			// 判断当前用户与该策略是否有关
			if (checkRel(release.getReleaseId(), uid, release.getGroupId())) {
				// "我的"投注和收益
				ScReleaseUser releaseUser = releaseUserDao.findByUserIdAndReleaseIdAndDelFlag(uid, rid,
						DictEnum.not_del.value);
				release.setRel(true);
				release.setUserName(getUserName(createUser));
				release.setUserImage(getUserImagePath(createUser.getMobile()));
				Map<String, Object> map = Maps.newHashMap();
				BigDecimal amount = new BigDecimal(0.00);
				BigDecimal profit = new BigDecimal(0.00);
				String isPay = DictEnum.negative.value;
				if (releaseUser != null) {
					amount = releaseUser.getAmount();
					profit = releaseUser.getProfit();
					release.setBet(true);
					isPay = releaseUser.getIsPay();
				} else {
					release.setBet(false);
				}
				release = getProducerInfo(release);
				map.put("isRel", true);
				map.put("release", release);
				map.put("myAmount", amount);
				map.put("myProfit", profit);
				map.put("isPay", isPay);
				map.put("isInGroup", isInGroup);
				return CreateJson.createObjJson(map, true);
			} else {
				// 无关
				ReleaseDto dto = new ReleaseDto();
				release = getProducerInfo(release);
				dto.setIntro(release.getIntro());
				dto.setProfitRate(release.getProfitRate());
				dto.setReleaseName(release.getReleaseName());
				dto.setStatus(release.getStatus());
				dto.setUserName(getUserName(createUser));
				dto.setUserImage(getUserImagePath(createUser.getMobile()));
				dto.setBet(false);
				dto.setProducerName(release.getProducerName());
				dto.setProducerImage(release.getProducerImage());
				dto.setInCondition(release.getInCondition());
				dto.setOutCondition(release.getOutCondition());
				dto.setCollectCloseDate(release.getCollectCloseDate());
				Map<String, Object> map = Maps.newHashMap();
				map.put("isRel", false);
				map.put("release", dto);
				map.put("isInGroup", isInGroup);
				return CreateJson.createObjJson(map, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 添加投注
	 * 
	 * @param userId
	 * @param releaseId
	 * @param groupId
	 * @param amount
	 * @return
	 */
	@Transactional
	public synchronized String addReleaseUser(String releaseId, String userId, String amount) {
		if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(releaseId) && StringUtils.isNotBlank(amount)) {
			int uid = Integer.parseInt(userId);
			int rid = Integer.parseInt(releaseId);
			BigDecimal amountd = new BigDecimal(amount);
			if (amountd.compareTo(new BigDecimal(100.00)) == -1) {
				return CreateJson.createTextJson(ReturnMsgEnum.minAmount.getMessage(), false);
			}
			ScUser user = userDao.findByUserId(uid);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			ScRelease release = releaseDao.findByReleaseIdAndDelFlag(rid, DictEnum.not_del.value);
			if (release == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
			}
			if (StringUtils.isNotBlank(release.getCollectCloseDate()) && TimeUtil
					.str2DateTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSpdayFormat), TimeUtil.DSpdayFormat)
					.compareTo(TimeUtil.str2DateTime(release.getCollectCloseDate(), TimeUtil.DSpdayFormat)) > 0) {
				return CreateJson.createTextJson(ReturnMsgEnum.releaseBetClose.getMessage(), false);
			}
			if (release.getStatus().equals(DictEnum.ing.value) || release.getStatus().equals(DictEnum.end.value)) {
				return CreateJson.createTextJson(ReturnMsgEnum.releaseIngOrEnd.getMessage(), false);
			}
			ScReleaseUser releaseUser = releaseUserDao.findByUserIdAndReleaseIdAndDelFlag(uid, rid,
					DictEnum.not_del.value);
			BigDecimal amount_old = new BigDecimal(0.00);
			if (releaseUser == null) {
				releaseUser = new ScReleaseUser();
				releaseUser.setReleaseId(rid);
				releaseUser.setUserId(uid);
				releaseUser.setGroupId(release.getGroupId());
				releaseUser.setProfit(new BigDecimal(0.00));
				releaseUser.setStatus(release.getStatus());
				releaseUser.setDelFlag(DictEnum.not_del.value);
				releaseUser.setIsPay(DictEnum.positive.value);
				releaseUser.setInitValue(releaseUser, userId);
			} else {
				amount_old = releaseUser.getAmount();
				releaseUser.setUpdateValue(releaseUser, userId);
			}
			releaseUser.setAmount(amountd);
			releaseUserDao.save(releaseUser);
			release.setCollectMoney(release.getCollectMoney().subtract(amount_old).add(amountd));
			releaseDao.save(release);
			String respInfo = ReturnMsgEnum.operateSuccess.getMessage();
			// 更新账户资金
			BigDecimal ableAmount = user.getAbleAmount();
			ableAmount = ableAmount.add(amount_old).subtract(amountd);
			user.setAbleAmount(ableAmount);
			userDao.save(user);
			return CreateJson.createTextJson(respInfo, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 增加策略标的
	 * 
	 * @param json
	 * @return
	 */
	@Transactional
	public String addReleaseDetails(String jsonText) {
		ReleaseDetailsReq req = JacksonUtil.jsonToObj(jsonText, ReleaseDetailsReq.class);
		if (req != null) {
			ScRelease release = releaseDao.findByReleaseIdAndDelFlag(req.getReleaseId(), DictEnum.not_del.value);
			if (release == null) {
				return CreateJson.createObjJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
			}
			if (!release.getStatus().equals(DictEnum.ing.value)) {
				return CreateJson.createObjJson(ReturnMsgEnum.connotDetails.getMessage(), false);
			}
			if (release.getCollectMoney().compareTo(new BigDecimal(0.00)) <= 0) {
				return CreateJson.createObjJson(ReturnMsgEnum.zeroCollectMoney.getMessage(), false);
			}
			List<ScReleaseDetails> list = release.getDetails();
			BigDecimal totalCost = new BigDecimal(0.00);
			if (list != null && list.size() > 0) {
				for (ScReleaseDetails sc : list) {
					if (sc.getCloseFlag().equals(DictEnum.close.value)) {
						continue;
					}
					totalCost = totalCost.add(sc.getTotalCost());
				}
			}
			List<ScReleaseDetails> detailsList = req.getDetailsList();
			if (detailsList != null && detailsList.size() > 0) {
				for (ScReleaseDetails sc : detailsList) {
					if (!checkReleaseDetails(sc)) {
						return CreateJson.createObjJson(ReturnMsgEnum.paramsInvalid.getMessage(), false);
					}
					sc.setReleaseId(release.getReleaseId());
					sc.setCloseFlag(DictEnum.open.value);
					sc.setCostRatio(sc.getTotalCost().divide(release.getCollectMoney(), 4, BigDecimal.ROUND_FLOOR)
							.floatValue());
					sc.setProfit(new BigDecimal(0.00));
					sc.setProfitRate(0.0f);
					sc.setInitValue(sc, String.valueOf(release.getUserId()));
					totalCost = totalCost.add(sc.getTotalCost());
				}
				if (totalCost.compareTo(release.getCollectMoney()) > 0) {
					return CreateJson.createObjJson(ReturnMsgEnum.outOfCollectMoney.getMessage(), false);
				}
				release.setDetails(detailsList);
				releaseDao.save(release);
				calcProfit(release);
			}
			return CreateJson.createObjJson(release, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 删除策略标的
	 * 
	 * @param releaseId
	 * @param id
	 * @return
	 */
	public String delReleaseDetails(Integer releaseId, Integer id) {
		if (releaseId != null && id != null) {
			ScReleaseDetails sc = releaseDetailsDao.findById(id);
			if (sc != null) {
				releaseDetailsDao.delete(sc);
				ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
				if (release != null) {
					// 更新策略收益
					updateRelease(release);
					// 计算每个人的收益
					calcUserProfit(release);
				}
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 策略标的平仓 同时计算策略及策略投注人的收益
	 * 
	 * @param releaseId
	 * @param id
	 * @param price
	 * @return
	 */
	@Transactional
	public String closeReleaseDetails(Integer releaseId, Integer id, BigDecimal nowPrice) {
		if (releaseId != null && id != null && nowPrice != null) {
			ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
			ScReleaseDetails details = releaseDetailsDao.findById(id);
			if (release != null && details != null && release.getStatus().equals(DictEnum.ing.value)) {
				BigDecimal profit = new BigDecimal(0.00);
				float profitRate = 0.00f;
				details.setNowPrice(nowPrice);
				profit = calcDetailsProfit(details);
				profitRate = profit.divide(details.getTotalCost(), 4, BigDecimal.ROUND_FLOOR).floatValue();
				details.setNowPrice(nowPrice);
				details.setProfit(profit);
				details.setProfitRate(profitRate);
				details.setCloseFlag(DictEnum.close.value);
				details.setUpdateValue(details, String.valueOf(release.getUserId()));
				releaseDetailsDao.save(details);
				// 更新策略收益
				updateRelease(release);
				// 计算每个人的收益
				calcUserProfit(release);
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 根据平仓价更新策略收益
	 * 
	 * @param release
	 */
	public void updateRelease(ScRelease release) {
		List<String> hisProfitRateList = Lists.newArrayList();
		BigDecimal totalProfit = new BigDecimal(0.00);
		List<ScReleaseDetails> detailsList = release.getDetails();
		if (detailsList != null && detailsList.size() > 0) {
			for (ScReleaseDetails details : detailsList) {
				totalProfit = totalProfit.add(details.getProfit());
			}
			release.setDetails(detailsList);
		}
		release.setProfit(totalProfit);
		release.setProfitRate(totalProfit.divide(release.getCollectMoney(), 4, BigDecimal.ROUND_FLOOR).floatValue());
		// 设置历史收益率
		if (StringUtils.isNoneBlank(release.getHisProfitRate())) {
			String day = TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DBdayFormat);
			if (release.getHisProfitRate().indexOf(day) == -1) {
				release.setHisProfitRate(release.getHisProfitRate() + "," + day + "@@" + release.getProfitRate());
			} else {
				String[] arr = release.getHisProfitRate().split(",");
				for (int i = 0; i < arr.length; i++) {
					if (arr[i].indexOf(day) != -1) {
						arr[i] = arr[i].split("@@")[0] + "@@" + release.getProfitRate();
					}
					hisProfitRateList.add(arr[i]);
				}
				release.setHisProfitRate(Joiner.on(",").join(hisProfitRateList));
			}
		}
		release.setUpdateValue(release, String.valueOf(release.getUserId()));
		releaseDao.save(release);
	}

	/**
	 * 平仓时计算每个标的的收益
	 * 
	 * @param details
	 * @return
	 */
	public BigDecimal calcDetailsProfit(ScReleaseDetails details) {
		if (details != null) {
			BigDecimal profit = new BigDecimal(0.00);
			// 计算策略收益
			// 判断是股票还是期货
			String key = DictEnum.redis_market_prefix.value + "-" + details.getCode() + "-" + details.getName() + "-"
					+ PinyinUtils.converterToFirstSpell(details.getName());
			if (details.getType().equals(CommodityTypeEnum.内盘期货.value)) {
				ScAFutures futures = JacksonUtil.jsonToObj(String.valueOf(redisService.get(key)), ScAFutures.class);
				profit = (details.getNowPrice().subtract(details.getCostPrice())).divide(futures.getFUpperTick())
						.multiply(new BigDecimal(futures.getFLowerTick())
								.divide(new BigDecimal(Math.pow(10.0, futures.getFDotNum()))))
						.multiply(futures.getFProductDot()).multiply(new BigDecimal(details.getVolume()))
						.multiply(new BigDecimal(buysell(details.getDirect())));
			} else if (details.getType().equals(CommodityTypeEnum.内盘股票.value)) {
				profit = (details.getNowPrice().subtract(details.getCostPrice()))
						.multiply(new BigDecimal(details.getVolume()));
			}
			profit = profit.setScale(2, BigDecimal.ROUND_FLOOR);
			return profit;
		}
		return new BigDecimal(0.00);
	}

	/**
	 * 验证标的信息
	 * 
	 * @param sc
	 * @return
	 */
	public boolean checkReleaseDetails(ScReleaseDetails sc) {
		if (sc == null) {
			return false;
		}
		if (!checkCommodityType(sc.getType())) {
			return false;
		}
		if (!checkDirect(sc.getDirect())) {
			return false;
		}
		if (!checkCommodity(sc.getCode(), sc.getName())) {
			return false;
		}
		return true;
	}

	/**
	 * 买卖方向
	 * 
	 * @param direct
	 * @return
	 */
	public boolean checkDirect(String direct) {
		if (StringUtils.isBlank(direct)) {
			return false;
		}
		boolean b = false;
		if (direct.equals(DictEnum.buy.value) || direct.equals(DictEnum.sell.value)) {
			b = true;
		}
		return b;
	}

	/**
	 * 商品类型
	 * 
	 * @param type
	 * @return
	 */
	public boolean checkCommodityType(String type) {
		if (StringUtils.isBlank(type)) {
			return false;
		}
		boolean b = false;
		for (CommodityTypeEnum e : CommodityTypeEnum.values()) {
			if (e.value.equals(type)) {
				b = true;
				break;
			}
		}
		return b;
	}

	/**
	 * 商品是否存在
	 * 
	 * @param code
	 * @param name
	 * @return
	 */
	public boolean checkCommodity(String code, String name) {
		if (StringUtils.isBlank(code) || StringUtils.isBlank(name)) {
			return false;
		}
		String key = DictEnum.redis_market_prefix.value + "-" + code + "-" + name + "-"
				+ PinyinUtils.converterToFirstSpell(name);
		if (!redisService.exists(key)) {
			return false;
		}
		return true;
	}

	/**
	 * 获取策略投注人列表
	 * 
	 * @param releaseId
	 * @return
	 */
	public String releaseUserList(Integer releaseId) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
		}
		List<ScReleaseUser> list = releaseUserDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		List<ReleaseUserDto> dataList = Lists.newArrayList();
		if (list != null && list.size() > 0) {
			for (ScReleaseUser sc : list) {
				ScUser user = userDao.findByUserId(sc.getUserId());
				if (user != null) {
					ReleaseUserDto dto = new ReleaseUserDto();
					dto.setReleaseId(sc.getReleaseId());
					dto.setAmount(sc.getAmount());
					dto.setMobile(user.getMobile());
					dto.setUserId(user.getUserId());
					dto.setUserName(getUserName(user));
					dto.setAbleAmount(user.getAbleAmount());
					dto.setRealName(user.getRealName());
					dataList.add(dto);
				}
			}
		}
		if (dataList != null && dataList.size() > 0) {
			return CreateJson.createObjJson(dataList, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 删除投注人
	 * 
	 * @param releaseId
	 * @param userId
	 * @return
	 */
	@Transactional
	public String delReleaseUser(Integer releaseId, Integer userId) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
		}
		if (!release.getStatus().equals(DictEnum.moren.value)) {
			return CreateJson.createObjJson(ReturnMsgEnum.cannotDelReleaseUser.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(release.getUserId());
		if (user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		ScReleaseUser releaseUser = releaseUserDao.findByUserIdAndReleaseIdAndDelFlag(userId, releaseId,
				DictEnum.not_del.value);
		if (releaseUser != null) {
			BigDecimal amount = releaseUser.getAmount();
			release.setCollectMoney(release.getCollectMoney().subtract(amount));
			release.setUpdateValue(release, String.valueOf(release.getUserId()));
			releaseDao.save(release);
			ScUser betUser = userDao.findByUserId(releaseUser.getUserId());
			if (betUser != null) {
				betUser.setAbleAmount(betUser.getAbleAmount().add(amount));
				userDao.save(betUser);
			}
			releaseUserDao.delete(releaseUser);
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 撤销投注
	 * 
	 * @param releaseId
	 * @param userId
	 * @param request
	 * @return
	 */
	@SuppressWarnings("unchecked")
	@Transactional
	public String cancelBet(Integer releaseId, Integer userId, HttpServletRequest request) {
		ScRelease release = releaseDao.findByReleaseIdAndDelFlag(releaseId, DictEnum.not_del.value);
		if (release == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.releaseNotExist.getMessage(), false);
		}
		if (!release.getStatus().equals(DictEnum.moren.value)) {
			return CreateJson.createObjJson(ReturnMsgEnum.cannotDelReleaseUser.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(release.getUserId());
		if (user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		// 验证当前用户是否有此权限
		String token = request.getHeader("token");
		Map<String, Object> resultMap = Jwt.validToken(token);
		Map<String, Object> dataMap = new HashMap<String, Object>();
		dataMap = (HashMap<String, Object>) resultMap.get("data");
		String uid = String.valueOf(dataMap.get("userId"));
		if (!uid.equals(String.valueOf(userId))) {
			return CreateJson.createObjJson(ReturnMsgEnum.nopermission.getMessage(), false);
		}
		ScReleaseUser releaseUser = releaseUserDao.findByUserIdAndReleaseIdAndDelFlag(userId, releaseId,
				DictEnum.not_del.value);
		if (releaseUser != null) {
			BigDecimal amount = releaseUser.getAmount();
			release.setCollectMoney(release.getCollectMoney().subtract(amount));
			release.setUpdateValue(release, String.valueOf(release.getUserId()));
			releaseDao.save(release);
			ScUser betUser = userDao.findByUserId(releaseUser.getUserId());
			if (betUser != null) {
				betUser.setAbleAmount(betUser.getAbleAmount().add(amount));
				userDao.save(betUser);
			}
			releaseUserDao.delete(releaseUser);
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	// TODO
	//////////////////////////////////////////// 实现接口方法//////////////////////////////////////////////////////////////////

	/**
	 * 获取策略排行榜
	 * 
	 * @param status
	 * @param pageno
	 * @param size
	 * @param delFlag
	 * @return
	 */
	public List<ScRelease> rankAndDelFlag(String status, int pageno, int size, String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _status = root.get("status");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_status, status));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "profitRate");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return releaseDao.findAll(specification, pageable).getContent();
	}

	/**
	 * 根据圈子ID查询尚未结束的策略
	 * 
	 * @param groupId
	 * @param index
	 * @param size
	 * @param delFlag
	 * @return
	 */
	public List<ScRelease> findByGroupIdNotEndAndDelFlag(int groupId, int pageno, int size, String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _groupId = root.get("groupId");
				Path<String> _delFlag = root.get("delFlag");
				Path<String> _status = root.get("status");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_groupId, groupId));
				predicates.add(cb.equal(_delFlag, delFlag));
				predicates.add(cb.notEqual(_status, "ZZ"));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "status");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return releaseDao.findAll(specification, pageable).getContent();
	}

	/**
	 * 根据圈子ID和策略状态查询
	 * 
	 * @param groupId
	 * @param status
	 * @param pageno
	 * @param size
	 * @param delFlag
	 * @return
	 */
	public List<ScRelease> findByGroupIdAndStatusAndDelFlag(int groupId, String status, int pageno, int size,
			String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _groupId = root.get("groupId");
				Path<String> _delFlag = root.get("delFlag");
				Path<String> _status = root.get("status");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_groupId, groupId));
				predicates.add(cb.equal(_delFlag, delFlag));
				predicates.add(cb.equal(_status, status));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "status");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return releaseDao.findAll(specification, pageable).getContent();
	}

	/**
	 * 根据策略名模糊查询尚未结束的策略
	 * 
	 * @param releaseName
	 * @param delFlag
	 * @return
	 */
	public TreeSet<ScRelease> findByReleaseNameLikeAndDelFlag(String releaseName, String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _releaseName = root.get("releaseName");
				Path<String> _delFlag = root.get("delFlag");
				Path<String> _status = root.get("status");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.like(_releaseName, "%" + releaseName + "%"));
				predicates.add(cb.equal(_delFlag, delFlag));
				predicates.add(cb.notEqual(_status, "E"));
				return query.where(predicates.toArray(new Predicate[] {})).getRestriction();
			}

		};
		return releaseDao.findAll(specification);
	}

	/**
	 * 根据圈子Id和策略名模糊查询尚未结束的策略
	 * 
	 * @param groupId
	 * @param releaseName
	 * @param delFlag
	 * @return
	 */
	public TreeSet<ScRelease> findByGroupIdAndReleaseNameLikeAndDelFlag(int groupId, String releaseName,
			String delFlag) {
		Specification<ScRelease> specification = new Specification<ScRelease>() {
			@Override
			public Predicate toPredicate(Root<ScRelease> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _groupId = root.get("groupId");
				Path<String> _releaseName = root.get("releaseName");
				Path<String> _delFlag = root.get("delFlag");
				Path<String> _status = root.get("status");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.like(_releaseName, "%" + releaseName + "%"));
				predicates.add(cb.equal(_groupId, groupId));
				predicates.add(cb.equal(_delFlag, delFlag));
				predicates.add(cb.notEqual(_status, "E"));
				return query.where(predicates.toArray(new Predicate[] {})).getRestriction();
			}

		};
		return releaseDao.findAll(specification);
	}

}
