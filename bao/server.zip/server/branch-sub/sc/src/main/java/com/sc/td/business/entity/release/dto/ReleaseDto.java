package com.sc.td.business.entity.release.dto;

/**
 * 当前用户与该策略无关时，返回的数据
 * @author user
 *
 */
public class ReleaseDto {

	private String releaseName;
	private float profitRate;
	private String userName;
	private String userImage;
	private String intro;
	private String status;
	private boolean isBet;
	private String producerName;
	private String producerImage;
	private String collectCloseDate;
	private String inCondition;
	private String outCondition;
	
	public String getCollectCloseDate() {
		return collectCloseDate;
	}
	public void setCollectCloseDate(String collectCloseDate) {
		this.collectCloseDate = collectCloseDate;
	}
	public String getInCondition() {
		return inCondition;
	}
	public void setInCondition(String inCondition) {
		this.inCondition = inCondition;
	}
	public String getOutCondition() {
		return outCondition;
	}
	public void setOutCondition(String outCondition) {
		this.outCondition = outCondition;
	}
	public String getProducerImage() {
		return producerImage;
	}
	public void setProducerImage(String producerImage) {
		this.producerImage = producerImage;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public boolean isBet() {
		return isBet;
	}
	public void setBet(boolean isBet) {
		this.isBet = isBet;
	}
	public String getReleaseName() {
		return releaseName;
	}
	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}
	public float getProfitRate() {
		return profitRate;
	}
	public void setProfitRate(float profitRate) {
		this.profitRate = profitRate;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getUserImage() {
		return userImage;
	}
	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
}
