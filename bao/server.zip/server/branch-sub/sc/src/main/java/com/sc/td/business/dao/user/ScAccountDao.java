package com.sc.td.business.dao.user;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.user.ScAccount;

public interface ScAccountDao extends BaseDao<ScAccount>{

	ScAccount findByUserId(int userId);
	
	ScAccount findByUserIdAndPassword(int userId,String pwd);
}
