package com.sc.td.business.entity.tribe;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.sc.td.common.config.DictEnum;
import com.sc.td.common.persistence.BaseEntity;

@Table
@Entity
public class ScTribe extends BaseEntity{

	private int tribeId;		//部落Id
	private String tribeName;	//部落名称
	private Integer userId;		//部落创建者Id
	private String intro;		//简介
	private String joinType;	//加入类型（0免费1收费，默认0）
	private BigDecimal joinFee;	//加入费用
	private String delFlag;		//删除标记（0正常1删除，默认0）
	private String isPublic;	//是否公开（true/false,默认不公开false）
	private String image;		//部落图片
	private long peopleCount;	//部落人数
	private String userName;	//部落创建者名称
	private String userImg;		//部落创建者头像
	private boolean isJoin;		//是否加入
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	public String getTribeName() {
		return tribeName;
	}
	public void setTribeName(String tribeName) {
		this.tribeName = tribeName;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getJoinType() {
		return joinType;
	}
	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}
	public BigDecimal getJoinFee() {
		return joinFee;
	}
	public void setJoinFee(BigDecimal joinFee) {
		this.joinFee = joinFee;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	public String getIsPublic() {
		return isPublic;
	}
	public void setIsPublic(String isPublic) {
		this.isPublic = isPublic;
	}
	@Transient
	public boolean isJoin() {
		return isJoin;
	}
	public void setJoin(boolean isJoin) {
		this.isJoin = isJoin;
	}
	@Transient
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Transient
	public long getPeopleCount() {
		return peopleCount;
	}
	public void setPeopleCount(long peopleCount) {
		this.peopleCount = peopleCount;
	}
	@Transient
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Transient
	public String getUserImg() {
		return userImg;
	}
	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setJoinType(DictEnum.free.value);
		this.setDelFlag(DictEnum.not_del.value);
		this.setIsPublic(DictEnum.isprivate.value);
	}
}
