package com.sc.td.business.entity.release;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class ScReleaseAmount {

	private int releaseId;
	private float managerRatio;
	private BigDecimal managerAmount;
	private float rewardRatio;
	private BigDecimal rewardAmount;
	
	@Id
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}
	public float getManagerRatio() {
		return managerRatio;
	}
	public void setManagerRatio(float managerRatio) {
		this.managerRatio = managerRatio;
	}
	public BigDecimal getManagerAmount() {
		return managerAmount;
	}
	public void setManagerAmount(BigDecimal managerAmount) {
		this.managerAmount = managerAmount;
	}
	public float getRewardRatio() {
		return rewardRatio;
	}
	public void setRewardRatio(float rewardRatio) {
		this.rewardRatio = rewardRatio;
	}
	public BigDecimal getRewardAmount() {
		return rewardAmount;
	}
	public void setRewardAmount(BigDecimal rewardAmount) {
		this.rewardAmount = rewardAmount;
	}
	
}
