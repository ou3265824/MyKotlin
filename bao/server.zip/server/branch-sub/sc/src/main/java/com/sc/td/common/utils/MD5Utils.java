package com.sc.td.common.utils;

import org.apache.commons.codec.digest.DigestUtils;

public class MD5Utils {

	private static final String salt="SC@mix@lx100$#365#$";
	
	public static String md5(String str){
		if(StringUtils.isNotBlank(str)){
			return DigestUtils.md5Hex(str);
		}
		return null;
	}
	
	public static String salt(String str){
		if(StringUtils.isNotBlank(str)){
			return salt.charAt(0)+salt.charAt(2)+salt.charAt(4)+salt.charAt(6)+salt.charAt(8)+salt.charAt(10)+str+salt;
		}
		return null;
	}
	
	public static String salt(String str,String salt){
		if(StringUtils.isNotBlank(str) && StringUtils.isNotBlank(salt)){
			return str+salt;
		}
		return null;
	}
	
	public static void main(String[] args) {
		System.out.println(MD5Utils.md5(MD5Utils.salt("4cce20abc430c4fb89ccfc894d86c51c", "2018-01-08 10:37:03")));
	}
}
