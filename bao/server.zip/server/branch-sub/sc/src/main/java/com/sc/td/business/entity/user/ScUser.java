
package com.sc.td.business.entity.user;

import java.io.Serializable;
import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.sc.td.common.utils.StringUtils;

/**
 * 注册用户Entity
 */

@Table
@Entity
public class ScUser implements Serializable {

	/**
	 * 唯一标识
	 */
	private static final long serialVersionUID = 2205393907497644586L;
	private int userId;
	private String userName; // 用户名
	private String mobile; // 手机号码
	private String openId;//微信号
	private String gender;//性别
	private String validCode; // 验证码
	private String validCodeType; // 验证码类型
	private BigDecimal amount;//账户余额
	private String image;//头像
	private String firstLogin;//是否第一次登录
	private String createDate; // 创建日期
	private String updateDate; // 更新日期
	private String easeName;//环信用户名
	private String easePassword;//环信密码
	private String intro;//用户简介
	private String groupLimit;//是否可以创建圈子
	private BigDecimal ableAmount;//可用资金
	private String password;//密码
	private String realName;//真实姓名
	private BigDecimal costAmount;//投入资金
	private String tribeLimit;//是否允许创建部落（T不允许F允许）
	
	public String getTribeLimit() {
		return tribeLimit;
	}

	public void setTribeLimit(String tribeLimit) {
		this.tribeLimit = tribeLimit;
	}

	public BigDecimal getCostAmount() {
		return costAmount;
	}

	public void setCostAmount(BigDecimal costAmount) {
		this.costAmount = costAmount;
	}

	public String getRealName() {
		return realName;
	}

	public void setRealName(String realName) {
		this.realName = realName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public BigDecimal getAbleAmount() {
		return ableAmount;
	}

	public void setAbleAmount(BigDecimal ableAmount) {
		this.ableAmount = ableAmount;
	}

	public String getGroupLimit() {
		return groupLimit;
	}

	public void setGroupLimit(String groupLimit) {
		this.groupLimit = groupLimit;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	@Transient
	public String getEaseName() {
		return easeName;
	}

	public void setEaseName(String easeName) {
		this.easeName = easeName;
	}

	@Transient
	public String getEasePassword() {
		return easePassword;
	}

	public void setEasePassword(String easePassword) {
		this.easePassword = easePassword;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCreateDate() {
		return (StringUtils.isBlank(createDate)) ? createDate : createDate.replace(".0", "");
	}

	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}

	public String getUpdateDate() {
		return (StringUtils.isBlank(updateDate)) ? updateDate : updateDate.replace(".0", "");
	}

	public void setUpdateDate(String updateDate) {
		this.updateDate = updateDate;
	}

	public String getFirstLogin() {
		return firstLogin;
	}

	public void setFirstLogin(String firstLogin) {
		this.firstLogin = firstLogin;
	}

	@Transient
	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Transient
	public String getValidCode() {
		return validCode;
	}

	public void setValidCode(String validCode) {
		this.validCode = validCode;
	}

	@Transient
	public String getValidCodeType() {
		return validCodeType;
	}

	public void setValidCodeType(String validCodeType) {
		this.validCodeType = validCodeType;
	}

}