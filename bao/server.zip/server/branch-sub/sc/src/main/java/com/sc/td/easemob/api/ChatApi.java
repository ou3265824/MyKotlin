package com.sc.td.easemob.api;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.sc.td.easemob.exception.EasemobException;

@Service("chatApi")
public class ChatApi extends BaseApi{

	public JSONObject chatMessages(String time) throws EasemobException{
		String chat_messages_url = getRequestUri1("chat_messages_url",time);
		JSONObject response = get(chat_messages_url, null);
		return response;
	}
}
