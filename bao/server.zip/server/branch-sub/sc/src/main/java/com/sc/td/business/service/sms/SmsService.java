package com.sc.td.business.service.sms;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.td.business.dao.sms.SmsDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.sms.ScSms;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.Global;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.config.SmsTypeEnum;
import com.sc.td.common.utils.RandomCode;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.ip.IpUtils;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.outer.alidayu.Alidayu;
import com.sc.td.outer.alidayu.AlidayuConfig;
import com.sc.td.outer.alidayu.EnumSignName;
import com.sc.td.outer.alidayu.EnumTemplate;
import com.taobao.api.ApiException;

@Service
public class SmsService {

	@Autowired
	private SmsDao smsDao;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScUserDao userDao;
	// /**
	// * 发送手机验证码(腾讯云)
	// *
	// * @param mobile
	// * @return
	// * @throws Exception
	// *
	// */
	// @SuppressWarnings("unchecked")
	// public String sendsms(String json, HttpServletRequest request) throws
	// Exception {
	// HashMap<String, String> jsonMap = JacksonUtil.jsonToObj(json,
	// HashMap.class);
	// String validCodeType = jsonMap.get("validCodeType");
	// String mobile = jsonMap.get("mobile");
	// // 判断该IP在5分钟内请求是否超过3次
	// String requestAddr = IpUtils.getIpAddr(request);
	// String max = TimeUtil.dateTime2Str(DateTime.now(),
	// TimeUtil.DSPdaytimeFormat);
	// String min = TimeUtil.dateTime2Str(
	// TimeUtil.minusTime(DateTime.now(), Global.sendsms_Time,
	// TimeUtil.MINUTES),
	// TimeUtil.DSPdaytimeFormat);
	// List<ScSms> listBySmsTime =
	// smsDao.findByRequestIpAndSmsTimeBetween(requestAddr, min, max);
	// if (listBySmsTime != null && listBySmsTime.size() >=
	// Global.sendsms_limitCount) {
	// return CreateJson.createTextJson(ReturnMsgEnum.sendsmsLimit.toString(),
	// false);
	// } else if (StringUtils.isBlank(validCodeType)) { // 判断验证码的类型是否填写
	// return
	// CreateJson.createTextJson(ReturnMsgEnum.validCodeTypeNull.toString(),
	// false);
	// } else if (!validCodeType.equals(SmsTypeEnum.login.toString())) {
	// return
	// CreateJson.createTextJson(ReturnMsgEnum.validCodeTypeError.toString(),
	// false);
	// } else {
	// // 生成随机验证码
	// String randomCode = RandomCode.getCode(4);
	// ArrayList<String> params = new ArrayList<>();
	// params.add(randomCode);
	// SmsSingleSenderResult smsSingleSenderResult =
	// QcloudSendSms.send(QcloudConfig.appid, QcloudConfig.appkey,
	// QcloudConfig.nationCode, mobile, QcloudConfig.tmplId, params);
	// if (smsSingleSenderResult.result == 0) {
	// // 保存发送记录至数据库
	// ScSms sms = new ScSms();
	// sms.setRecieveNum(mobile);
	// sms.setRequestIp(requestAddr);
	// Map<String, String> contentMap = new HashMap<String, String>();
	// //contentMap.put("tmplId", String.valueOf(QcloudConfig.tmplId));
	// contentMap.put("signName", EnumSignName.appName.toString());
	// contentMap.put("templateCode", String.valueOf(QcloudConfig.tmplId));
	// contentMap.put("validCode", randomCode);
	// sms.setSmsContext(JacksonUtil.objToJson(contentMap));
	// sms.setSmsType(validCodeType);
	// sms.setSmsTime(TimeUtil.dateTime2Str(DateTime.now(),
	// TimeUtil.DSPdaytimeFormat));
	// smsDao.save(sms);
	// // 将验证码保存至Redis中，供登陆验证
	// redisService.set(validCodeType + "-validCode-" + mobile, randomCode,
	// Global.validcode_time);
	// return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.toString(),
	// true);
	// } else {
	// return CreateJson.createTextJson(ReturnMsgEnum.operateFail.toString(),
	// false);
	// }
	// }
	// }

	/**
	 * 发送手机验证码（阿里大于）
	 * 
	 * @param mobile
	 * @return
	 * @throws ApiException
	 * 
	 */
	@SuppressWarnings("unchecked")
	public String sendsms(String jsonText, HttpServletRequest request) throws ApiException {
		HashMap<String, String> jsonMap = JacksonUtil.jsonToObj(jsonText, HashMap.class);
		String validCodeType = jsonMap.get("validCodeType");
		String mobile = jsonMap.get("mobile");
		ScUser user = userDao.findByMobile(mobile);
		if (!validCodeType.equals(SmsTypeEnum.reg.toString()) && user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.toString(), false);
		}else if(validCodeType.equals(SmsTypeEnum.reg.toString()) && user != null){
			return CreateJson.createTextJson(ReturnMsgEnum.userExist.toString(), false);
		}
		// // 判断该IP在5分钟内请求是否超过3次
		String requestAddr = IpUtils.getIpAddr(request);
		// String max = TimeUtil.dateTime2Str(DateTime.now(),
		// TimeUtil.DSPdaytimeFormat);
		// String min = TimeUtil.dateTime2Str(
		// TimeUtil.minusTime(DateTime.now(), Global.sendsms_Time,
		// TimeUtil.MINUTES),
		// TimeUtil.DSPdaytimeFormat);
		// List<ScSms> listBySmsTime =
		// smsDao.findByRequestIpAndSmsTimeBetween(requestAddr, min, max);
		// if (listBySmsTime != null && listBySmsTime.size() >=
		// Global.sendsms_limitCount) {
		// return
		// CreateJson.createTextJson(ReturnMsgEnum.sendsmsLimit.toString(),
		// false);
		// } else
		if (StringUtils.isBlank(validCodeType)) { // 判断验证码的类型是否填写
			return CreateJson.createTextJson(ReturnMsgEnum.validCodeTypeNull.toString(), false);
		} else
			if (!validCodeType.equals(SmsTypeEnum.login.toString()) && !validCodeType.equals(SmsTypeEnum.reg.toString())
					&& !validCodeType.equals(SmsTypeEnum.fgtPwd.toString())
					&& !validCodeType.equals(SmsTypeEnum.resetPwd.toString())) {
			return CreateJson.createTextJson(ReturnMsgEnum.validCodeTypeError.toString(), false);
		} else {
			// 生成随机验证码
			String randomCode = RandomCode.getCode(4);
			String params = Alidayu.setParams(randomCode, EnumSignName.appName.toString());
			String response = Alidayu.sendSms_validateCode(params, mobile, EnumSignName.appName,
					EnumTemplate.validCode);
			Map<String, Object> map = JacksonUtil.jsonToObj(response, HashMap.class);
			if (map.containsKey(AlidayuConfig.successKey)) {
				HashMap<String, Object> h = (HashMap<String, Object>) map.get(AlidayuConfig.successKey);
				HashMap<String, Object> m = (HashMap<String, Object>) h.get("result");
				String err_code = (String) m.get("err_code");
				if (err_code.equals(AlidayuConfig.successCode)) {
					// 短信发送成功后，将验证码储存在redis中，供注册时验证
					redisService.set(validCodeType + "-validCode-" + mobile, randomCode,
							Integer.parseInt(Global.validcode_livetime));
					// 保存发送记录至数据库
					ScSms sms = new ScSms();
					sms.setRecieveNum(mobile);
					sms.setRequestIp(requestAddr);
					Map<String, String> contentMap = new HashMap<String, String>();
					// contentMap.put("tmplId",
					// String.valueOf(QcloudConfig.tmplId));
					contentMap.put("signName", EnumSignName.appName.toString());
					contentMap.put("templateCode", EnumTemplate.validCode.getName());
					contentMap.put("validCode", randomCode);
					sms.setSmsContext(JacksonUtil.objToJson(contentMap));
					sms.setSmsType(validCodeType);
					sms.setSmsTime(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
					smsDao.save(sms);
					return CreateJson.createTextJson(null, true);
				} else {
					return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.toString(), true);
				}
			} else {
				return CreateJson.createTextJson(ReturnMsgEnum.operateFail.toString(), false);
			}
		}
	}
}
