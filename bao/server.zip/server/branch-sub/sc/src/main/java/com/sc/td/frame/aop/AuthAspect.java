package com.sc.td.frame.aop;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.groupauth.ScGroupAuthDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.groupauth.ScGroupAuth;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.UnicodeUtils;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.jwt.Jwt;
import com.sc.td.frame.annotation.AuthCheck;

import javassist.NotFoundException;

@Component
@Aspect
public class AuthAspect {

	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ScGroupAuthDao scGroupAuthDao;

	@Autowired
	private ScGroupDao groupDao;
	
	@Pointcut("execution(* com.sc.td.business..*.*(..))")
	public void init() {

	}

	@SuppressWarnings("unchecked")
	@Around(value = "init() && @annotation(ac)")
	public Object before(ProceedingJoinPoint point, AuthCheck ac) throws IOException, NotFoundException, ClassNotFoundException {
		Object o = null;
		Object[] args = point.getArgs();
		Integer groupId = null;
		Signature signature = point.getSignature();
		MethodSignature methodSignature = (MethodSignature) signature;
		String[] paramsArr = methodSignature.getParameterNames();
		for (int i = 0; i < paramsArr.length; i++) {
			if (paramsArr[i].equals("groupId")) {
				groupId = (Integer) args[i];
			}
		}
		HttpServletResponse response = null;
		HttpServletRequest request = null;
		for (int i = 0; i < args.length; i++) {
			if (args[i] instanceof HttpServletResponse) {
				response = (HttpServletResponse) args[i];
			} else if (args[i] instanceof HttpServletRequest) {
				request = (HttpServletRequest) args[i];
			}
		}
		String permission = ac.value();// 权限名
		String resp = CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
		if (StringUtils.isBlank(permission)) {
			response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
		} else {
			// 验证当前用户是否有此权限
			// 1、从token中获取用户ID
			String token = request.getHeader("token");
			Map<String, Object> resultMap = Jwt.validToken(token);
			Map<String, Object> dataMap = new HashMap<String, Object>();
			dataMap = (HashMap<String, Object>) resultMap.get("data");
			String userId = String.valueOf(dataMap.get("userId"));
			ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
			if(group==null){
				resp = CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
				response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			}
			List<ScGroupAuth> auth = scGroupAuthDao.findByGroupIdAndUserIdAndPermissionAndIsAble(DictEnum.enable.value,groupId,
					Integer.parseInt(userId), permission);
			if (group.getUserId()!=Integer.parseInt(userId) && !(auth != null && auth.size() > 0)) {
				response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			}else{
				try {
			        //执行
			        o = point.proceed(point.getArgs());
			    } catch (Throwable e) {
			        e.printStackTrace();
			        String className = point.getThis().toString();  
			        String methodName = point.getSignature().getName(); 
			        log.error(className+"."+methodName+" Exception:"+e.getMessage());	     
			        resp = CreateJson.createTextJson(ReturnMsgEnum.sysExeption.getMessage(), false);
			        response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			    }
			}
		}
		return o;
	}

}
