package com.sc.td.easemob.model;

import java.io.Serializable;
import java.util.List;

import com.alibaba.fastjson.annotation.JSONField;

public class Group implements Serializable{

	private static final long serialVersionUID = 7319838319943014988L;

	@JSONField(name = "groupname")
	private String groupName;//群组名称，此属性为必须的
	private String desc;//群组描述，此属性为必须的
	@JSONField(name = "public")
	private boolean isPublic;//是否是公开群，此属性为必须的
	@JSONField(name = "maxusers")
	private int maxUsers;//群组成员最大数（包括群主），值为数值类型，默认值200，最大值2000，此属性为可选的
	@JSONField(name = "members_only")
	private boolean membersOnly;// 加入群是否需要群主或者群管理员审批，默认是false
	@JSONField(name = "allowinvites")
	private boolean allowInvites;//是否允许群成员邀请别人加入此群。 true：允许群成员邀请人加入此群，false：只有群主或者管理员才可以往群里加人。
	private String owner;//群组的管理员，此属性为必须的
	@JSONField(name = "members")
	private List<String> members;//群组成员，此属性为可选的，但是如果加了此项，数组元素至少一个（注：群主jma1不需要写入到members里面）
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	public boolean isPublic() {
		return isPublic;
	}
	public void setPublic(boolean isPublic) {
		this.isPublic = isPublic;
	}
	public int getMaxUsers() {
		return maxUsers;
	}
	public void setMaxUsers(int maxUsers) {
		this.maxUsers = maxUsers;
	}
	public boolean isMembersOnly() {
		return membersOnly;
	}
	public void setMembersOnly(boolean membersOnly) {
		this.membersOnly = membersOnly;
	}
	public boolean isAllowInvites() {
		return allowInvites;
	}
	public void setAllowInvites(boolean allowInvites) {
		this.allowInvites = allowInvites;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public List<String> getMembers() {
		return members;
	}
	public void setMembers(List<String> members) {
		this.members = members;
	}
	@Override
	public String toString() {
		return "Group [groupName=" + groupName + ", desc=" + desc + ", isPublic=" + isPublic + ", maxUsers=" + maxUsers
				+ ", membersOnly=" + membersOnly + ", allowInvites=" + allowInvites + ", owner=" + owner + ", members="
				+ members + "]";
	}
	
}
