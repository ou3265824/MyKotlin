package com.sc.td.common.utils.mail;
public class SendMail {
	
	public static boolean sendMail(MailSenderInfo mailSenderInfo){		
		//System.out.println("服务器地址："+mailSenderInfo.getMailServerHost());
		MailSenderInfo mailInfo = new MailSenderInfo();   
	    mailInfo.setMailServerHost(mailSenderInfo.getMailServerHost());   
	    mailInfo.setMailServerPort(mailSenderInfo.getMailServerPort());   
	    mailInfo.setValidate(true);   
	    mailInfo.setUserName(mailSenderInfo.getFromAddress());   
	    mailInfo.setPassword(mailSenderInfo.getPassword());//您的邮箱密码   
	    mailInfo.setFromAddress(mailSenderInfo.getFromAddress());
	    mailInfo.setContent(mailSenderInfo.getContent());
	    mailInfo.setToAddress(mailSenderInfo.getToAddress());   
	    mailInfo.setSubject(mailSenderInfo.getSubject()); 
	     
        //这个类主要来发送邮件  
        SimpleMailSender sms = new SimpleMailSender();  
        return sms.sendTextMail(mailInfo);//发送文体格式   
        //return sms.sendHtmlMail(mailInfo);//发送html格式  
		
	}
	
	
	/*public static void main(String[] args) {
		MailSenderInfo mailInfo= new MailSenderInfo();
		String oppo = "反应太慢";
		mailInfo.setMailServerHost("smtp.mxhichina.com");   
	     mailInfo.setMailServerPort("25");   
	     mailInfo.setValidate(true);   
	     mailInfo.setUserName("octplus@wtrade365.com");   
	     mailInfo.setPassword("oct!@#456");//您的邮箱密码   
	     mailInfo.setFromAddress("octplus@wtrade365.com");   
	     mailInfo.setToAddress("service@wtrade365.com");   
	     mailInfo.setSubject("用户xxx的投诉与建议");
	     System.out.println("服务器地址："+mailInfo.getMailServerHost());
	     StringBuffer sb = new StringBuffer();
	     sb.append("                                         用户xxx的投诉与建议");
	     sb.append("\n\n");
	     sb.append("内容:");
	     sb.append("  ");
	     sb.append(oppo);
	     sb.append("\n\n");
	     sb.append("联系方式:");
	     sb.append("  ");
	     sb.append("15903905658");
	     String content ="";
			content +="<table width='600px' border='1'><tr style='background-color:rgb(208, 240, 238)'><td colspan='3' align='center'><p>OTT用户注册信息</p></td></tr></table>";
			content += "<table style='width:600px'><tr style='background-color:#f0f0f0'><td>OTT名称</td><td>登录ID</td><td>登录密码</td><td>注册时间</td>";
			content +="<tr style='background-color:rgb(200, 225, 241)'><td>"+info.getOttName()+"</td><td>"+info.getOttID()+"</td><td>"+info.getPassword()+"</td><td>"+info.getRegtime()+"</td>";
			content +="</table>";
			
			mailInfo.setContent(sb.toString());   
	        //这个类主要来发送邮件  
	        SimpleMailSender sms = new SimpleMailSender();  
	        sms.sendTextMail(mailInfo);
	}*/
}
