package com.sc.td.business.dao.sms;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.sms.ScSms;

public interface SmsDao extends BaseDao<ScSms>{

	List<ScSms> findByRequestIpAndSmsTimeBetween(String requestAddr, String min, String max);

}
