package com.sc.td.business.entity.groupauth;

import java.io.Serializable;

public class ScGroupRoleAuthPk implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int roleId;
	private int authId;
	
	public ScGroupRoleAuthPk() {
		super();
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + authId;
		result = prime * result + roleId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ScGroupRoleAuthPk other = (ScGroupRoleAuthPk) obj;
		if (authId != other.authId)
			return false;
		if (roleId != other.roleId)
			return false;
		return true;
	}
}
