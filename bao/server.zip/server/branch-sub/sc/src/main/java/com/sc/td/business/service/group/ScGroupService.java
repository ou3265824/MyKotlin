package com.sc.td.business.service.group;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.group.ScGroupApplyDao;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.group.ScGroupMemberDao;
import com.sc.td.business.dao.groupauth.ScGroupAuthDao;
import com.sc.td.business.dao.groupauth.ScGroupRoleDao;
import com.sc.td.business.dao.groupauth.ScGroupUserRoleDao;
import com.sc.td.business.dao.release.ScReleaseDao;
import com.sc.td.business.dao.release.ScReleaseUserDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.group.ScGroupApply;
import com.sc.td.business.entity.group.ScGroupMember;
import com.sc.td.business.entity.group.dto.MemberDto;
import com.sc.td.business.entity.groupauth.ScGroupAuth;
import com.sc.td.business.entity.groupauth.ScGroupRole;
import com.sc.td.business.entity.groupauth.ScGroupUserRole;
import com.sc.td.business.entity.release.ScRelease;
import com.sc.td.business.entity.release.ScReleaseUser;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.business.entity.user.dto.GroupUserDto;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.Global;
import com.sc.td.common.config.MsgEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.config.SystemConfig;
import com.sc.td.common.utils.FileUtils;
import com.sc.td.common.utils.RandomCode;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.image.ImgBase64;
import com.sc.td.common.utils.image.ImgCreate;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.easemob.api.GroupApi;
import com.sc.td.easemob.exception.EasemobException;

@Service
public class ScGroupService extends BaseService {

	private static Logger log = LoggerFactory.getLogger(ScGroupService.class);
	@Autowired
	private ScGroupDao groupDao;

	@Autowired
	private ScGroupMemberDao groupMemberDao;

	@Autowired
	private ScUserDao userDao;

	@Autowired
	private ScGroupApplyDao groupApplyDao;

	@Autowired
	private ScReleaseDao releaseDao;

	@Autowired
	private GroupApi groupApi;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScReleaseUserDao releaseUserDao;

	@Autowired
	private ScGroupRoleDao groupRoleDao;

	@Autowired
	private ScGroupUserRoleDao groupUserRoleDao;

	@Autowired
	private ScGroupAuthDao groupAuthDao;

	@Autowired
	private SystemConfig sysCfg;
	
	/**
	 * 根据用户名查找圈子内用户
	 * @param groupId
	 * @param userName
	 * @return
	 */
	public String memberByNameLike(Integer groupId,String userName){
		List<ScGroupMember> list = groupMemberDao.findByGroupIdAndUserNameLike(groupId, userName);
		List<MemberDto> dataList=handlerMember(list);
		if(dataList!=null && dataList.size()>0){
			return CreateJson.createObjJson(dataList, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false); 
	}
	/**
	 * 获取圈子内所有成员
	 * @param groupId
	 * @return
	 */
	public String allGroupMember(Integer groupId){
		List<ScGroupMember> list = groupMemberDao.findByGroupId(groupId);
		List<MemberDto> dataList=handlerMember(list);
		if(dataList!=null && dataList.size()>0){
			return CreateJson.createObjJson(dataList, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	public List<MemberDto> handlerMember(List<ScGroupMember> list){
		List<MemberDto> dataList=Lists.newArrayList();
		if(list!=null && list.size()>0){
			for(ScGroupMember sc:list){
				ScUser user=userDao.findByUserId(sc.getUserId());
				if(user!=null){
					MemberDto dto=new MemberDto();
					dto.setUserId(user.getUserId());
					dto.setUserName(getUserName(user));
					dataList.add(dto);
				}
			}
		}
		return dataList;
	}
	/**
	 * 生成邀请码
	 * 
	 * @param groupId
	 * @return
	 */
	public String generateCode(Integer groupId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		String oldCode=redisService.get(DictEnum.redisJoinGroupIdPrefix.value + String.valueOf(groupId));
		if(StringUtils.isNotBlank(oldCode)){
			redisService.del(DictEnum.redisJoinGroupCodePrefix.value + oldCode);
		}
		String code = null;
		try {
			while (true) {
				code = RandomCode.getCode(4);
				if (StringUtils.isBlank(redisService.get(DictEnum.redisJoinGroupCodePrefix.value + code))) {
					break;
				}
			}
			if (StringUtils.isNotBlank(code)) {
				redisService.set(DictEnum.redisJoinGroupCodePrefix.value + code, String.valueOf(groupId),Global.groupcode_time);
				redisService.set(DictEnum.redisJoinGroupIdPrefix.value + String.valueOf(groupId), code,Global.groupcode_time);
				return CreateJson.createObjJson(code, true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	
	/**
	 * 获取邀请码
	 * @param groupId
	 * @return
	 */
	public String obtainCode(Integer groupId) {
		String code = redisService.get(DictEnum.redisJoinGroupIdPrefix.value + String.valueOf(groupId));
		if(StringUtils.isNotBlank(code)){
			return CreateJson.createObjJson(code, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 根据邀请码加入活动
	 * 
	 * @param userId
	 * @param code
	 * @return
	 */
	@Transactional
	public String joinGroupByCode(Integer userId, String code) {
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		String groupId = redisService.get(DictEnum.redisJoinGroupCodePrefix.value + code);
		if (StringUtils.isBlank(groupId)) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		ScGroupMember member = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId), userId,
				DictEnum.not_del.value);
		if (member != null) {
			return CreateJson.createTextJson(ReturnMsgEnum.alreadyInGroup.getMessage(), false);
		}
		ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		} else {
			ScGroupMember sc = addMember(Integer.parseInt(groupId), userId);
			if (groupMemberDao.save(sc) != null) {
				// 将用户加入到环信的群组
				String easeUserId = redisService.hget(DictEnum.redisAppEaseUserKey.value,
						String.valueOf(user.getUserId()));
				String easeGroupId = redisService.hget(DictEnum.redisAppEaseGroupKey.value, groupId);
				try {
					if(StringUtils.isBlank(easeUserId)){
						user=checkEaseUser(user);
						easeUserId=user.getEaseName();
					}
					if(StringUtils.isBlank(easeGroupId)){
						group = checkEaseGroup(group);
						easeGroupId=group.getEaseGroupId();
					}
					groupApi.addGroupMember(easeUserId, easeGroupId);
				} catch (Exception e) {
					log.error(e.getMessage());
					if(StringUtils.isNotBlank(easeUserId) && StringUtils.isNotBlank(easeGroupId)){
						redisService.hset(DictEnum.redisJoinExceptionKey.value, easeUserId,easeGroupId);
					}
				}

				// 创建消息
				String content = setSysContent(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()),
						group.getGroupName(), "用户" + getUserName(user) + "加入活动" + group.getGroupName(),
						TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
				createNotify(String.valueOf(group.getUserId()), MsgEnum.sys.value, MsgEnum.group_check.desc, content);
				
				return CreateJson.createObjJson(group(String.valueOf(group.getGroupId()), String.valueOf(userId)), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 审核加入/退出环信群组时异常
	 * 
	 * @param userId
	 * @param groupId
	 * @return
	 */
	public String joinOrQuitException(String type, String easeUserId, String easeGroupId) {
		if (StringUtils.isBlank(type) || !(type.equals(DictEnum.join.value) || type.equals(DictEnum.quit.value))) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsError.getMessage(), false);
		}
		if (easeUserId != null && easeGroupId != null) {
			redisService.hset(type + "-group-exception", easeUserId, easeGroupId);
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 绑定环信群组
	 * 
	 * @param groupId
	 * @param easeGroupId
	 * @return
	 */
	@Deprecated
	public String bindGroup(String groupId, String easeGroupId) {
		if (StringUtils.isBlank(groupId) || StringUtils.isBlank(easeGroupId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		redisService.hset(DictEnum.redisEaseAppGroupKey.value, easeGroupId, groupId);
		redisService.hset(DictEnum.redisAppEaseGroupKey.value, groupId, easeGroupId);
		return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
	}

	/**
	 * 创建圈子 APP服务器创建圈子后，调用环信接口创建环信群聊，同时将圈子的ID与环信群ID的对应关系保存至redis中
	 * 
	 * @param json
	 * @return
	 * @throws EasemobException
	 * @throws IOException
	 */
	public String create(String json, HttpServletRequest request) throws EasemobException, IOException {
		String token = request.getHeader("token");
		ScGroup group = JacksonUtil.jsonToObj(json, ScGroup.class);
		if (group != null && StringUtils.isNotBlank(String.valueOf(group.getUserId()))
				&& StringUtils.isNotBlank(group.getGroupName())) {
			ScUser user = userDao.findByUserId(group.getUserId());
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			if (!checkToken(token, user.getMobile())) {
				return CreateJson.createTextJson(ReturnMsgEnum.tokenIllegal.getMessage(), false);
			}
			// 判断圈子名是否重复
			List<ScGroup> findByGroupName = groupDao.findByGroupName(group.getGroupName());
			if (findByGroupName != null && findByGroupName.size() > 0) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNameExist.getMessage(), false);
			}
			group.setInitValue(group, String.valueOf(group.getUserId()));
			if (groupDao.save(group) != null) {
				// 生成圈子头像,如果客户端没有传递img，则生成默认图片
				boolean b = true;
				if (StringUtils.isBlank(group.getGroupImg())) {
					b = false;
				} else {
					String imageName = group.getGroupImg();// 图片名
					// 判断该图片在示例图片中是否存在
					String srcPath = sysCfg.getUserfiles_groupexample_url() + imageName + DictEnum.picFormat.value;
					File file = new File(srcPath);
					// 如果图片存在，则复制图片至圈子头像的文件夹中，并更改图片名（以圈子ID为图片名）
					if (file.exists()) {
						FileUtils.copyFileToDirectory(new File(srcPath), new File(sysCfg.getUserfiles_group_url()), true);
						File groupImageFile = new File(sysCfg.getUserfiles_group_url() + imageName + DictEnum.picFormat.value);
						if (groupImageFile.exists()) {
							groupImageFile.renameTo(new File(sysCfg.getUserfiles_group_url() + group.getUserId() + "-"
									+ group.getGroupId() + DictEnum.picFormat.value));
						}
					} else {
						b = false;
					}
				}
				if (!b) {
					ImgCreate imgCreate = new ImgCreate();
					imgCreate.createImage(sysCfg.getUserfiles_group_url(), group.getGroupName(),
							String.valueOf(group.getGroupId()));
				}
				// 上传成功之后，将时间戳保存至redis中
				long time = System.currentTimeMillis();
				redisService.hset(DictEnum.redisGroupImageTimestampKey.value,
						group.getUserId() + "-" + group.getGroupId(), String.valueOf(time));
				group.setGroupImg(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
				// 将该用户加入到群组用户对应表
				ScGroupMember groupMember = new ScGroupMember();
				groupMember.setGroupId(group.getGroupId());
				groupMember.setUserId(group.getUserId());
				groupMember.setInitValue(groupMember, String.valueOf(group.getUserId()));
				if (groupMemberDao.save(groupMember) != null) {
					group = checkEaseGroup(group);
					group.setUserName(getUserName(user));
					group.setUserImg(getUserImagePath(user.getMobile()));
					group.setIsJoin(true);
					group.setPeopleCount(
							groupMemberDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
					group.setReleaseCount(
							releaseDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
					group.setReleaseLimit(groupMember.getReleaseLimit());
					// 圈子创建成功之后，将圈子创建者设置为超级管理员
					List<ScGroupRole> roleList = groupRoleDao.findByType(DictEnum.admin.value);
					if (roleList != null && roleList.size() > 0) {
						ScGroupRole role = roleList.get(0);
						ScGroupUserRole sc = new ScGroupUserRole();
						sc.setGroupId(group.getGroupId());
						sc.setRoleId(role.getId());
						sc.setUserId(group.getUserId());
						groupUserRoleDao.save(sc);
					}
					return CreateJson.createObjJsonWithToken(createToken(user), group);
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 申请加入圈子（手机端发送请求）
	 * 
	 * @param json
	 * @return
	 * @throws EasemobException
	 */
	@Transactional
	public String joinApply(String json) throws EasemobException {
		ScGroupApply groupApply = JacksonUtil.jsonToObj(json, ScGroupApply.class);
		if (groupApply != null && StringUtils.isNotBlank(String.valueOf(groupApply.getGroupId()))
				&& StringUtils.isNotBlank(String.valueOf(groupApply.getUserId()))) {
			ScUser applyUser = userDao.findByUserId(groupApply.getUserId());
			if (applyUser == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			ScGroup group = groupDao.findByGroupIdAndDelFlag(groupApply.getGroupId(), DictEnum.not_del.value);
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			ScUser auditUser = userDao.findByUserId(group.getUserId());
			if (auditUser == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			// 判断该用户是否已经在该圈子内
			ScGroupMember member = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(group.getGroupId(),
					groupApply.getUserId(), DictEnum.not_del.value);
			if (member != null) {
				return CreateJson.createTextJson(ReturnMsgEnum.alreadyInGroup.getMessage(), false);
			}
			groupApply.setStatus(DictEnum.apply.value);
			groupApply.setAuditView(DictEnum.not_ignore.value);
			groupApply.setAuditBy(group.getUserId());
			groupApply.setApplyDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
			groupApply.setDelFlag(DictEnum.not_del.value);
			groupApply.setReadFlag(MsgEnum.not_read.value);
			if (groupApplyDao.save(groupApply) != null) {
				// 申请成功之后，服务器创建一条消息记录保存在数据库中
				// Map<String,String> map=Maps.newHashMap();
				// map.put("userId", String.valueOf(applyUser.getUserId()));
				// map.put("userName", applyUser.getUserName());
				// map.put("userImage",
				// getUserImagePath(applyUser.getMobile()));
				// map.put("auditUserId",
				// String.valueOf(auditUser.getUserId()));
				// map.put("reason",groupApply.getApplyContent());
				// map.put("applyDate", groupApply.getApplyDate());
				// map.put("groupId", String.valueOf(group.getGroupId()));
				// map.put("groupName", group.getGroupName());
				// map.put("status", groupApply.getStatus());
				// map.put("easeGroupId",
				// redisService.hget(DictEnum.redisAppEaseGroupKey.value,
				// String.valueOf(group.getGroupId())));
				// map.put("easeApplyUserId",
				// redisService.hget(DictEnum.redisAppEaseUserKey.value,
				// String.valueOf(applyUser.getUserId())));
				// createNotify(String.valueOf(auditUser.getUserId()),
				// MsgEnum.group_check.value, MsgEnum.group_check.desc,
				// JacksonUtil.objToJson(map));
				groupApply.setUserName(getUserName(applyUser));
				groupApply.setUserImage(getUserImagePath(applyUser.getMobile()));
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 圈子加入新成员
	 * 
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public ScGroupMember addMember(int groupId, int userId) {
		ScGroupMember groupMember = new ScGroupMember();
		groupMember.setGroupId(groupId);
		groupMember.setUserId(userId);
		groupMember.setInitValue(groupMember, String.valueOf(userId));
		groupMember.setArticleLimit(DictEnum.positive.value);
		groupMember.setArticleCommentLimit(DictEnum.positive.value);
		groupMember.setReleaseLimit(DictEnum.positive.value);
		groupMember.setReleaseCommentLimit(DictEnum.positive.value);
		return groupMember;
	}

	/**
	 * 忽略验证信息（管理员）
	 * 
	 * @param json
	 * @return
	 */
	public String ignore(String json) {
		@SuppressWarnings("unchecked")
		HashMap<String, String> map = JacksonUtil.jsonToObj(json, HashMap.class);
		if (map != null && map.size() > 0) {
			String groupId = map.get("groupId");
			String userId = map.get("userId");
			if (StringUtils.isNotBlank(groupId) && StringUtils.isNotBlank(userId)) {
				ScGroupApply groupApply = groupApplyDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId),
						Integer.parseInt(userId), DictEnum.not_del.value);
				ScUser user = userDao.findByUserId(Integer.parseInt(userId));
				if (groupApply != null && user != null) {
					groupApply.setAuditView(DictEnum.ignore.value);
					if (groupApplyDao.save(groupApply) != null) {
						return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
					}
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 批准/拒绝加入圈子（服务端处理请求） 处理单条记录 接收手机端发送的请求，管理员进行审核
	 * 
	 * @param json
	 * @return
	 * @throws EasemobException
	 */
	@Transactional
	public String audit(String groupId, String applyUserId, String auditUserId, String status) throws EasemobException {
		if (StringUtils.isBlank(groupId) || StringUtils.isBlank(applyUserId) || StringUtils.isBlank(auditUserId)
				|| StringUtils.isBlank(status)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		// 判断审核人是否为圈子创建者
		if (group.getUserId() != Integer.parseInt(auditUserId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
		}
		// 判断该用户是否已经在该圈子内
		ScGroupMember member = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(group.getGroupId(),
				Integer.parseInt(applyUserId), DictEnum.not_del.value);
		if (member != null) {
			return CreateJson.createTextJson(ReturnMsgEnum.alreadyInGroup.getMessage(), false);
		}
		ScGroupApply scGroupApply = groupApplyDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId),
				Integer.parseInt(applyUserId), DictEnum.not_del.value);
		ScUser applyUser = userDao.findByUserId(Integer.parseInt(applyUserId));
		ScUser operateUser = userDao.findByUserId(Integer.parseInt(auditUserId));
		if (scGroupApply != null && applyUser != null && operateUser != null
				&& StringUtils.isNotBlank(scGroupApply.getStatus())) {
			scGroupApply.setStatus(status);
			scGroupApply.setAuditBy(Integer.parseInt(auditUserId));
			scGroupApply.setApplyDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
			if (groupApplyDao.save(scGroupApply) != null) {
				scGroupApply.setUserName(getUserName(applyUser));
				scGroupApply.setUserImage(getUserImagePath(applyUser.getMobile()));
				if (scGroupApply.getStatus().equals(DictEnum.audit_pass.value)) {
					// 同意加入圈子
					ScGroupMember addMember = addMember(Integer.parseInt(groupId), Integer.parseInt(applyUserId));
					if (groupMemberDao.save(addMember) != null) {
						// 创建消息至申请者
						String content = setSysContent(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()),
								group.getGroupName(), "管理员同意加入圈子",
								TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
						createNotify(applyUserId, MsgEnum.sys.value, MsgEnum.group_check.desc, content);
					}
				} else if (scGroupApply.getStatus().equals(DictEnum.audit_refuse.value)) {
					// 拒绝加入圈子，创建一条系统消息
					String content = setSysContent(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()),
							group.getGroupName(), "管理员拒绝了您的加群请求",
							TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
					createNotify(applyUserId, MsgEnum.sys.value, MsgEnum.sys.desc, content);
				}
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 通过UserId查找该用户所加入的圈子
	 * 
	 * @param json
	 * @return
	 */
	public String findMyJoin(String userId) throws NumberFormatException {
		if (StringUtils.isNotBlank(userId)) {
			int id = Integer.parseInt(userId);
			ScUser user = userDao.findByUserId(id);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			List<ScGroupMember> list = groupMemberDao.findByUserIdAndDelFlagOrderByUpdateDateDesc(id, DictEnum.not_del.value);
			List<ScGroup> dataList = Lists.newArrayList();
			if (list != null) {
				for (ScGroupMember sc : list) {
					ScGroup group = groupDao.findByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value);
					if (group != null) {
						ScUser groupUser = userDao.findByUserId(group.getUserId());
						if (groupUser != null) {
							group.setUserName(getUserName(groupUser));
							group.setUserImg(getUserImagePath(groupUser.getMobile()));
						}
						group.setIsJoin(true);
						group.setGroupImg(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
						group.setPeopleCount(
								groupMemberDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
						group.setReleaseCount(
								releaseDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
						group.setReleaseLimit(sc.getReleaseLimit());
						// 获取环信的圈子ID
						group.setEaseGroupId(redisService.hget(DictEnum.redisAppEaseGroupKey.value,
								String.valueOf(group.getGroupId())));
						dataList.add(group);
					}
				}
			}
			if (dataList != null && dataList.size() > 0) {
				return CreateJson.createObjJson(dataList, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	public Page<ScGroup> getSourceCode(int pageNumber, int pageSize, Sort sort) {
		PageRequest request = this.buildPageRequest(pageNumber, pageSize, sort);
		Page<ScGroup> sourceCodes = this.groupDao.findAll(request);
		return sourceCodes;
	}

	private PageRequest buildPageRequest(int pageNumber, int pagzSize, Sort sort) {
		return new PageRequest(pageNumber - 1, pagzSize, sort);
	}

	/**
	 * 获取热门圈子（目前为获取全部圈子）
	 * 
	 * @param groupId
	 * @param index
	 * @param size
	 * @return
	 */
	public String hotGroup(String userId, String index1, String size1) {
		if (StringUtils.isBlank(userId)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		Page<ScGroup> page = getSourceCode(pageInfo.get_pageno(), pageInfo.get_size(),
				new Sort(Direction.DESC, "createDate"));
		if (page != null && page.getContent() != null && page.getContent().size() > 0) {
			for (ScGroup sc : page.getContent()) {
				sc.setGroupImg(getGroupImagePath(sc.getUserId() + "-" + sc.getGroupId()));
				// 判断当前用户是否加入该圈子
				ScGroupMember groupMember = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(sc.getGroupId(),
						Integer.parseInt(userId), DictEnum.not_del.value);
				if (groupMember != null) {
					sc.setIsJoin(true);
					sc.setReleaseLimit(groupMember.getReleaseLimit());
				} else {
					sc.setIsJoin(false);
				}
				// 获取环信的圈子ID
				sc.setEaseGroupId(
						redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(sc.getGroupId())));
				ScUser user = userDao.findByUserId(sc.getUserId());
				if (user != null) {
					sc.setUserName(getUserName(user));
					sc.setUserImg(getUserImagePath(user.getMobile()));
				}
				sc.setPeopleCount(groupMemberDao.countByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value));
				sc.setReleaseCount(releaseDao.countByGroupIdAndDelFlag(sc.getGroupId(), DictEnum.not_del.value));
			}
			return CreateJson.createObjJson(page.getContent(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 上传头像
	 * 
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 */
	@Transactional
	public String uploadImg(String jsonText, HttpServletRequest request) throws UnknownHostException {
		String token = request.getHeader("token");
		// 解析json数据
		@SuppressWarnings({ "unchecked", "rawtypes" })
		HashMap<String, String> dataMap = (HashMap) JacksonUtil.jsonToObj(jsonText, Object.class);
		// 得到img的字符串数据
		String imgStr = dataMap.get("img");
		// 圈子ID
		String groupId = dataMap.get("groupId");
		// 手机号
		String mobile = dataMap.get("mobile");
		if (StringUtils.isBlank(imgStr) || StringUtils.isBlank(groupId) || StringUtils.isBlank(mobile)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		if (!checkToken(token, mobile)) {
			return CreateJson.createTextJson(ReturnMsgEnum.tokenIllegal.getMessage(), false);
		}
		// 检查该手机号用户是否存在
		ScUser scUser = userDao.findByMobile(mobile);
		ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
		String fileName = group.getUserId() + "-" + group.getGroupId() + DictEnum.picFormat.value;
		if (scUser != null && group != null) {
			// 判断该用户是否有此权限
			if (scUser.getUserId() != group.getUserId()) {
				return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
			}
			// 上传头像
			boolean b = ImgBase64.GenerateImage(imgStr, sysCfg.getUserfiles_group_url(), fileName);
			if (b) {
				// 上传成功之后，修改redis内的时间戳
				long time = System.currentTimeMillis();
				redisService.hset(DictEnum.redisGroupImageTimestampKey.value,
						group.getUserId() + "-" + group.getGroupId(), String.valueOf(time));
				group.setGroupImg(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
				return CreateJson.createObjJson(group, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 查询圈子内的成员
	 * 
	 * @param groupId
	 * @param index1
	 * @param size1
	 * @return
	 */
	public String groupMember(String groupId, String index1, String size1) {
		if (StringUtils.isNotBlank(groupId)) {
			ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			PageInfo pageInfo = getPageIndexAndSize(index1, size1);
			List<ScGroupMember> list = findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value,
					pageInfo.get_pageno(), pageInfo.get_size());
			TreeSet<GroupUserDto> set =Sets.newTreeSet();
			if (list != null && list.size() > 0) {
				for (ScGroupMember member : list) {
					ScUser user = userDao.findByUserId(member.getUserId());
					if (user != null) {
						GroupUserDto dto=new GroupUserDto();
						dto.setUserId(user.getUserId());
						dto.setUserName(getUserName(user));
						dto.setImage(getUserImagePath(user.getMobile()));
						dto.setJoinTime(member.getCreateDate());
						//是否管理员
						Long countAdmin = groupUserRoleDao.countByGroupIdAndUserIdAndType(Integer.parseInt(groupId), user.getUserId(), DictEnum.admin.value);
						Long countManager = groupUserRoleDao.countByGroupIdAndUserIdAndType(Integer.parseInt(groupId), user.getUserId(), DictEnum.manager.value);
						if(countAdmin>0){
							dto.setAdmin(true);
						}
						if(countManager>0){
							dto.setManager(true);
						}
						set.add(dto);
					}
				}
			}
			if (set != null && set.size() > 0) {
				return CreateJson.createObjJson(set, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 修改群组信息
	 * 
	 * @param jsonText
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws EasemobException
	 */
	@Transactional
	public String modify(String jsonText)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, EasemobException {
		@SuppressWarnings("unchecked")
		HashMap<String, String> map = JacksonUtil.jsonToObj(jsonText, HashMap.class);
		String userId = map.get("userId");// 当前操作用户的ID
		String groupId = map.get("groupId");
		String column = map.get("column");
		String value = map.get("value");
		if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(groupId) && StringUtils.isNotBlank(column)
				&& StringUtils.isNotBlank(value)) {
			ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			if (Integer.parseInt(userId) != group.getUserId()) {
				return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
			}
			if (column.equals("groupName")) {
				String groupName_old = group.getGroupName();
				if (StringUtils.isBlank(groupName_old)
						|| (StringUtils.isNotBlank(groupName_old) && !groupName_old.equals(value))) {
					// 判断圈子名是否重复
					List<ScGroup> findByGroupName = groupDao.findByGroupName(value);
					if (findByGroupName != null && findByGroupName.size() > 0) {
						return CreateJson.createTextJson(ReturnMsgEnum.groupNameExist.getMessage(), false);
					}
				}
			}
			String key = "set" + toUpperKey(column);
			Method[] methods = group.getClass().getMethods();
			for (Method method : methods) {
				if (key.equals(method.getName())) {
					method.invoke(group, value);
					break;
				}
			}
			if (groupDao.save(group) != null) {
				// //获取环信群组ID
				// String easeGroupId =
				// redisService.hget(DictEnum.redisAppEaseGroupKey.value,
				// String.valueOf(group.getGroupId()));
				// Map<String,String> params=Maps.newHashMap();
				// if(column.equals("groupName")){
				// //修改环信群组名
				// params.put("groupname", group.getGroupName());
				// groupApi.modifyGroup(easeGroupId, params);
				// }
				// if(column.equals("intro")){
				// //修改环信简介
				// params.put("description", group.getIntro());
				// groupApi.modifyGroup(easeGroupId, params);
				// }
				group.setGroupImg(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
				return CreateJson.createObjJson(group, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 退出圈子 1、有正在进行的策略时不能退出 2、圈子拥有者不能退出 3、退出时删除（逻辑删除）以下与用户相关的数据： a、圈子成员表 b、策略表
	 * c、策略成员表（投注表） d、退出环信群组
	 * 
	 * @param groupId
	 * @param userId
	 * @return
	 * @throws EasemobException
	 */
	@Transactional
	public String quit(String groupId, String userId) throws EasemobException {
		if (StringUtils.isNotBlank(groupId) && StringUtils.isNotBlank(userId)) {
			int gid = Integer.parseInt(groupId);
			int uid = Integer.parseInt(userId);
			ScGroup group = groupDao.findByGroupIdAndDelFlag(gid, DictEnum.not_del.value);
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			ScUser user = userDao.findByUserId(uid);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			// 1、根据圈子ID和用户ID查询正在进行中的策略
			Long count1 = releaseDao.countByUserIdAndGroupIdAndDelFlagAndStatus(uid, gid, DictEnum.not_del.value,
					DictEnum.ing.value);
			// 2、判断用户是否为该圈子拥有者
			Long count2 = groupDao.countByUserIdAndGroupIdAndDelFlag(uid, gid, DictEnum.not_del.value);
			if (count1 > 0 || count2 > 0) {
				return CreateJson.createObjJson(ReturnMsgEnum.refuseQuit.getMessage(), false);
			}
			// 3、删除圈子内与用户相关的数据
			// a、圈子成员表
			ScGroupMember member = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(gid, uid, DictEnum.not_del.value);
			if (member != null) {
				member.setDelFlag(DictEnum.del.value);
				member.setUpdateValue(member, String.valueOf(uid));
				groupMemberDao.save(member);
			}
			// b、策略表
			Set<ScRelease> releaseSet = releaseDao.findByUserIdAndGroupIdAndDelFlag(uid, gid, DictEnum.not_del.value);
			if (releaseSet != null && releaseSet.size() > 0) {
				for (ScRelease sc : releaseSet) {
					sc.setDelFlag(DictEnum.del.value);
					sc.setUpdateValue(sc, String.valueOf(uid));
					releaseDao.save(sc);
				}
			}
			// c、策略成员表（投注）
			Set<ScReleaseUser> releaseUserSet = releaseUserDao.findByUserIdAndGroupIdAndDelFlag(uid, gid,
					DictEnum.not_del.value);
			if (releaseUserSet != null && releaseUserSet.size() > 0) {
				for (ScReleaseUser sc : releaseUserSet) {
					sc.setDelFlag(DictEnum.del.value);
					releaseUserDao.save(sc);
				}
			}
			// d、退出环信圈子
			String easeGroupId = redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(gid));// 环信群组ID
			String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value, String.valueOf(uid));
			try {
				groupApi.deleteGroupMember(easeUserName, easeGroupId);
			} catch (Exception e) {
				log.error(e.getMessage());
				redisService.hset(DictEnum.redisQuitExceptionKey.value, easeUserName, easeGroupId);
			}
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), true);
	}

	/**
	 * 根据环信群组ID获取APP的圈子信息
	 * 
	 * @param easeGroupId
	 * @return
	 */
	public String groupByEaseChat(String easeGroupId, String userId) {
		if (StringUtils.isNotBlank(easeGroupId)) {
			String groupId = redisService.hget(DictEnum.redisEaseAppGroupKey.value, easeGroupId);
			ScGroup group = group(groupId, userId);
			if (group != null) {
				group.setEaseGroupId(easeGroupId);
				return CreateJson.createObjJson(group, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 根据圈子ID获取圈子信息
	 * 
	 * @param groupId
	 * @return
	 */
	public ScGroup group(String groupId, String userId) {
		if (StringUtils.isNotBlank(groupId)) {
			int gid = Integer.parseInt(groupId);
			ScGroup group = groupDao.findByGroupIdAndDelFlag(gid, DictEnum.not_del.value);
			if (group != null) {
				group.setGroupImg(getGroupImagePath(group.getUserId() + "-" + group.getGroupId()));
				ScUser user = userDao.findByUserId(group.getUserId());
				if (user == null) {
					return null;
				}
				group.setUserName(getUserName(user));
				group.setUserImg(getUserImagePath(user.getMobile()));
				ScGroupMember groupMember = groupMemberDao.findByGroupIdAndUserIdAndDelFlag(Integer.parseInt(groupId),
						Integer.parseInt(userId), DictEnum.not_del.value);
				if (groupMember != null) {
					group.setIsJoin(true);
					group.setReleaseLimit(groupMember.getReleaseLimit());
				} else {
					group.setIsJoin(false);
				}
				group.setPeopleCount(
						groupMemberDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
				group.setReleaseCount(releaseDao.countByGroupIdAndDelFlag(group.getGroupId(), DictEnum.not_del.value));
				return group;
			}
		}
		return null;
	}

	public String groupById(String groupId, String userId) {
		ScGroup group = group(groupId, userId);
		if (group != null) {
			return CreateJson.createObjJson(group, true);
		} else {
			return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
		}
	}

	/**
	 * 根据环信用户名和环信群ID获取APP的用户和圈子信息 该接口用于验证消息的数据显示
	 * 
	 * @param easeUserName
	 * @param easeGroupId
	 * @return
	 */
	public String ease2app(String easeUserName, String easeGroupId) {
		Map<String, Object> map = Maps.newHashMap();
		String userId = redisService.hget(DictEnum.redisEaseAppUserKey.value, easeUserName);
		String groupId = redisService.hget(DictEnum.redisEaseAppGroupKey.value, easeGroupId);
		if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(easeGroupId)) {
			ScUser user = userDao.findByUserId(Integer.parseInt(userId));
			ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			if (group == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
			}
			map.put("userId", user.getUserId());
			map.put("userName", getUserName(user));
			map.put("userImage", getUserImagePath(user.getMobile()));
			map.put("groupId", group.getGroupId());
			map.put("groupName", group.getGroupName());
			ScGroupApply groupApply = groupApplyDao.findByGroupIdAndUserIdAndDelFlag(group.getGroupId(),
					user.getUserId(), DictEnum.not_del.value);
			if (groupApply != null) {
				map.put("reason", groupApply.getApplyContent());
			} else {
				map.put("reason", "申请加入圈子\"" + group.getGroupName() + "\"");
			}
			return CreateJson.createObjJson(map, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 根据环信用户名和环信群ID获取APP的用户和圈子信息（多条获取） 该接口用于验证消息的数据显示
	 * 
	 * @param json
	 * @return
	 */
	public String easeList2App(String json) {
		List<Object> list = Lists.newArrayList();
		@SuppressWarnings("unchecked")
		LinkedHashMap<String, String> easeParams = JacksonUtil.jsonToObj(json, LinkedHashMap.class);
		if (easeParams != null && easeParams.size() > 0) {
			for (Entry<String, String> entry : easeParams.entrySet()) {
				Map<String, Object> map = Maps.newHashMap();
				String userId = redisService.hget(DictEnum.redisEaseAppUserKey.value,
						entry.getKey().substring(0, entry.getKey().indexOf("@@")));
				String groupId = redisService.hget(DictEnum.redisEaseAppGroupKey.value, entry.getValue());
				if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(groupId)) {
					ScUser user = userDao.findByUserId(Integer.parseInt(userId));
					ScGroup group = groupDao.findByGroupIdAndDelFlag(Integer.parseInt(groupId), DictEnum.not_del.value);
					if (user == null) {
						continue;
					}
					if (group == null) {
						continue;
					}
					map.put("easeUserId", entry.getKey());
					map.put("userId", user.getUserId());
					map.put("userName", getUserName(user));
					map.put("userImage", getUserImagePath(user.getMobile()));
					map.put("easeGroupId", entry.getValue());
					map.put("groupId", group.getGroupId());
					map.put("groupName", group.getGroupName());
					ScGroupApply groupApply = groupApplyDao.findByGroupIdAndUserIdAndDelFlag(group.getGroupId(),
							user.getUserId(), DictEnum.not_del.value);
					if (groupApply != null) {
						map.put("reason", groupApply.getApplyContent());
					} else {
						map.put("reason", "");
					}
					list.add(map);
				}
			}
		}
		if (list != null && list.size() > 0) {
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 获取示例图片
	 * 
	 * @return
	 */
	@Deprecated
	public String getExampleGroupImage() {
		int countFile = FileUtils.countFile(sysCfg.getUserfiles_groupexample_url());
		if (countFile < 1) {
			return null;
		}
		int min = 1;
		Map<String, String> map = Maps.newHashMap();
		String imageNo = redisService.get(DictEnum.redisExampleGroupImageKey.value);
		if (StringUtils.isBlank(imageNo)) {
			int random = new Random().nextInt(countFile) % (countFile - min + 1) + min;
			handlerRedisRandom(String.valueOf(random));
			map.put("path", getExampleGroupImagePath(String.valueOf(random)));
			map.put("picName", String.valueOf(random));
			return CreateJson.createObjJson(map, true);
		} else {
			String picName = "";
			while (true) {
				int random = new Random().nextInt(countFile) % (countFile - min + 1) + min;
				if (random != Integer.parseInt(imageNo)) {
					picName = String.valueOf(random);
					handlerRedisRandom(String.valueOf(random));
					break;
				}
			}
			map.put("path", getExampleGroupImagePath(redisService.get(DictEnum.redisExampleGroupImageKey.value)));
			map.put("picName", picName);
			return CreateJson.createObjJson(map, true);
		}
	}

	@Deprecated
	public void handlerRedisRandom(String random) {
		redisService.set(DictEnum.redisExampleGroupImageKey.value, random);
		redisService.hset(DictEnum.redisExampleGroupImageTimestampKey.value, random,
				String.valueOf(System.currentTimeMillis()));
	}

	/**
	 * 分配管理员权限
	 * 
	 * @param groupId
	 * @param userIds
	 * @return
	 */
	public String allotManager(Integer groupId, Integer userId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}

		List<ScGroupRole> list = groupRoleDao.findByType(DictEnum.manager.value);
		if (list != null && list.size() > 0) {
			ScGroupRole role = list.get(0);
			List<ScGroupUserRole> userRole = groupUserRoleDao.findByGroupIdAndUserIdAndType(groupId, userId,
					DictEnum.manager.value);
			if (userRole != null && userRole.size() > 0) {
				return CreateJson.createObjJson(ReturnMsgEnum.isManager.getMessage(), false);
			}
			ScGroupUserRole sc = new ScGroupUserRole();
			sc.setGroupId(groupId);
			sc.setRoleId(role.getId());
			sc.setUserId(userId);
			groupUserRoleDao.save(sc);
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 移除管理员
	 * 
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public String removeManager(Integer groupId, Integer userId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		List<ScGroupUserRole> userRole = groupUserRoleDao.findByGroupIdAndUserIdAndType(groupId, userId,
				DictEnum.manager.value);
		if (userRole != null && userRole.size() > 0) {
			for (ScGroupUserRole sc : userRole) {
				groupUserRoleDao.delete(sc);
			}
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 获取圈子内的所有管理员
	 * 
	 * @param groupId
	 * @return
	 */
	public String getAllManager(Integer groupId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		List<ScGroupMember> list = groupMemberDao.findByGroupIdAndRoleType(groupId, DictEnum.manager.value);
		Set<ScUser> set = Sets.newHashSet();
		if (list != null && list.size() > 0) {
			for (ScGroupMember member : list) {
				ScUser user = userDao.findByUserId(member.getUserId());
				if (user != null) {
					user.setImage(getUserImagePath(user.getMobile()));
					user.setUserName(getUserName(user));
					set.add(user);
				}
			}
		}
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 获取圈子内的所有非管理员
	 * 
	 * @param groupId
	 * @return
	 */
	public String getAllNotManager(Integer groupId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		List<ScGroupMember> list = groupMemberDao.findByGroupIdAndRoleType(groupId, DictEnum.manager.value,
				DictEnum.admin.value);
		Set<ScUser> set = Sets.newHashSet();
		if (list != null && list.size() > 0) {
			for (ScGroupMember member : list) {
				ScUser user = userDao.findByUserId(member.getUserId());
				if (user != null) {
					user.setImage(getUserImagePath(user.getMobile()));
					user.setUserName(getUserName(user));
					set.add(user);
				}
			}
		}
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 获取用户在圈子内的权限
	 * 
	 * @param groupId
	 * @param userId
	 * @return
	 */
	public String getAllUserAuth(Integer groupId, Integer userId) {
		ScGroup group = groupDao.findByGroupIdAndDelFlag(groupId, DictEnum.not_del.value);
		if (group == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.groupNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		List<ScGroupAuth> list = groupAuthDao.findByGroupIdAndUserIdAndIsAble(DictEnum.enable.value, groupId, userId);
		if (list != null && list.size() > 0) {
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	//////////////////////////////////////////////////////// 接口实现//////////////////////////////////////////////////////////////////
	/**
	 * 查询所有群成员
	 * 
	 * @param groupId
	 * @param delFlag
	 * @param pageno
	 * @param size
	 * @return
	 */
	public List<ScGroupMember> findByGroupIdAndDelFlag(int groupId, String delFlag, int pageno, int size) {
		Specification<ScGroupMember> specification = new Specification<ScGroupMember>() {
			@Override
			public Predicate toPredicate(Root<ScGroupMember> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _groupId = root.get("groupId");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_groupId, groupId));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.ASC, "createDate");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return groupMemberDao.findAll(specification, pageable).getContent();
	}
}
