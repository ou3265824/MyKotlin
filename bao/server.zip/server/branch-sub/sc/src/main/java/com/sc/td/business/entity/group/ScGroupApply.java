package com.sc.td.business.entity.group;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.persistence.Transient;

@Table
@Entity
@IdClass(ScGroupApplyPk.class)
public class ScGroupApply {

	private int groupId;
	private int userId;
	private String status;
	private String applyContent;
	private String applyDate;
	private int auditBy;
	private String auditContent;
	private String auditDate;
	private String auditView;
	private String userName;
	private String userImage;
	private String delFlag;
	private String readFlag;
	private String groupName;
	private String easeGroupId;
	private String easeUserName;
	private String groupImage;
	private String groupIntro;
	
	@Transient
	public String getGroupImage() {
		return groupImage;
	}
	public void setGroupImage(String groupImage) {
		this.groupImage = groupImage;
	}
	@Transient
	public String getGroupIntro() {
		return groupIntro;
	}
	public void setGroupIntro(String groupIntro) {
		this.groupIntro = groupIntro;
	}
	@Transient
	public String getEaseUserName() {
		return easeUserName;
	}
	public void setEaseUserName(String easeUserName) {
		this.easeUserName = easeUserName;
	}
	@Transient
	public String getEaseGroupId() {
		return easeGroupId;
	}
	public void setEaseGroupId(String easeGroupId) {
		this.easeGroupId = easeGroupId;
	}
	@Transient
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getReadFlag() {
		return readFlag;
	}
	public void setReadFlag(String readFlag) {
		this.readFlag = readFlag;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	@Transient
	public String getUserImage() {
		return userImage;
	}
	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	@Transient
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Id
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	@Id
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getApplyContent() {
		return applyContent;
	}
	public void setApplyContent(String applyContent) {
		this.applyContent = applyContent;
	}
	public String getApplyDate() {
		return applyDate;
	}
	public void setApplyDate(String applyDate) {
		this.applyDate = applyDate;
	}
	public int getAuditBy() {
		return auditBy;
	}
	public void setAuditBy(int auditBy) {
		this.auditBy = auditBy;
	}
	public String getAuditContent() {
		return auditContent;
	}
	public void setAuditContent(String auditContent) {
		this.auditContent = auditContent;
	}
	public String getAuditDate() {
		return auditDate;
	}
	public void setAuditDate(String auditDate) {
		this.auditDate = auditDate;
	}
	public String getAuditView() {
		return auditView;
	}
	public void setAuditView(String auditView) {
		this.auditView = auditView;
	}
}
