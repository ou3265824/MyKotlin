package com.sc.td.business.entity.release.dto;

import java.util.List;

import com.sc.td.business.entity.release.ScReleaseDetails;

public class ReleaseDetailsReq {

	private int releaseId; 
	private List<ScReleaseDetails> detailsList;

	public List<ScReleaseDetails> getDetailsList() {
		return detailsList;
	}

	public void setDetailsList(List<ScReleaseDetails> detailsList) {
		this.detailsList = detailsList;
	}

	public int getReleaseId() {
		return releaseId;
	}

	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}

}
