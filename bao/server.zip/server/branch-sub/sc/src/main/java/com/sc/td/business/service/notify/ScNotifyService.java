package com.sc.td.business.service.notify;

import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.group.ScGroupApplyDao;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.notify.ScNotifyRecordDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.group.ScGroupApply;
import com.sc.td.business.entity.notify.ScNotifyRecord;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.MsgEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;

@Service
public class ScNotifyService extends BaseService {

	@Autowired
	private ScNotifyRecordDao notifyRecordDao;

	@Autowired
	private ScGroupApplyDao groupApplyDao;
	
	@Autowired
	private ScUserDao userDao;
	
	@Autowired
	private ScGroupDao groupDao;
	
	@Autowired
	private RedisService redisService;
	

	/**
	 * 根据userId和消息的类型获取消息
	 * @param userId
	 * @param index1
	 * @param size1
	 * @return
	 */
	public String getNotifyInfo(Integer userId,String type,String index1,String size1){
		PageInfo pageInfo = getSQLIndexAndSize(index1, size1);
		if(userId!=null){
			//获取所有的未读消息，然后设置为已读
			List<ScNotifyRecord> notReadList = notifyRecordDao.findByUserIdAndTypeAndReadFlag(userId, type, MsgEnum.not_read.value);
			if(notReadList!=null && notReadList.size()>0){
				for(ScNotifyRecord sc:notReadList){
					sc.setReadFlag(MsgEnum.read.value);
					sc.setReadDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
					notifyRecordDao.save(sc);
				}
			}
			List<ScNotifyRecord> list = notifyRecordDao.findByUserIdAndTypeAndStatusOrderDESC(userId, type,MsgEnum.publish.value, pageInfo.get_index(),pageInfo.get_size());
			if(list!=null && list.size()>0){
				return CreateJson.createObjJson(list, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 根据UserId获取验证消息
	 * @param userId
	 * @return
	 */
	@Transactional
	public String joinApplyNotify(Integer userId,String index1,String size1){
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		if(userId!=null){
			//获取所有的未读消息，然后设置为已读
			List<ScGroupApply> notReadList=groupApplyDao.findByAuditByAndDelFlagAndReadFlag(userId, DictEnum.not_del.value, MsgEnum.not_read.value);
			if(notReadList!=null && notReadList.size()>0){
				for(ScGroupApply sc:notReadList){
					sc.setReadFlag(MsgEnum.read.value);
					groupApplyDao.save(sc);
				}
			}
			List<ScGroupApply> list = findByAuditByAndDelFlag(userId,DictEnum.not_del.value,pageInfo.get_pageno(),pageInfo.get_size());
			if(list!=null && list.size()>0){
				for(ScGroupApply sc:list){
					//获取所有申请者的信息
					ScUser applyUser = userDao.findByUserId(sc.getUserId());
					if(applyUser!=null){
						sc.setUserName(getUserName(applyUser));
						sc.setUserImage(getUserImagePath(applyUser.getMobile()));
						sc.setEaseUserName(redisService.hget(DictEnum.redisAppEaseUserKey.value, String.valueOf(applyUser.getUserId())));
					}
					ScGroup group=groupDao.findByGroupIdAndDelFlag(sc.getGroupId(),DictEnum.not_del.value);
					if(group!=null){
						sc.setGroupName(group.getGroupName());
						sc.setEaseGroupId(redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(group.getGroupId())));
						sc.setGroupImage(getGroupImagePath(group.getUserId()+"-"+group.getGroupId()));
						sc.setGroupIntro(group.getIntro());
					}
				}
				return CreateJson.createObjJson(list, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 获取系统消息和验证消息的个数
	 * @param userId
	 * @return
	 */
	public String getCount(Integer userId){
		long sysMsgCount=notifyRecordDao.countByUserIdAndTypeAndReadFlag(userId,MsgEnum.sys.value,MsgEnum.not_read.value);
		long groupMsgCount=groupApplyDao.countByAuditByAndDelFlagAndReadFlag(userId, DictEnum.not_del.value, MsgEnum.not_read.value);
		Map<String,Long> map=Maps.newHashMap();
		map.put("sysMsgCount", sysMsgCount);
		map.put("groupMsgCount",groupMsgCount);
		return CreateJson.createObjJson(map, true);
	}
	
	
	//////////////////////////////////////////////接口实现///////////////////////////////////////////////////////////////////
	public List<ScGroupApply> findByAuditByAndDelFlag(int auditBy,String delFlag,int pageno,int size){
		 Specification<ScGroupApply> specification = new Specification<ScGroupApply>() {
			@Override
			public Predicate toPredicate(Root<ScGroupApply> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _auditBy = root.get("auditBy");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_auditBy, auditBy));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[]{}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "applyDate");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return groupApplyDao.findAll(specification, pageable).getContent();
	}
	
	@Deprecated
	public List<ScNotifyRecord> findByUserIdAndType(int userId,String type,int pageno,int size){
		Specification<ScNotifyRecord> specification = new Specification<ScNotifyRecord>() {
			@Override
			public Predicate toPredicate(Root<ScNotifyRecord> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _userId = root.get("userId");
				Path<String> _type = root.get("type");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_userId, userId));
				predicates.add(cb.equal(_type, type));
				return cb.and(predicates.toArray(new Predicate[]{}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "readDate");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return notifyRecordDao.findAll(specification, pageable).getContent();
	}
}
