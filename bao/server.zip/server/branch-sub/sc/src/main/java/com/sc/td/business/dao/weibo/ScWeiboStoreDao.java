package com.sc.td.business.dao.weibo;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.weibo.ScWeiboStore;

public interface ScWeiboStoreDao extends BaseDao<ScWeiboStore> {

	ScWeiboStore findByWeiboIdAndUserIdAndDelFlag(int weiboId,int userId,String delFlag);
}
