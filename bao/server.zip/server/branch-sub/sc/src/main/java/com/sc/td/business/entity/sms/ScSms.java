package com.sc.td.business.entity.sms;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table
@Entity
public class ScSms {

	private int id;
	private String recieveNum;
	private String requestIp;
	private String smsType;
	private String smsContext;
	private String smsTime;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getRecieveNum() {
		return recieveNum;
	}
	public void setRecieveNum(String recieveNum) {
		this.recieveNum = recieveNum;
	}
	public String getRequestIp() {
		return requestIp;
	}
	public void setRequestIp(String requestIp) {
		this.requestIp = requestIp;
	}
	public String getSmsType() {
		return smsType;
	}
	public void setSmsType(String smsType) {
		this.smsType = smsType;
	}
	public String getSmsContext() {
		return smsContext;
	}
	public void setSmsContext(String smsContext) {
		this.smsContext = smsContext;
	}
	public String getSmsTime() {
		return smsTime;
	}
	public void setSmsTime(String smsTime) {
		this.smsTime = smsTime;
	}
	
}
