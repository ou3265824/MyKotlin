package com.sc.td.business.dao.weibo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.weibo.ScWeibo;

public interface ScWeiboDao extends BaseDao<ScWeibo>, SpecificationDao<ScWeibo> {

	ScWeibo findByIdAndDelFlag(int weiboId, String delFlag);

	@Query(value = "select weibo.id,weibo.user_id,weibo.tribe_id,weibo.content,weibo.img,weibo.type,weibo.create_time,weibo.del_flag"
			+ " from sc_weibo weibo join  sc_tribe_member member on member.tribe_id=weibo.tribe_id"
			+ " where member.user_id=?1 and weibo.del_flag=?2 order by weibo.create_time DESC limit ?3,?4", nativeQuery = true)
	List<ScWeibo> findMyTribeWeiboByUserIdAndDelFlag(int userId, String delFlag, int index, int size);

	@Query(value = "select weibo.id,weibo.user_id,weibo.tribe_id,weibo.content,weibo.img,weibo.type,weibo.create_time,weibo.del_flag"
			+ " from sc_weibo weibo join sc_weibo_store store on store.weibo_id=weibo.id"
			+ " where store.user_id=?1 and weibo.del_flag=?2 order by weibo.create_time DESC limit ?3,?4", nativeQuery = true)
	List<ScWeibo> findMyStoreWeiboByUserIdAndDelFlag(int userId, String delFlag, int index, int size);

	@Query(value = "select weibo.id,weibo.user_id,weibo.tribe_id,weibo.content,weibo.img,weibo.type,weibo.create_time,weibo.del_flag"
			+ "	from sc_weibo weibo join sc_tribe tribe on weibo.tribe_id=tribe.tribe_id" 
			+ " where weibo.del_flag=?1 and tribe.del_flag=?1 and tribe.is_public=?2 and join_type=?3 limit ?4,?5", nativeQuery=true)
	List<ScWeibo> hot(String delFlag, String isPublic, String joinType, int index, int size);
}
