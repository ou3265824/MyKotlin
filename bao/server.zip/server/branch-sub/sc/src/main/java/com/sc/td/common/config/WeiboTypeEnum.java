package com.sc.td.common.config;

public enum WeiboTypeEnum {

	original("原创","0"),
	transmit("转发","1"),
	comment("评论","2");
	
	public String desc;
	public String value;
	
	private WeiboTypeEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
}
