package com.sc.td.business.dao.group;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.group.ScGroup;

public interface ScGroupDao extends BaseDao<ScGroup>,SpecificationDao<ScGroup> {

	ScGroup findByGroupIdAndDelFlag(int groupId,String delFlag);
	
	Long countByUserIdAndGroupIdAndDelFlag(int userId,int groupId,String delFlag);
	
	List<ScGroup> findByGroupName(String groupName);
}
