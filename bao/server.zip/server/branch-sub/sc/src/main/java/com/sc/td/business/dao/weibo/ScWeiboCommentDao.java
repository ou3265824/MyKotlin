package com.sc.td.business.dao.weibo;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.weibo.ScWeiboComment;

public interface ScWeiboCommentDao extends BaseDao<ScWeiboComment>,SpecificationDao<ScWeiboComment>{

	ScWeiboComment findByIdAndDelFlag(int id,String delFlag);
}
