package com.sc.td.common.config;

public enum ReturnMsgEnum {
	
	
	operateSuccess("操作成功"),
	operateFail("操作失败"),
	operateInvalid("非法操作"),
	paramsNull("参数为必填项"),
	paramsError("参数填写错误"),
	paramsInvalid("参数非法"),
	mobileOrPwdError("手机号或密码错误"),
	userNameNull("用户名为必填项"),
	userNameExist("该昵称已被使用"),
	userNotExist("用户不存在"),
	userExist("用户已存在"),
	producerNotExist("策略提出人不存在"),
	notPass("账号或密码错误"),
	oldPwdError("旧密码错误"),
	isManager("该用户已是管理员"),
	passwordOldError("原密码填写错误"),
	passwordReError("两次密码输入不一致"),
	mobileNull("手机号码为必填项"),
	mobileExist("该手机号码已注册"),
	tokenIllegal("请先登录"),
	tokenInvalid("请先登录"),
	sysExeption("系统异常"),
	smsException("短信发送异常"),
	loginFail("登陆失败"),
	loginSuccess("登陆成功"),
	logout("登出成功"),
	logoutException("登出异常"),
	resetpwdSuccess("密码修改成功"),
	resetpwdFail("密码修改失败"),
	pwdNull("密码不能为空"),
	validCodeTypeNull("验证码类型不能为空"),
	validCodeTypeError("验证码类型错误"),
	validCodeError("验证码错误"),
	nondata("无数据"),
	sendsmsLimit("操作过频，请稍后申领！"),
	groupNameExist("活动名重复"),
	groupNotExist("活动不存在"),
	alreadyInGroup("已加入活动"),
	easeUserNotExist("环信用户不存在"),
	easeCreateGroupError("创建环信群组失败"),
	nopermission("无权限"),
	refuseQuit("活动拥有者或有正在进行的策略，不能退出"),
	releaseNameExist("策略名重复"),
	releaseNotExist("策略不存在"),
	releaseDetailNull("策略标的不能为空"),
	nonBet("无人投注，不能开启策略"),
	connotDetails("当前状态不能添加标的"),
	betMoneyNotEnough("当前有资金不足的用户，无法开启策略"),
	notEnoughFunds("可用资金不足，请尽快充值"),
	releaseIngOrEnd("当前无法投注"),
	minAmount("最小投注额100元"),
	outOfCollectMoney("总下单额不得大于策略募集额"),
	notAllCloseDetails("当前存在未平仓的标的"),
	zeroCollectMoney("无人投注，无法添加商品"),
	lessThanOldBetAmout("标的已添加，不能减少投注额"),
	releaseBetClose("投注已结束"),
	cannotDelReleaseUser("当前状态无法删除投注人"),
	connotEndReleaseByIng("当前状态无法结束策略"),
	tribeNameExist("部落名已被使用"),
	tribeNotExist("部落不存在"),
	alreadyInTribe("已加入部落"),
	notInTribe("尚未加入部落"),
	weiboNUll("微博内容不能为空"),
	weiboNotExist("微博不存在"),
	commentNULL("评论内容不能为空"),
	commentNotExist("评论不存在");
	
	private ReturnMsgEnum(String message) {
		this.message = message;
	}
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return this.message;
	}
	
}
