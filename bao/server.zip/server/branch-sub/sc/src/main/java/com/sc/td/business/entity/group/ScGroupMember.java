package com.sc.td.business.entity.group;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.sc.td.common.config.DictEnum;
import com.sc.td.common.persistence.BaseEntity;

@Table
@Entity
@IdClass(GroupMemberPk.class)
public class ScGroupMember extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int groupId;
	private int userId;
	private String articleLimit;
	private String articleCommentLimit;
	private String releaseLimit;
	private String releaseCommentLimit;
	private String delFlag;
	
	
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	@Id
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	
	@Id
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getArticleLimit() {
		return articleLimit;
	}
	public void setArticleLimit(String articleLimit) {
		this.articleLimit = articleLimit;
	}
	public String getArticleCommentLimit() {
		return articleCommentLimit;
	}
	public void setArticleCommentLimit(String articleCommentLimit) {
		this.articleCommentLimit = articleCommentLimit;
	}
	public String getReleaseLimit() {
		return releaseLimit;
	}
	public void setReleaseLimit(String releaseLimit) {
		this.releaseLimit = releaseLimit;
	}
	public String getReleaseCommentLimit() {
		return releaseCommentLimit;
	}
	public void setReleaseCommentLimit(String releaseCommentLimit) {
		this.releaseCommentLimit = releaseCommentLimit;
	}
	
	@Override
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setArticleLimit(DictEnum.negative.value);
		this.setArticleCommentLimit(DictEnum.negative.value);
		this.setReleaseLimit(DictEnum.negative.value);
		this.setReleaseCommentLimit(DictEnum.negative.value);
		this.setDelFlag(DictEnum.not_del.value);
	}
}
