package com.sc.td.business.service.weibo;

import java.io.File;
import java.net.URLDecoder;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.tribe.ScTribeAuthDao;
import com.sc.td.business.dao.tribe.ScTribeDao;
import com.sc.td.business.dao.tribe.ScTribeMemberDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.dao.weibo.ScWeiboCommentDao;
import com.sc.td.business.dao.weibo.ScWeiboDao;
import com.sc.td.business.dao.weibo.ScWeiboLikeDao;
import com.sc.td.business.dao.weibo.ScWeiboStoreDao;
import com.sc.td.business.entity.tribe.ScTribe;
import com.sc.td.business.entity.tribe.ScTribeAuth;
import com.sc.td.business.entity.tribe.ScTribeAuthEnum;
import com.sc.td.business.entity.tribe.ScTribeMember;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.business.entity.weibo.ScWeibo;
import com.sc.td.business.entity.weibo.ScWeiboComment;
import com.sc.td.business.entity.weibo.ScWeiboLike;
import com.sc.td.business.entity.weibo.ScWeiboStore;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.FileFormatEnum;
import com.sc.td.common.config.PicFormatEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.config.WeiboTypeEnum;
import com.sc.td.common.utils.BeanUtils;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.image.ImgUtils;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;

@Service
public class ScWeiboService extends BaseService {

	@Autowired
	private ScWeiboDao weiboDao;

	@Autowired
	private ScTribeDao tribeDao;

	@Autowired
	private ScTribeMemberDao tribeMemberDao;

	@Autowired
	private ScUserDao userDao;

	@Autowired
	private RedisService redisService;

	@Autowired
	private ScWeiboLikeDao weiboLikeDao;

	@Autowired
	private ScWeiboStoreDao weiboStoreDao;

	@Autowired
	private ScWeiboCommentDao weiboCommentDao;

	@Autowired
	private ScTribeAuthDao tribeAuthDao;

	/**
	 * 发布微博
	 * 
	 * @param request
	 * @param loadpath
	 * @return
	 * @throws Exception
	 */
	public String publish(HttpServletRequest request, String loadpath) throws Exception {
		Map<String, String> map = upload(request, loadpath);
		if (map != null && map.size() > 0) {
			String tribeId = map.get("tribeId");
			String content = map.get("content");
			String img = map.get("img");
			String createTime = map.get("createTime");
			if(StringUtils.isBlank(tribeId)){
				return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
			}
			if (StringUtils.isBlank(content) && StringUtils.isBlank(img)) {
				return CreateJson.createTextJson(ReturnMsgEnum.weiboNUll.getMessage(), false);
			}
			ScUser currentUser = userByToken(request);
			ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(Integer.parseInt(tribeId), DictEnum.not_del.value);
			if (tribe == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
			}
			ScWeibo weibo = new ScWeibo();
			weibo.setType(WeiboTypeEnum.original.value);
			weibo.setTribeId(Integer.parseInt(tribeId));
			weibo.setUserId(currentUser.getUserId());
			weibo.setContent(content);
			weibo.setImg(img);
			Timestamp t = Timestamp.valueOf(createTime);
			t.setNanos(0);
			weibo.setCreateTime(t);
			weibo.setNanosecond(Timestamp.valueOf(createTime).getNanos());
			weibo.setDelFlag(DictEnum.not_del.value);
			if (weiboDao.save(weibo) != null) {
				ScWeibo respWeibo = new ScWeibo();
				BeanUtils.copyBeanNotNull2Bean(weibo, respWeibo);
				respWeibo.setCreateTime(weibo.getCreateTime());
				weibo = handler(respWeibo, currentUser);
				return CreateJson.createObjJson(weibo, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 手机端上传文件 表单形式上传（文本、图片等文件）
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	public Map<String, String> upload(HttpServletRequest request, String loadpath) throws Exception {
		Timestamp time = new Timestamp(System.currentTimeMillis());
		time.setNanos(0);
		String tempFilePath = loadpath + DictEnum.temp.value + time.getTime();
		String filePath = loadpath + time.getTime();
		// 创建临时文件夹
		File dir_temp = new File(tempFilePath);
		if (!dir_temp.exists()) {
			dir_temp.mkdirs();
		}
		loadpath = loadpath + DictEnum.temp.value + time.getTime() + File.separator;
		Map<String, String> map = Maps.newHashMap();
		StringBuilder img = new StringBuilder("");
		Map<String, String> itemNameMap = Maps.newHashMap();
		DiskFileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setSizeMax(20 * 1024 * 1024); // 设置允许用户上传文件大小,单位:字节
		upload.setFileSizeMax(20 * 1024 * 1024); // 设置最多只允许在内存中存储的数据,单位:字节

		// 开始读取上传信息
		List<FileItem> fileItems = null;

		try {
			fileItems = upload.parseRequest(request);
		} catch (Exception e) {
			e.printStackTrace();
		}

		Iterator<FileItem> iter = fileItems.iterator(); // 依次处理每个上传的文件
		while (iter.hasNext()) {
			FileItem item = (FileItem) iter.next();// 忽略其他不是文件域的所有表单信息
			if (!item.isFormField()) {
				String name = item.getName();// 获取上传文件名,包括路径
				if (name == null || name.equals("")) {
					continue;
				}
				name = name.substring(name.lastIndexOf(File.separator) + 1);// 从全路径中提取文件名
				String suffix = name.toUpperCase().substring(name.lastIndexOf(".") + 1);
				if (!checkFileFormat(suffix) && !checkPicFormat(suffix)) {
					// 检查文件类型是否符合
					continue;
				}
				if (itemNameMap.containsKey(name)) {
					continue;
				}
				itemNameMap.put(name, name);
				long size = item.getSize();
				if (size == 0)
					continue;
				File fNew = new File(loadpath, name);
				try {
					item.write(fNew);
					if (checkPicFormat(suffix)) {
						// 生成缩略图
						ImgUtils.thumbnailImage(loadpath + name, Integer.parseInt(DictEnum.thumb_w.value),
								Integer.parseInt(DictEnum.thumb_h.value), DictEnum.thumb_prevfix.value, false);
						if (StringUtils.isBlank(img)) {
							img.append(name);
						} else {
							img.append("," + name);
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

			} else// 取出不是文件域的所有表单信息
			{
				map.put(item.getFieldName(), URLDecoder.decode(item.getString(), "utf-8"));
				// map.put(item.getFieldName(), item.getString());
			}
		}
		map.put("img", img.toString());
		map.put("createTime", String.valueOf(time));
		if (StringUtils.isNotBlank(img.toString())) {
			// copy临时文件
			FileUtils.copyDirectory(dir_temp, new File(filePath));
		}
		FileUtils.deleteQuietly(dir_temp);
		return map;
	}

	/**
	 * 删除微博
	 * 
	 * @param request
	 * @param weiboId
	 * @return
	 */
	public String del(HttpServletRequest request, Integer weiboId) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		// 判断是否有权限删除微博
		// 1、发布者 2、有权限的管理员
		boolean b = false;
		if (weibo.getUserId() == currentUser.getUserId()) {
			b = true;
		}
		if (!b) {
			ScTribeAuth auth = tribeAuthDao.findByTribeIdAndUserIdAndPermissionAndIsAble(DictEnum.enable.value,
					weibo.getTribeId(), currentUser.getUserId(), ScTribeAuthEnum.weiboDelete.value);
			if (auth != null) {
				b = true;
			}
		}
		if (b) {
			weibo.setDelFlag(DictEnum.del.value);
			weiboDao.save(weibo);
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), true);
	}

	/**
	 * 处理返回的数据
	 * 
	 * @param weibo
	 * @return
	 */
	public ScWeibo handler(ScWeibo weibo, ScUser currentUser) {
		weibo.setCommentCount(
				redisService.hget(DictEnum.redisWeiboCommentCountKey.value, String.valueOf(weibo.getId())));
		weibo.setLikeCount(redisService.hget(DictEnum.redisWeiboLikeCountKey.value, String.valueOf(weibo.getId())));
		weibo.setStoreCount(redisService.hget(DictEnum.redisWeiboStoreCountKey.value, String.valueOf(weibo.getId())));
		StringBuilder sb = new StringBuilder("");
		StringBuilder sb_thumb = new StringBuilder("");
		if (weibo != null && StringUtils.isNotBlank(weibo.getImg())) {
			String[] imgs = weibo.getImg().split(",");
			String thumbImg = "";
			for (String img : imgs) {
				Timestamp t = weibo.getCreateTime();
				t.setNanos(0);
				thumbImg = getWeiboImagePath(String.valueOf(t.getTime()),
						DictEnum.thumb_prevfix.value + img);
				img = getWeiboImagePath(String.valueOf(t.getTime()), img);
				if (sb.toString().length() <= 0) {
					sb.append(img);
				} else {
					sb.append("," + img);
				}
				if (sb_thumb.toString().length() <= 0) {
					sb_thumb.append(thumbImg);
				} else {
					sb_thumb.append("," + thumbImg);
				}
			}
		}
		weibo.setImg(sb.toString());
		weibo.setThumbImg(sb_thumb.toString());
		ScUser pubUser = userDao.findByUserId(weibo.getUserId());
		if (pubUser != null) {
			weibo.setUserName(getUserName(pubUser));
			weibo.setUserImg(getUserImagePath(pubUser.getMobile()));
		}
		ScTribe pubtribe = tribeDao.findByTribeIdAndDelFlag(weibo.getTribeId(), DictEnum.not_del.value);
		if (pubtribe != null) {
			weibo.setTribeName(pubtribe.getTribeName());
		}
		ScWeiboLike like = weiboLikeDao.findByWeiboIdAndUserIdAndDelFlag(weibo.getId(), currentUser.getUserId(),
				DictEnum.not_del.value);
		if (like != null) {
			weibo.setLike(true);
		}
		ScWeiboStore store = weiboStoreDao.findByWeiboIdAndUserIdAndDelFlag(weibo.getId(), currentUser.getUserId(),
				DictEnum.not_del.value);
		if (store != null) {
			weibo.setStore(true);
		}
		return weibo;
	}

	public static boolean checkFileFormat(String fileSuffix) {
		boolean b = false;
		for (FileFormatEnum e : FileFormatEnum.values()) {
			if (fileSuffix.equals(e.toString())) {
				b = true;
				return b;
			}
		}
		return b;
	}

	public static boolean checkPicFormat(String fileSuffix) {
		boolean b = false;
		for (PicFormatEnum e : PicFormatEnum.values()) {
			if (fileSuffix.equals(e.toString())) {
				b = true;
				return b;
			}
		}
		return b;
	}

	/**
	 * 点赞
	 * 
	 * @param request
	 * @param weiboId
	 * @return
	 */
	public String like(HttpServletRequest request, Integer weiboId) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		ScWeiboLike like = weiboLikeDao.findByWeiboIdAndUserIdAndDelFlag(weiboId, currentUser.getUserId(),
				DictEnum.not_del.value);
		if (like != null) {
			return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
		}
		like = new ScWeiboLike();
		like.setUserId(currentUser.getUserId());
		like.setWeiboId(weiboId);
		like.setDelFlag(DictEnum.not_del.value);
		weiboLikeDao.save(like);
		String value = redisService.hget(DictEnum.redisWeiboLikeCountKey.value, String.valueOf(weiboId));
		int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
		redisService.hset(DictEnum.redisWeiboLikeCountKey.value, String.valueOf(weiboId), String.valueOf(++count));
		weibo = handler(weibo, currentUser);
		return CreateJson.createObjJson(weibo, true);
	}

	/**
	 * 取消点赞
	 * 
	 * @param request
	 * @param weiboId
	 * @return
	 */
	public String like_cancel(HttpServletRequest request, Integer weiboId) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		ScWeiboLike like = weiboLikeDao.findByWeiboIdAndUserIdAndDelFlag(weiboId, currentUser.getUserId(),
				DictEnum.not_del.value);
		if (like == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
		}
		weiboLikeDao.delete(like);
		String value = redisService.hget(DictEnum.redisWeiboLikeCountKey.value, String.valueOf(weiboId));
		int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
		if (count > 0) {
			redisService.hset(DictEnum.redisWeiboLikeCountKey.value, String.valueOf(weiboId), String.valueOf(--count));
		}
		weibo = handler(weibo, currentUser);
		return CreateJson.createObjJson(weibo, true);
	}

	/**
	 * 收藏
	 * 
	 * @param request
	 * @param weiboId
	 * @return
	 */
	public String store(HttpServletRequest request, Integer weiboId) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		ScWeiboStore store = weiboStoreDao.findByWeiboIdAndUserIdAndDelFlag(weiboId, currentUser.getUserId(),
				DictEnum.not_del.value);
		if (store != null) {
			return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
		}
		store = new ScWeiboStore();
		store.setUserId(currentUser.getUserId());
		store.setWeiboId(weiboId);
		store.setDelFlag(DictEnum.not_del.value);
		weiboStoreDao.save(store);
		String value = redisService.hget(DictEnum.redisWeiboStoreCountKey.value, String.valueOf(weiboId));
		int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
		redisService.hset(DictEnum.redisWeiboStoreCountKey.value, String.valueOf(weiboId), String.valueOf(++count));
		weibo = handler(weibo, currentUser);
		return CreateJson.createObjJson(weibo, true);
	}

	/**
	 * 取消收藏
	 * 
	 * @param request
	 * @param weiboId
	 * @return
	 */
	public String store_cancel(HttpServletRequest request, Integer weiboId) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		ScWeiboStore weiboStore = weiboStoreDao.findByWeiboIdAndUserIdAndDelFlag(weiboId, currentUser.getUserId(),
				DictEnum.not_del.value);
		if (weiboStore == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
		}
		weiboStoreDao.delete(weiboStore);
		String value = redisService.hget(DictEnum.redisWeiboStoreCountKey.value, String.valueOf(weiboId));
		int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
		if (count > 0) {
			redisService.hset(DictEnum.redisWeiboStoreCountKey.value, String.valueOf(weiboId), String.valueOf(--count));
		}
		weibo = handler(weibo, currentUser);
		return CreateJson.createObjJson(weibo, true);
	}

	/**
	 * 评论微博
	 * 
	 * @param request
	 * @param jsonText
	 * @return
	 */
	public String comment(HttpServletRequest request, String jsonText) {
		ScWeiboComment comment = JacksonUtil.jsonToObj(jsonText, ScWeiboComment.class);
		if (comment != null) {
			String content = comment.getContent();
			if (StringUtils.isBlank(content)) {
				return CreateJson.createTextJson(ReturnMsgEnum.commentNULL.getMessage(), false);
			}
			ScWeibo weibo = weiboDao.findByIdAndDelFlag(comment.getWeiboId(), DictEnum.not_del.value);
			if (weibo == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
			}
			ScUser currentUser = userByToken(request);
			comment.setUserId(currentUser.getUserId());
			comment.setCreateTime(new Timestamp(System.currentTimeMillis()));
			comment.setDelFlag(DictEnum.not_del.value);
			weiboCommentDao.save(comment);
			String value = redisService.hget(DictEnum.redisWeiboCommentCountKey.value,
					String.valueOf(comment.getWeiboId()));
			int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
			redisService.hset(DictEnum.redisWeiboCommentCountKey.value, String.valueOf(comment.getWeiboId()),
					String.valueOf(++count));
			weibo = handler(weibo, currentUser);
			return CreateJson.createObjJson(weibo, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 删除评论
	 * 
	 * @param request
	 * @param id
	 * @return
	 */
	public String delComment(HttpServletRequest request, Integer id) {
		ScWeiboComment comment = weiboCommentDao.findByIdAndDelFlag(id, DictEnum.not_del.value);
		if (comment == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.commentNotExist.getMessage(), false);
		}
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(comment.getWeiboId(), DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		// 判断用户是否有权限删除评论
		// 1、评论者
		// 2、有删除权限的管理员
		boolean b = false;
		if (comment.getUserId() == currentUser.getUserId()) {
			b = true;
		}
		if (!b) {
			ScTribeAuth auth = tribeAuthDao.findByTribeIdAndUserIdAndPermissionAndIsAble(DictEnum.enable.value,
					weibo.getTribeId(), currentUser.getUserId(), ScTribeAuthEnum.weiboCommentDelete.value);
			if (auth != null) {
				b = true;
			}
		}
		if (b) {
			comment.setDelFlag(DictEnum.del.value);
			weiboCommentDao.save(comment);
			String value = redisService.hget(DictEnum.redisWeiboCommentCountKey.value,
					String.valueOf(comment.getWeiboId()));
			int count = StringUtils.isBlank(value) ? 0 : Integer.parseInt(value);
			if (count > 0) {
				redisService.hset(DictEnum.redisWeiboCommentCountKey.value, String.valueOf(comment.getWeiboId()),
						String.valueOf(--count));
			}
			weibo = handler(weibo, currentUser);
			return CreateJson.createObjJson(weibo, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 用户所在部落内的微博
	 * 
	 * @param request
	 * @param index
	 * @param size
	 * @return
	 */
	public String myTribeWeibo(HttpServletRequest request, String index, String size) {
		PageInfo pageInfo = getSQLIndexAndSize(index, size);
		ScUser currentUser = userByToken(request);
		List<ScWeibo> list = weiboDao.findMyTribeWeiboByUserIdAndDelFlag(currentUser.getUserId(),
				DictEnum.not_del.value, pageInfo.get_index(), pageInfo.get_size());
		if (list != null && list.size() > 0) {
			for (ScWeibo sc : list) {
				sc = handler(sc, currentUser);
			}
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 单个部落内的微博
	 * 
	 * @param tribeId
	 * @param index
	 * @param size
	 * @return
	 */
	public String tribeWeibo(HttpServletRequest request, int tribeId, String index, String size) {
		ScUser currentUser = userByToken(request);
		ScTribeMember member = tribeMemberDao.findByTribeIdAndUserIdAndDelFlag(tribeId, currentUser.getUserId(),
				DictEnum.not_del.value);
		if (member == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.notInTribe.getMessage(), false);
		}
		PageInfo pageInfo = getPageIndexAndSize(index, size);
		List<ScWeibo> list = findByTribeIdAndDelFlagCriteria(tribeId, DictEnum.not_del.value, pageInfo.get_pageno(),
				pageInfo.get_size());
		if (list != null && list.size() > 0) {
			for (ScWeibo sc : list) {
				sc = handler(sc, currentUser);
			}
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 收藏的微博
	 * 
	 * @param request
	 * @param index
	 * @param size
	 * @return
	 */
	public String myStore(HttpServletRequest request, String index, String size) {
		PageInfo pageInfo = getSQLIndexAndSize(index, size);
		ScUser currentUser = userByToken(request);
		List<ScWeibo> list = weiboDao.findMyStoreWeiboByUserIdAndDelFlag(currentUser.getUserId(),
				DictEnum.not_del.value, pageInfo.get_index(), pageInfo.get_size());
		if (list != null && list.size() > 0) {
			for (ScWeibo sc : list) {
				sc = handler(sc, currentUser);
			}
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	/**
	 * 微博评论
	 * 
	 * @param request
	 * @param weiboId
	 * @param index
	 * @param size
	 * @return
	 */
	public String commentList(HttpServletRequest request, int weiboId, String index, String size) {
		ScWeibo weibo = weiboDao.findByIdAndDelFlag(weiboId, DictEnum.not_del.value);
		if (weibo == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.weiboNotExist.getMessage(), false);
		}
		ScUser currentUser = userByToken(request);
		ScTribeMember member = tribeMemberDao.findByTribeIdAndUserIdAndDelFlag(weibo.getTribeId(),
				currentUser.getUserId(), DictEnum.not_del.value);
		if (member == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.notInTribe.getMessage(), false);
		}
		PageInfo pageInfo = getPageIndexAndSize(index, size);
		List<ScWeiboComment> list = findCommentByWeiboIdAndDelFlagCriteria(weiboId, DictEnum.not_del.value,
				pageInfo.get_pageno(), pageInfo.get_size());
		if (list != null && list.size() > 0) {
			for (ScWeiboComment sc : list) {
				ScUser commentUser = userDao.findByUserId(sc.getUserId());
				if (commentUser != null) {
					sc.setUserName(getUserName(commentUser));
					sc.setUserImg(getUserImagePath(commentUser.getMobile()));
				}
			}
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 热门微博
	 * @param request
	 * @return
	 */
	public String hot(HttpServletRequest request,String index, String size){
		ScUser currentUser = userByToken(request);
		PageInfo pageInfo = getSQLIndexAndSize(index, size);
		List<ScWeibo> list = weiboDao.hot(DictEnum.not_del.value, DictEnum.ispublic.value, DictEnum.free.value,pageInfo.get_index(),pageInfo.get_size());
		if(list!=null && list.size()>0){
			for(ScWeibo sc:list){
				sc=handler(sc, currentUser);
			}
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false); 
	}

	///////////////////////////////////////////// JPA动态查询接口实现
	///////////////////////////////////////////// ///////////////////////////////////////////////////////////////////////////////////////

	/**
	 * 单个部落内的微博
	 * 
	 * @param tid
	 * @param delFlag
	 * @param pageno
	 * @param size
	 * @return
	 */
	public List<ScWeibo> findByTribeIdAndDelFlagCriteria(int tid, String delFlag, int pageno, int size) {
		Specification<ScWeibo> specification = new Specification<ScWeibo>() {
			@Override
			public Predicate toPredicate(Root<ScWeibo> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _tid = root.get("tribeId");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_tid, tid));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "createTime");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return weiboDao.findAll(specification, pageable).getContent();
	}

	/**
	 * 微博评论
	 * 
	 * @param weiboId
	 * @param delFlag
	 * @param pageno
	 * @param size
	 * @return
	 */
	public List<ScWeiboComment> findCommentByWeiboIdAndDelFlagCriteria(int weiboId, String delFlag, int pageno,
			int size) {
		Specification<ScWeiboComment> specification = new Specification<ScWeiboComment>() {
			@Override
			public Predicate toPredicate(Root<ScWeiboComment> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _weiboId = root.get("weiboId");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_weiboId, weiboId));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "createTime");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return weiboCommentDao.findAll(specification, pageable).getContent();
	}
}
