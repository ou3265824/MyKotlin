package com.sc.td.business.dao.groupauth;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.groupauth.ScGroupRole;

public interface ScGroupRoleDao extends BaseDao<ScGroupRole> {

	List<ScGroupRole> findByType(String type);
}
