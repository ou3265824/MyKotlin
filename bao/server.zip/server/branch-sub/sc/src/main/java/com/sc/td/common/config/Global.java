package com.sc.td.common.config;

public class Global {
	
	
	public static final String recommend_not_vip="1";
	public static final String recommend_vip="2";
	public static final String redis_price_key="LastPrice";
	public static final String encrypt_key="adminSC@mix@lx100$#365#$";
	public static final String encrypt_iv="0F5E3A24";
	//true
	public static final String token_expire="0";
	//hours
	public static final String token_expire_long="2";
	public static final String validcode_livetime="300";
	public static final String sendsms_limitTime="30";
	public static final String pk_start_time=" 00:00";
	public static final String obtainMoney_limitTime="30";
	//发送短信
	public static final int sendsms_limitCount=3;//限制5分钟内只能发送3次
	public static final int sendsms_Time=5;
	public static final int validcode_time=1800;
	public static final int groupcode_time=600;
	public static final int tribecode_time=600;
}
