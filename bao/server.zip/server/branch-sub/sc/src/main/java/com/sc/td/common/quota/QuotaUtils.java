package com.sc.td.common.quota;

import java.math.BigDecimal;

import org.apache.commons.lang3.StringUtils;

import com.sc.td.common.config.CommodityTypeEnum;
import com.sc.td.common.utils.HttpUtils;

public class QuotaUtils {

	/**
	 * 调用新浪接口获取商品现价
	 * @return
	 */
	public static BigDecimal getNowPrice(String quotaCode,String commodityType){
		try {
			String result=HttpUtils.getHttp("http://hq.sinajs.cn/list="+quotaCode);
			if(StringUtils.isNotBlank(result)){
				String[] arr=result.substring(result.indexOf("\"")+1, result.lastIndexOf("\"")).split(",");
				if(arr!=null && arr.length>3){
					if(commodityType.equals(CommodityTypeEnum.内盘期货.value)){
						return new BigDecimal(arr[8]);
					}else if(commodityType.equals(CommodityTypeEnum.内盘股票.value)){
						return new BigDecimal(arr[3]);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new BigDecimal(0.00);
	}
}
