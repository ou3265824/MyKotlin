package com.sc.td.business.dao.weibo;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.weibo.ScWeiboLike;

public interface ScWeiboLikeDao extends BaseDao<ScWeiboLike> {

	ScWeiboLike findByWeiboIdAndUserIdAndDelFlag(int weiboId,int userId,String delFlag);
}
