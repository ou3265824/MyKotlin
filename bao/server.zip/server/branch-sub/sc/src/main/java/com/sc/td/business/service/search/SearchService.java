package com.sc.td.business.service.search;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.group.ScGroupDao;
import com.sc.td.business.dao.group.ScGroupMemberDao;
import com.sc.td.business.dao.release.ScReleaseDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.group.ScGroup;
import com.sc.td.business.entity.release.ScRelease;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.business.service.release.ScReleaseService;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.redis.RedisService;

@Service
public class SearchService extends BaseService{

	@Autowired
	private ScGroupDao groupDao;
	
	@Autowired
	private ScReleaseService releaseService;
	
	@Autowired
	private ScUserDao userDao;
	
	@Autowired
	private ScGroupMemberDao groupMemberDao;
	
	@Autowired
	private ScReleaseDao releaseDao;
	
	@Autowired
	private RedisService redisService;
	
	
	/**
	 * 根据名字搜索圈子或策略(尚未结束的策略)
	 * @param name
	 * @return
	 */
	public String groupOrRelease(String type,String userId,String name){
		if(StringUtils.isNotBlank(name) && StringUtils.isNotBlank(userId)){
			Map<String,Object> map=Maps.newHashMap();
			Set<ScGroup> groupSet = findByGroupNameLike(name);
			if(groupSet!=null && groupSet.size()>0){
				for(ScGroup sc:groupSet){
					//判断当前用户是否加入该圈子
					if(checkInGroup(sc.getGroupId(), Integer.parseInt(userId))){
						sc.setIsJoin(true);
					}else{
						sc.setIsJoin(false);
					}
					ScUser user=userDao.findByUserId(sc.getUserId());//策略发布人
					if(user!=null){
						sc.setUserName(getUserName(user));
						sc.setUserImg(getUserImagePath(user.getMobile()));
					}
					sc.setGroupImg(getGroupImagePath(sc.getUserId()+"-"+sc.getGroupId()));
					sc.setPeopleCount(groupMemberDao.countByGroupIdAndDelFlag(sc.getGroupId(),DictEnum.not_del.value));
					sc.setReleaseCount(releaseDao.countByGroupIdAndDelFlag(sc.getGroupId(),DictEnum.not_del.value));
					//获取环信的圈子ID
					sc.setEaseGroupId(redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(sc.getGroupId())));
				}
			}
			map.put("group", groupSet);
			TreeSet<ScRelease> set = releaseService.findByReleaseNameLikeAndDelFlag(name,DictEnum.not_del.value);
			handlerReturnData(set,Integer.parseInt(userId));
			map.put("release", set);
			return CreateJson.createObjJson(map, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 搜索商品
	 * @param key
	 * @return
	 */
	public String marketInfo(String key){
		Set<String> set = redisService.keys("*"+key+"*");
		TreeSet<String> dataSet=Sets.newTreeSet();
		if(set!=null && set.size()>0){
			if(set.size()>20){
				Iterator<String> iterator = set.iterator();
				int count=0;
				while(iterator.hasNext()){
					String str=iterator.next();
					if(StringUtils.isNotBlank(str) && str.startsWith(DictEnum.redis_market_prefix.value)){
						dataSet.add(redisService.get(str));
						count++;
					}
					if(count==20){
						break;
					}
				}
			}else{
				for(String str:set){
					if(str.startsWith(DictEnum.redis_market_prefix.value)){
						dataSet.add(String.valueOf(redisService.get(str)));
					}
				}
			}
			if(dataSet!=null && dataSet.size()>0){
				return CreateJson.createObjJson(dataSet, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
//	/**
//	 * 根据名字搜索圈子或策略(尚未结束的策略)
//	 * 关注页面（只搜索和用户相关的圈子）
//	 * @param name
//	 * @return
//	 */
//	public String groupOrRelease(String type,String userId,String name){
//		if(StringUtils.isNotBlank(name) && StringUtils.isNotBlank(userId)){
//			Map<String,Object> map=Maps.newHashMap();
//			Set<ScGroup> groupSet = findByGroupNameLike(name);
//			if(groupSet!=null && groupSet.size()>0){
//				for(ScGroup sc:groupSet){
//					//判断当前用户是否加入该圈子
//					if(checkInGroup(sc.getGroupId(), Integer.parseInt(userId))){
//						sc.setIsJoin(true);
//					}else{
//						sc.setIsJoin(false);
//						if(type.equals(SearchTypeEnum.my.getValue())){
//							groupSet.remove(sc);
//						}
//					}
//					sc.setGroupImg(getGroupImagePath(String.valueOf(sc.getGroupId())));
//					sc.setPeopleCount(groupMemberDao.countByGroupIdAndDelFlag(sc.getGroupId(),DictEnum.not_del.value));
//					sc.setReleaseCount(releaseDao.countByGroupIdAndDelFlag(sc.getGroupId(),DictEnum.not_del.value));
//					//获取环信的圈子ID
//					sc.setEaseGroupId(redisService.hget(DictEnum.redisAppEaseGroupKey.value, String.valueOf(sc.getGroupId())));
//				}
//			}
//			map.put("group", groupSet);
//			if(type.equals(SearchTypeEnum.my.getValue())){
//				TreeSet<ScRelease> set = releaseService.findByReleaseNameLikeAndDelFlag(name,DictEnum.not_del.value);
//				handlerReturnDataMy(set,Integer.parseInt(userId));
//				map.put("release", set);
//			}
//			return CreateJson.createObjJson(map, true);
//		}
//		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
//	}
//	
	
	/**
	 * 根据策略名模糊查询特定圈子的策略
	 * @param userId
	 * @param groupId
	 * @param name
	 * @return
	 */
	public String release(String userId,String groupId,String name){
		if(StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(groupId) && StringUtils.isNotBlank(name)){
			ScUser user=userDao.findByUserId(Integer.parseInt(userId));
			if(user==null){
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			TreeSet<ScRelease> set = releaseService.findByGroupIdAndReleaseNameLikeAndDelFlag(Integer.parseInt(groupId), name,DictEnum.not_del.value);
			handlerReturnDataMy(set,Integer.parseInt(userId));
			if(set!=null && set.size()>0){
				return CreateJson.createObjJson(set, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	
	/**
	 * 根据策略名模糊查询所有圈子中和“我”相关的策略
	 * @param userId
	 * @param name
	 * @return
	 */
	public String myRelease(String userId,String name){
		if(StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(name)){
			TreeSet<ScRelease> set = releaseService.findByReleaseNameLikeAndDelFlag(name,DictEnum.not_del.value);
			handlerReturnDataMy(set,Integer.parseInt(userId));
			if(set!=null && set.size()>0){
				return CreateJson.createObjJson(set, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	
	///////////////////////////////////////////////////接口实现方法///////////////////////////////////////////////////////////////
	/**
	 * 根据圈子名称模糊查询
	 * @param groupName
	 * @return
	 */
	public Set<ScGroup> findByGroupNameLike(String groupName){
		Specification<ScGroup> specification=new Specification<ScGroup>(){

			@Override
			public Predicate toPredicate(Root<ScGroup> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _groupName = root.get("groupName");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.like(_groupName, "%" + groupName + "%"));
				return query.where(predicates.toArray(new Predicate[]{})).getRestriction();
			}
		};
		return groupDao.findAll(specification);
	}
	
}
