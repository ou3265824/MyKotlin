package com.sc.td.business.entity.tribe;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sc.td.common.persistence.BaseEntity;

@Table
@Entity
public class ScTribeAuth extends BaseEntity{

	private int id;				//主键Id
	private String name;		//权限名称
	private String permission;	//权限标记
	private String isAble;		//是否可用（0可用1不可用，默认0）
	private String remarks;		//备注
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	public String getIsAble() {
		return isAble;
	}
	public void setIsAble(String isAble) {
		this.isAble = isAble;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
}
