package com.sc.td.business.dao.groupauth;

import java.util.List;
import org.springframework.data.jpa.repository.Query;
import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.groupauth.ScGroupUserRole;

public interface ScGroupUserRoleDao extends BaseDao<ScGroupUserRole> {

	@Query(value="select t1.* from sc_group_user_role t1 join sc_group_role t2 on t1.role_id=t2.id "
			+ "where t1.group_id=?1 and t1.user_id=?2 and t2.type=?3",nativeQuery=true)
	List<ScGroupUserRole> findByGroupIdAndUserIdAndType(int groupId,int userId,String type);
	
	@Query(value="select count(t1.user_id) as count from sc_group_user_role t1 join sc_group_role t2 on t1.role_id=t2.id "
			+ "where t1.group_id=?1 and t1.user_id=?2 and t2.type=?3",nativeQuery=true)
	Long countByGroupIdAndUserIdAndType(int groupId,int userId,String type);
}
