package com.sc.td.common.config;

public enum SearchTypeEnum {

	my("0"),
	hot("1");
	
	private SearchTypeEnum(String value){
		this.value = value;
	}
	private String value;
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	@Override
	public String toString() {
		return this.value;
	}
}
