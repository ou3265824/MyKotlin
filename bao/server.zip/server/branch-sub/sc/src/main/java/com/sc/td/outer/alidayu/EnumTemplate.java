package com.sc.td.outer.alidayu;

public enum EnumTemplate {

	register("SMS_66875159"),
	resetPwd("SMS_66875157"),
	validCode("SMS_118640175");
	
	private EnumTemplate(String name){
		this.name=name;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return this.name;
	}
}
