package com.sc.td.easemob.model;

import java.io.Serializable;

import com.alibaba.fastjson.annotation.JSONField;

/**
 * 
 * @className User
 * @author jinyu(foxinmy@gmail.com)
 * @date 2015年1月28日
 * @since JDK 1.6
 * @see
 */
public class User implements Serializable {

	private static final long serialVersionUID = -4696349242637444865L;

	@JSONField(name = "username")
	private String uname;
	private String password;
	private String nickname;
	
	public User() {
	}

	public User(String uname, String password, String nickname) {
		super();
		this.uname = uname;
		this.password = password;
		this.nickname = nickname;
	}

	public String getUname() {
		return uname;
	}

	public void setUname(String uname) {
		this.uname = uname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	@Override
	public String toString() {
		return "User [uname=" + uname + ", password=" + password + ", nickname=" + nickname + "]";
	}


}
