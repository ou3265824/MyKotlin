package com.sc.td.business.controller.release;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.release.ScReleaseService;
import com.sc.td.common.config.SystemConfig;
import com.sc.td.frame.annotation.AuthCheck;

@Controller
@RequestMapping("/operate/release")
public class ScReleaseController {

	@Autowired
	private ScReleaseService releaseService;
	
	@Autowired
	private SystemConfig sysCfg;
	
	/////////////////////////////////////////////v1_1////////////////////////////////////////////////////////
	/**
	 * 发布策略
	 * @param jsonText
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/v1_1/create/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:create")
    public String create(@PathVariable Integer groupId,String jsonText,HttpServletRequest request,HttpServletResponse response){
		return releaseService.create(jsonText,request);
	}
	
	/**
	 * 修改策略
	 * @param groupId
	 * @param jsonText
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/modify/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:modify") 
    public String modify(@PathVariable Integer groupId,String jsonText,HttpServletRequest request,HttpServletResponse response) throws Exception{
		return releaseService.modify(jsonText);
	}
	
	/**
	 * 开始策略
	 * @param releaseId
	 * @return
	 */
	@RequestMapping(value="/begin/{groupId}/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:begin")
    public String begin(@PathVariable Integer groupId,@PathVariable Integer releaseId,HttpServletRequest request,HttpServletResponse response){
		return releaseService.begin(releaseId);
	}
	
	/**
	 * 结束策略
	 * @param releaseId
	 * @return
	 */
	@RequestMapping(value="/end/{groupId}/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:end")
    public String end(@PathVariable Integer groupId,@PathVariable Integer releaseId,HttpServletRequest request,HttpServletResponse response){
		return releaseService.end(releaseId);
	}
	
	/**
	 * 废弃策略
	 * @param groupId
	 * @param releaseId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/abort/{groupId}/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:abort")
	public String abort(@PathVariable Integer groupId,@PathVariable Integer releaseId,HttpServletRequest request,HttpServletResponse response){
		return releaseService.abort(releaseId);
	}

	/**
	 * 增加策略标的
	 * @param jsonText
	 * @return
	 */
	@RequestMapping(value="/add/releaseDetails/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:releaseDetails:add")
    public String addReleaseDetails(@PathVariable Integer groupId,String jsonText,HttpServletRequest request,HttpServletResponse response){
		return releaseService.addReleaseDetails(jsonText);
	}
	
	/**
	 * 删除策略标的
	 * @param releaseId
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/del/releaseDetails/{groupId}/{releaseId}/{id}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:releaseDetails:del")
    public String delReleaseDetails(@PathVariable Integer groupId,@PathVariable Integer releaseId,@PathVariable Integer id,HttpServletRequest request,HttpServletResponse response){
		return releaseService.delReleaseDetails(releaseId, id);
	}
	
	/**
	 * 策略标的平仓
	 * @param releaseId
	 * @param id
	 * @return
	 */
	@RequestMapping(value="/close/releaseDetails/{groupId}/{releaseId}/{id}/{nowPrice}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:releaseDetails:close")
    public String closeReleaseDetails(@PathVariable Integer groupId,@PathVariable Integer releaseId,@PathVariable Integer id,@PathVariable BigDecimal nowPrice,HttpServletRequest request,HttpServletResponse response){
		return releaseService.closeReleaseDetails(releaseId, id, nowPrice);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * 发布策略
	 * @param jsonText
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/create_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String create(String jsonText,HttpServletRequest request){
		return releaseService.create(jsonText,request);
	}
	
	/**
	 * 开始策略
	 * @param releaseId
	 * @return
	 */
	@RequestMapping(value="/begin/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String begin(@PathVariable Integer releaseId){
		return releaseService.begin(releaseId);
	}
	
	/**
	 * 结束策略
	 * @param releaseId
	 * @return
	 */
	@RequestMapping(value="/end/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String end(@PathVariable Integer releaseId){
		return releaseService.end(releaseId);
	}
	
	/**
	 * 查询“我”的策略（包括验证的和发起的正在进行中的策略）
	 * 所有圈子
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/my/{userId}/{type}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String my(@PathVariable String userId,@PathVariable String type){
		return releaseService.my(userId,type);
	}
	
	/**
	 * 根据策略状态查询“我”的策略
	 * 所有圈子
	 * @param userId
	 * @param status
	 * @return
	 */
	@RequestMapping(value="/my/status/{userId}/{status}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String myByStatus(@PathVariable String userId,@PathVariable String status){
		return releaseService.myByStatus(userId, status);
	}
	
	/**
	 * 查询“我”的策略（包括验证的和发起的正在进行中的策略）
	 * 特定圈子
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/my/group/{userId}/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String myByGroupId(@PathVariable String userId,@PathVariable String groupId){
		return releaseService.myByGroupId(userId,groupId);
	}
	
	/**
	 * 策略排行榜
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/rank/{userId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String rank(@PathVariable String userId,@PathVariable String index,@PathVariable String size){
		return releaseService.rank(userId,index,size);
	}
	
	/**
	 * 根据GroupId获取策略（不包括已结束的策略）
	 * @param groupId
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/find/group/{userId}/{groupId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String findByGroupId(@PathVariable String userId,@PathVariable String groupId,@PathVariable String index,@PathVariable String size){
		return releaseService.findByGroupId(userId,groupId,index,size);
	}
	
	
	/**
	 * 根据GroupId和策略状态获取策略
	 * @param groupId
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/find/group/status/{userId}/{groupId}/{status}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String findByGroupIdAndStatus(@PathVariable String userId,@PathVariable String groupId,@PathVariable String status,@PathVariable String index,@PathVariable String size){
		return releaseService.findByGroupIdAndStatus(userId,groupId,status,index,size);
	}
	
	/**
	 * 在“我的”页面查看“策略收益”
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/my/profit/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String myReleaseProfit(@PathVariable String userId){
		return releaseService.myReleaseProfit(userId);
	}
	
	/**
	 * 查看策略详情
	 * @param releaseId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/details/{releaseId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String releaseDetails(@PathVariable String releaseId,@PathVariable String userId){
		return releaseService.releaseDetails(releaseId,userId);
	}
	
	/**
	 * 添加投注
	 * @param releaseId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/add/releaseUser/{releaseId}/{userId}/{amount}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String addReleaseUser(@PathVariable String releaseId,@PathVariable String userId,@PathVariable String amount){
		return releaseService.addReleaseUser(releaseId, userId, amount);
	}
	
	/**
	 * 获取策略风险告知书
	 * @return
	 */
	@RequestMapping(value="/agreement",method = RequestMethod.GET,produces = "application/json; charset=utf-8")
	@ResponseBody
	public String getAgreetmentUrl(){
		return sysCfg.getProtocol()+sysCfg.getNginx_path()+sysCfg.getNginx_project_folder()+"/release-agreement.html";
	}
	
	/**
	 * 获取策略投注人
	 * @param releaseId
	 * @return
	 */
	@RequestMapping(value="/user/{groupId}/{releaseId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:user:list") 
    public String releaseUserList(@PathVariable Integer groupId,@PathVariable Integer releaseId,HttpServletRequest request,HttpServletResponse response){
		return releaseService.releaseUserList(releaseId);
	}
	
	/**
	 * 删除策略投注人
	 * @param groupId
	 * @param releaseId
	 * @param userId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/del/user/{groupId}/{releaseId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:release:del:user")
    public String delReleaseUser(@PathVariable Integer groupId,@PathVariable Integer releaseId,@PathVariable Integer userId,HttpServletRequest request,HttpServletResponse response){
		return releaseService.delReleaseUser(releaseId,userId);
	}
	
	/**
	 * 撤销投注
	 * @param releaseId
	 * @param userId
	 * @param request
	 * @return
	 */
	@RequestMapping(value="/cancel/bet/{releaseId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String cancelBet(@PathVariable Integer releaseId,@PathVariable Integer userId,HttpServletRequest request){
		return releaseService.cancelBet(releaseId, userId, request);
	}
}
