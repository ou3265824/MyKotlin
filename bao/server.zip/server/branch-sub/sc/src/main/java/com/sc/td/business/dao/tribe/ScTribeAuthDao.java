package com.sc.td.business.dao.tribe;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.tribe.ScTribeAuth;

public interface ScTribeAuthDao extends BaseDao<ScTribeAuth> {

	@Query(value = "select auth.id,auth.name,auth.permission,auth.is_able,auth.remarks,auth.create_by,auth.create_date,auth.update_by,"
			+ "auth.update_date from sc_tribe_member member "
			+ "join sc_tribe_user_role userRole on member.user_id=userRole.user_id	and member.tribe_id=userRole.tribe_id "
			+ "join sc_tribe_role role on userRole.role_id=role.id	"
			+ "join sc_tribe_role_auth roleAuth on role.id=roleAuth.role_id	"
			+ "join sc_tribe_auth auth on roleAuth.auth_id=auth.id and auth.is_able=?1 "
			+ "where member.tribe_id=?2 and member.user_id=?3 ", nativeQuery = true)
	List<ScTribeAuth> findByTribeIdAndUserIdAndIsAble(String isAble,int tribeId,int userId);
	
	@Query(value = "select auth.id,auth.name,auth.permission,auth.is_able,auth.remarks,auth.create_by,auth.create_date,auth.update_by,"
			+ "auth.update_date from sc_tribe_member member "
			+ "join sc_tribe_user_role userRole on member.user_id=userRole.user_id	and member.tribe_id=userRole.tribe_id "
			+ "join sc_tribe_role role on userRole.role_id=role.id	"
			+ "join sc_tribe_role_auth roleAuth on role.id=roleAuth.role_id	"
			+ "join sc_tribe_auth auth on roleAuth.auth_id=auth.id and auth.is_able=?1 "
			+ "where member.tribe_id=?2 and member.user_id=?3 and auth.permission=?4", nativeQuery = true)
	ScTribeAuth findByTribeIdAndUserIdAndPermissionAndIsAble(String isAble,int tribeId,int userId,String permission);
}
