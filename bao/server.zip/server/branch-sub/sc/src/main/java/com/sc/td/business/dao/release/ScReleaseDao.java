package com.sc.td.business.dao.release;

import java.util.TreeSet;
import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.release.ScRelease;

public interface ScReleaseDao extends BaseDao<ScRelease>{

	List<ScRelease> findByReleaseName(String releaseName);
	
	TreeSet<ScRelease> findByUserIdAndGroupIdAndDelFlag(int userId,int groupId,String delFlag);
	
	ScRelease findByReleaseIdAndDelFlag(int releaseId,String delFlag);
	
	Long countByGroupIdAndDelFlag(int groupId,String delFlag);
	
	TreeSet<ScRelease> findByUserIdAndDelFlagAndStatus(int userId,String delFlag,String status);
	
	TreeSet<ScRelease> findByUserIdAndDelFlagAndStatusNot(int userId,String delFlag,String status);
	
	Long countByUserIdAndGroupIdAndDelFlagAndStatus(int userId,int groupId,String delFlag,String status);
	
	TreeSet<ScRelease> findByUserIdAndGroupIdAndDelFlagAndStatusNot(int userId,int groupId,String delFlag,String status);
	
	Long countByReleaseIdAndUserIdAndGroupIdAndDelFlag(int releaseId,int userId,int groupId,String delFlag);
	
	Long countByReleaseIdAndProducerAndDelFlag(int releaseId,int producer,String delFlag);
	
	//分页查询
	Page<ScRelease> findAll(Specification<ScRelease> specification,Pageable pageable);
	//不分页查询
	TreeSet<ScRelease> findAll(Specification<ScRelease> specification);
}
