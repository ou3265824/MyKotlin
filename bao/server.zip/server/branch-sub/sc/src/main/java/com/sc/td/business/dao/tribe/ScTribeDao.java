package com.sc.td.business.dao.tribe;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.tribe.ScTribe;

public interface ScTribeDao extends BaseDao<ScTribe> {

	List<ScTribe> findByTribeName(String tname);
	
	ScTribe findByTribeIdAndDelFlag(int tid,String delFlag);
	
	Long countByUserIdAndTribeIdAndDelFlag(int userId,int tribeId,String delFlag);
}
