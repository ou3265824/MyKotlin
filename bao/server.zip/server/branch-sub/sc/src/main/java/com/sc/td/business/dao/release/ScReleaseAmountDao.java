package com.sc.td.business.dao.release;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.release.ScReleaseAmount;

public interface ScReleaseAmountDao extends BaseDao<ScReleaseAmount> {

}
