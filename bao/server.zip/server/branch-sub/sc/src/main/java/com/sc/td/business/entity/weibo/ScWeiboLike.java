package com.sc.td.business.entity.weibo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Table
@Entity
@IdClass(WeiboLikePk.class)
public class ScWeiboLike {

	private int weiboId;	//微博Id
	private int userId;		//点赞人Id
	private String delFlag; //删除标记（0正常1删除）
	@Id
	public int getWeiboId() {
		return weiboId;
	}
	public void setWeiboId(int weiboId) {
		this.weiboId = weiboId;
	}
	@Id
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	
}
