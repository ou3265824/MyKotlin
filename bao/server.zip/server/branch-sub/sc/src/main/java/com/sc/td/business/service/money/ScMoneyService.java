package com.sc.td.business.service.money;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.money.ScMoneyDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.money.ScMoney;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.page.PageInfo;

@Service
public class ScMoneyService extends BaseService{

	@Autowired
	private ScMoneyDao moneyDao;
	
	@Autowired
	private ScUserDao userDao;
	
	/**
	 * 根据userId获取用户的出入金情况
	 * @param userId
	 * @param index1
	 * @param size1
	 * @return
	 */
	public String listByUserId(Integer userId,String index1,String size1){
		PageInfo pageInfo = getPageIndexAndSize(index1, size1);
		if(userId!=null){
			ScUser user=userDao.findByUserId(userId);
			if(user==null){
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			List<ScMoney> list = findByUserIdAndAcceptStatus(userId,pageInfo.get_pageno(),pageInfo.get_size());
			if(list!=null && list.size()>0){
				return CreateJson.createObjJson(list, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	//////////////////////////////////实现动态查询///////////////////////////////////////////////////////////////
	public List<ScMoney> findByUserIdAndAcceptStatus(Integer userId,int pageno,int size){
		Specification<ScMoney> specification = new Specification<ScMoney>() {
			@Override
			public Predicate toPredicate(Root<ScMoney> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _userId = root.get("userId");
				Path<String> _acceptStatus = root.get("acceptStatus");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_userId, userId));
				predicates.add(cb.equal(_acceptStatus, DictEnum.audit_pass.value));
				return cb.and(predicates.toArray(new Predicate[]{}));
			}

		};
		Sort sort = new Sort(Direction.DESC, "applyTime");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return moneyDao.findAll(specification, pageable).getContent();
	}
}
