package com.sc.td.easemob.api;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.easemob.model.Group;

@Service("groupApi")
public class GroupApi extends BaseApi {


	/**
	 * 创建一个群组
	 * @param group
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult createGroup(Group group) throws EasemobException{
		String create_user_url = getRequestUri0("create_groups_url");
		JSONObject response = post(create_user_url, JSON.toJSONString(group));
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	
	/**
	 * 添加一个群成员
	 * @param groupId
	 * @param userName
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult addGroupMember(String userName,String groupId) throws EasemobException{
		String operate_group_member = getRequestUri1("operate_group_member",groupId,userName);
		JSONObject response = post(operate_group_member, JSON.toJSONString(operate_group_member));
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	
	/**
	 * 删除一个群成员
	 * @param groupId
	 * @param userName
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult deleteGroupMember(String userName,String groupId) throws EasemobException{
		String operate_group_member = getRequestUri1("operate_group_member",groupId,userName);
		JSONObject response = delete(operate_group_member, null);
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	/**
	 * 修改群组信息
	 * 只能修改群组名、群描述、群人数
	 * @param groupId
	 * @param params
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult modifyGroup(String groupId,Map<String,String> params) throws EasemobException{
		String modify_group_url = getRequestUri1("modify_group_url",groupId);
		JSONObject response = post(modify_group_url, JSON.toJSONString(params));
		return JSON.toJavaObject(response, ApiResult.class);
	}
	
	/**
	 * 获取一个用户参与的所有群组
	 * @param userName
	 * @return
	 * @throws EasemobException
	 */
	public ApiResult getUserGroups(String userName) throws EasemobException{
		String user_chatgroups_url=getRequestUri1("user_chatgroups_url", userName);
		JSONObject response=get(user_chatgroups_url,null);
		return JSON.toJavaObject(response, ApiResult.class);
	}
}
