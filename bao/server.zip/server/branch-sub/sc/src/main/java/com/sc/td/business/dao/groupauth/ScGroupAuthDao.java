package com.sc.td.business.dao.groupauth;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.groupauth.ScGroupAuth;

public interface ScGroupAuthDao extends BaseDao<ScGroupAuth> {

	@Query(value = "select auth.* from sc_group_member member "
			+ "join sc_group_user_role userRole on member.user_id=userRole.user_id	and member.group_id=userRole.group_id "
			+ "join sc_group_role role on userRole.role_id=role.id	"
			+ "join sc_group_role_auth roleAuth on role.id=roleAuth.role_id	"
			+ "join sc_group_auth auth on roleAuth.auth_id=auth.id and auth.is_able=?1 "
			+ "where member.group_id=?2 and member.user_id=?3 and auth.permission=?4", nativeQuery = true)
	List<ScGroupAuth> findByGroupIdAndUserIdAndPermissionAndIsAble(String isAble,int groupId,int userId,String permission);
	
	@Query(value = "select auth.* from sc_group_member member "
			+ "join sc_group_user_role userRole on member.user_id=userRole.user_id	and member.group_id=userRole.group_id "
			+ "join sc_group_role role on userRole.role_id=role.id	"
			+ "join sc_group_role_auth roleAuth on role.id=roleAuth.role_id	"
			+ "join sc_group_auth auth on roleAuth.auth_id=auth.id and auth.is_able=?1 "
			+ "where member.group_id=?2 and member.user_id=?3 ", nativeQuery = true)
	List<ScGroupAuth> findByGroupIdAndUserIdAndIsAble(String isAble,int groupId,int userId);
}
