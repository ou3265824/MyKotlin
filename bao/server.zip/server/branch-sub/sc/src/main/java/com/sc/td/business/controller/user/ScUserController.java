package com.sc.td.business.controller.user;

import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.user.ScUserService;

@Controller
@RequestMapping("/operate/user")
public class ScUserController {

	@Autowired
	private ScUserService userService;
	
	
	//////////////////////////////////////////////v1.1///////////////////////////////////////////////////////
	
	/**
	 * 注册
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/v1_1/register",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String register_v1_1(String jsonText) throws Exception{
		return userService.register_v1_1(jsonText);
	}
	
	/**
	 * 登录
	 * @param jsonText
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/v1_1/login",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String login_v1_1(String jsonText) throws Exception{
		return userService.login_v1_1(jsonText);
	}
	
	/**
	 * 重置密码
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/v1_1/resetPwd",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String resetPwd_v1_1(String jsonText) throws Exception{
		return userService.resetPwd_v1_1(jsonText);
	}
	
	/**
	 * 忘记密码
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/v1_1/fgtPwd",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String fgtPwd_v1_1(String jsonText) throws Exception{
		return userService.fgtPwd_v1_1(jsonText);
	}
	///////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * 登录/注册
	 * @param jsonText
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/login",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String login(String jsonText) throws Exception{
		return userService.login(jsonText);
	}
	
	/**
	 * 修改个人信息
	 * @param jsonText
	 * @return
	 * @throws Exception 
	 */
	@RequestMapping(value="/modify_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String modify(String jsonText,HttpServletRequest request) throws Exception{
		return userService.modify(jsonText,request);
	}
	
	/**
	 * 获取用户资产情况
	 */
    @RequestMapping(value="/asset/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getUserAsset(@PathVariable String userId) throws Exception{
		return userService.getUserAsset(userId);
	}
	
	/**
	 * 上传头像
	 * 
	 * @param request
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException 
	 */
	@RequestMapping(value = "/uploadImg_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String uploadImg(HttpServletRequest request, String jsonText) throws UnknownHostException {
		return userService.uploadImg(jsonText,request);
	}
	
	/**
	 * 用户登出
	 * 
	 * @param request
	 * @return
	 * @throws UnknownHostException
	 * @
	 */
	@RequestMapping(value = "/logout_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String logout(HttpServletRequest request, String jsonText) throws UnknownHostException {
		String token = request.getHeader("token");
		return userService.logout(token, jsonText);
	}
	
}
