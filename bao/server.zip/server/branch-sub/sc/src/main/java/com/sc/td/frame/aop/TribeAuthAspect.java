package com.sc.td.frame.aop;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sc.td.business.dao.tribe.ScTribeAuthDao;
import com.sc.td.business.dao.tribe.ScTribeDao;
import com.sc.td.business.entity.tribe.ScTribe;
import com.sc.td.business.entity.tribe.ScTribeAuth;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.UnicodeUtils;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.jwt.Jwt;
import com.sc.td.frame.annotation.TribeAuthCheck;

import javassist.NotFoundException;

@Component
@Aspect
public class TribeAuthAspect {

	private Logger log = LoggerFactory.getLogger(getClass());
	
	@Autowired
	private ScTribeAuthDao scTribeAuthDao;

	@Autowired
	private ScTribeDao tribeDao;
	
	@Pointcut("execution(* com.sc.td.business..*.*(..))")
	public void init() {

	}

	@SuppressWarnings("unchecked")
	@Around(value = "init() && @annotation(ac)")
	public Object before(ProceedingJoinPoint point, TribeAuthCheck ac) throws IOException, NotFoundException, ClassNotFoundException {
		Object o = null;
		Object[] args = point.getArgs();
		Integer tribeId = null;
		Signature signature = point.getSignature();
		MethodSignature methodSignature = (MethodSignature) signature;
		String[] paramsArr = methodSignature.getParameterNames();
		for (int i = 0; i < paramsArr.length; i++) {
			if (paramsArr[i].equals("tribeId")) {
				tribeId = (Integer) args[i];
			}
		}
		HttpServletResponse response = null;
		HttpServletRequest request = null;
		for (int i = 0; i < args.length; i++) {
			if (args[i] instanceof HttpServletResponse) {
				response = (HttpServletResponse) args[i];
			} else if (args[i] instanceof HttpServletRequest) {
				request = (HttpServletRequest) args[i];
			}
		}
		String permission = ac.value();// 权限名
		String resp = CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
		if (StringUtils.isBlank(permission)) {
			response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
		} else {
			// 验证当前用户是否有此权限
			// 1、从token中获取用户ID
			String token = request.getHeader("token");
			Map<String, Object> resultMap = Jwt.validToken(token);
			Map<String, Object> dataMap = new HashMap<String, Object>();
			dataMap = (HashMap<String, Object>) resultMap.get("data");
			String userId = String.valueOf(dataMap.get("userId"));
			ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
			if(tribe==null){
				resp = CreateJson.createTextJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
				response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			}
			ScTribeAuth auth = scTribeAuthDao.findByTribeIdAndUserIdAndPermissionAndIsAble(DictEnum.enable.value,tribeId,
					Integer.parseInt(userId), permission);
			if (tribe.getUserId()!=Integer.parseInt(userId) && auth == null) {
				response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			}else{
				try {
			        //执行
			        o = point.proceed(point.getArgs());
			    } catch (Throwable e) {
			        e.printStackTrace();
			        String className = point.getThis().toString();  
			        String methodName = point.getSignature().getName(); 
			        log.error(className+"."+methodName+" Exception:"+e.getMessage());	     
			        resp = CreateJson.createTextJson(ReturnMsgEnum.sysExeption.getMessage(), false);
			        response.sendRedirect(request.getContextPath() + "/baseResp?resp=" + UnicodeUtils.enUnicode(resp));
			    }
			}
		}
		return o;
	}

}
