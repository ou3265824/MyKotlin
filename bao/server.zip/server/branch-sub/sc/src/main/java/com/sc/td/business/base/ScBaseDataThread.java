package com.sc.td.business.base;

public class ScBaseDataThread implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}

}
