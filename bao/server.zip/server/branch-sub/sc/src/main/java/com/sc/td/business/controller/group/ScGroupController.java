package com.sc.td.business.controller.group;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLDecoder;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.group.ScGroupService;
import com.sc.td.easemob.exception.EasemobException;
import com.sc.td.frame.annotation.AuthCheck;

@Controller
@RequestMapping("/operate/group")
public class ScGroupController {

	@Autowired
	private ScGroupService groupService;
	
	/**
	 * 根据用户名查找圈子内用户
	 * @param groupId
	 * @param userName
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping(value="/member/by/name/{groupId}/{userName}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String allGroupMember(@PathVariable Integer groupId,@PathVariable String userName) throws UnsupportedEncodingException{
		return groupService.memberByNameLike(groupId, URLDecoder.decode(userName,"UTF-8"));
	}
	
	/**
	 * 获取圈子内所有成员
	 * @param groupId
	 * @return
	 */
	@RequestMapping(value="/all/member/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String allGroupMember(@PathVariable Integer groupId){
		return groupService.allGroupMember(groupId);
	}
	
	/**
	 * 生成邀请码
	 * @param groupId
	 * @param request
	 * @param response
	 * @return
	 * @throws EasemobException
	 * @throws IOException
	 */
	@RequestMapping(value="/generate/code/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:group:generate:code")
    public String generateCode(@PathVariable Integer groupId,HttpServletRequest request,HttpServletResponse response){
		return groupService.generateCode(groupId);
	}
	
	/**
	 * 获取邀请码
	 * @param groupId
	 * @return
	 * @throws EasemobException
	 * @throws IOException
	 */
	@RequestMapping(value="/obtain/code/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String obtainCode(@PathVariable Integer groupId) throws EasemobException, IOException{
		return groupService.obtainCode(groupId);
	}
	
	/**
	 * 根据邀请码加入圈子
	 * @param userId
	 * @param code
	 * @return
	 * @throws EasemobException
	 * @throws IOException
	 */
	@RequestMapping(value="/join/by/code/{userId}/{code}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String joinGroupByCode(@PathVariable Integer userId,@PathVariable String code) throws EasemobException, IOException{
		return groupService.joinGroupByCode(userId, code);
	}
	
	/**
	 * 创建圈子
	 * @param jsonText
	 * @param request
	 * @return
	 * @throws EasemobException 
	 * @throws IOException 
	 */
	@RequestMapping(value="/create_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String create(String jsonText,HttpServletRequest request) throws EasemobException, IOException{
		return groupService.create(jsonText,request);
	}
	
	/**
	 * 查询“我”加入的圈子
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/myJoin/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String findMyJoin(@PathVariable("userId") String userId){
		return groupService.findMyJoin(userId);
	}
	
	/**
	 * 获取热门圈子
	 * @param userId
	 * @param index
	 * @param size
	 * @return
	 * @throws InterruptedException
	 */
	@RequestMapping(value="/hot/{userId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String index(@PathVariable("userId") String userId,@PathVariable("index") String index,@PathVariable("size") String size) throws InterruptedException{
		
		return groupService.hotGroup(userId, index, size);
	}
	
	/**
	 * 上传头像
	 * 
	 * @param request
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException 
	 */
	@RequestMapping(value = "/uploadImg_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String uploadImg(HttpServletRequest request, String jsonText) throws UnknownHostException {
		return groupService.uploadImg(jsonText,request);
	}
	
	/**
	 * 申请加入圈子
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException 
	 */
	@RequestMapping(value = "/join_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String join(String jsonText) throws UnknownHostException, EasemobException {
		return groupService.joinApply(jsonText);
	}
	
	/**
	 * 审核加入圈子信息
	 * @param groupId
	 * @param applyUserId
	 * @param auditUserId
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException 
	 */
	@RequestMapping(value = "/audit/{groupId}/{applyUserId}/{auditUserId}/{status}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String audit(@PathVariable String groupId,@PathVariable String applyUserId,@PathVariable String auditUserId,@PathVariable String status) throws UnknownHostException, EasemobException {
		return groupService.audit(groupId,applyUserId,auditUserId,status);
	}
	
	
	/**
	 * 查询圈子内的成员
	 * @param groupId
	 * @param index
	 * @param size
	 * @return
	 * @throws UnknownHostException
	 */
	@RequestMapping(value = "/member/{groupId}/{index}/{size}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String groupMember(@PathVariable String groupId,@PathVariable String index,@PathVariable String size) throws UnknownHostException {
		return groupService.groupMember(groupId, index, size);
	}
	
	/**
	 * 修改群组信息
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 * @throws InvocationTargetException 
	 * @throws IllegalArgumentException 
	 * @throws IllegalAccessException 
	 * @throws EasemobException 
	 */
	@RequestMapping(value = "/modify/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String modify(String jsonText) throws UnknownHostException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, EasemobException {
		return groupService.modify(jsonText);
	}
	
	/**
	 * 退出圈子
	 * @param groupId
	 * @param userId
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException
	 */
	@RequestMapping(value = "/quit/{groupId}/{userId}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String quit(@PathVariable String groupId,@PathVariable String userId) throws UnknownHostException, EasemobException {
		return groupService.quit(groupId, userId);
	}
	
	/**
	 * 根据环信群组ID获取APP圈子信息
	 * @param easeGroupId
	 * @param userId
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException
	 */
	@RequestMapping(value = "/by/easechat/{easeGroupId}/{userId}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String groupByEaseChat(@PathVariable String easeGroupId,@PathVariable String userId) throws UnknownHostException, EasemobException {
		return groupService.groupByEaseChat(easeGroupId, userId);
	}
	
	/**
	 * 根据groupId获取圈子的信息
	 * @param groupId
	 * @param userId
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException
	 */
	@RequestMapping(value = "/by/groupId/{groupId}/{userId}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String groupById(@PathVariable String groupId,@PathVariable String userId) throws UnknownHostException, EasemobException {
		return groupService.groupById(groupId, userId);
	}
	
	/**
	 * 根据环信用户名和环信群ID获取APP的用户和圈子信息（单条获取）
	 * 该接口用于验证消息的数据显示
	 * @param easeUserName
	 * @param easeGroupId
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException
	 */
	@RequestMapping(value = "/ease/2/app/{easeUserName}/{easeGroupId}/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String ease2app(@PathVariable String easeUserName,@PathVariable String easeGroupId) throws UnknownHostException, EasemobException {
		return groupService.ease2app(easeUserName, easeGroupId);
	}
	
	/**
	 * 根据环信用户名和环信群ID获取APP的用户和圈子信息（多条获取）
	 * 该接口用于验证消息的数据显示
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 * @throws EasemobException
	 */
	@RequestMapping(value = "/easelist/2/app/_ckt", method = RequestMethod.POST, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String easeList2App(String jsonText) throws UnknownHostException, EasemobException {
		return groupService.easeList2App(jsonText);
	}
	
	/**
	 * 加入/退出环信群组时异常
	 * @param type
	 * @param userId
	 * @param groupId
	 * @return
	 */
	@RequestMapping(value = "/joinorquit/exception/{type}/{userId}/{groupId}/_ckt", method = {RequestMethod.POST,RequestMethod.GET}, produces = "application/json; charset=utf-8")
	@ResponseBody
	public String joinOrQuitException(@PathVariable String type,@PathVariable String userId,@PathVariable String groupId){
		return groupService.joinOrQuitException(type, userId, groupId);
	}
	
	
	/**
	 * 分配管理员
	 * @param groupId
	 * @param userIds
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/allot/manager/{groupId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:allot:manager")
    public String allotManager(@PathVariable Integer groupId,@PathVariable Integer userId,HttpServletRequest request,HttpServletResponse response){
		return groupService.allotManager(groupId, userId);
	}
	
	/**
	 * 移除管理员
	 * @param groupId
	 * @param userId
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value="/remove/manager/{groupId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
	@AuthCheck("sc:remove:manager")
    public String removeManager(@PathVariable Integer groupId,@PathVariable Integer userId,HttpServletRequest request,HttpServletResponse response){
		return groupService.removeManager(groupId, userId);
	}
	
	/**
	 * 获取圈子内的所有管理员（非超管）
	 * @param groupId
	 * @return
	 */
	@RequestMapping(value="/managers/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllManager(@PathVariable Integer groupId){
		return groupService.getAllManager(groupId);
	}
	
	/**
	 * 获取圈子内的所有非管理员
	 * @param groupId
	 * @return
	 */
	@RequestMapping(value="/not/managers/{groupId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllNotManager(@PathVariable Integer groupId){
		return groupService.getAllNotManager(groupId);
	}
	
	
	/**
	 * 获取用户在圈子内的权限
	 * @param groupId
	 * @param userId
	 * @return
	 */
	@RequestMapping(value="/user/auth/{groupId}/{userId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String getAllUserAuth(@PathVariable Integer groupId,@PathVariable Integer userId){
		return groupService.getAllUserAuth(groupId, userId);
	}
}
