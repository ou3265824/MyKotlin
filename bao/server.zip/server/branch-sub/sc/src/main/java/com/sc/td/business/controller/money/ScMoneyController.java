package com.sc.td.business.controller.money;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.money.ScMoneyService;

@Controller
@RequestMapping("/operate/money")
public class ScMoneyController {

	@Autowired
	private ScMoneyService moneyService;
	
	/**
	 * 根据userId获取用户的出入金情况
	 * @param userId
	 * @param index
	 * @param size
	 * @return
	 */
	@RequestMapping(value="/list/{userId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String create(@PathVariable Integer userId,@PathVariable String index,@PathVariable String size){
		return moneyService.listByUserId(userId, index, size);
	}
}
