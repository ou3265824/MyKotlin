package com.sc.td.business.dao.group;

import java.util.List;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.group.ScGroupMember;

public interface ScGroupMemberDao extends BaseDao<ScGroupMember>,SpecificationDao<ScGroupMember> {

	ScGroupMember findByGroupIdAndUserIdAndDelFlag(int groupId,int userId,String delFlag);
	
	List<ScGroupMember> findByUserIdAndDelFlagOrderByUpdateDateDesc(int userId,String delFlag);
	
	Long countByGroupIdAndDelFlag(int groupId,String delFlag);
	
	@Query(value="select t1.* from sc_group_member t1 join sc_group_user_role t2 on t1.user_id=t2.user_id "
			+ "join sc_group_role t3 on t2.role_id=t3.id where t1.group_id=?1 and t3.type=?2",nativeQuery=true)
	List<ScGroupMember> findByGroupIdAndRoleType(int groupId,String type);
	
	@Query(value="select * from sc_group_member where user_id not in (select t1.user_id from sc_group_member t1 "
			+ "join sc_group_user_role t2 on t1.user_id=t2.user_id and t1.group_id=t2.group_id join sc_group_role t3 on t2.role_id=t3.id "
			+ "where t1.group_id=?1 and (t3.type<>?2 or t3.type<>?3)) and group_id=?1",nativeQuery=true)
	List<ScGroupMember> findByGroupIdAndRoleType(int groupId,String type1,String type2);
	
	List<ScGroupMember> findByGroupId(int groupId);
	
	@Query(value="select t1.* from sc_group_member t1 join sc_user t2 on t1.user_id=t2.user_id "
			+ "where t1.group_id=?1 and t2.user_name like CONCAT('%',?2,'%')",nativeQuery=true)
	List<ScGroupMember> findByGroupIdAndUserNameLike(int groupId,String userName);
}
