package com.sc.td.business.entity.release;

import java.io.Serializable;

public class ReleaseUserPk implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int releaseId;
	private int userId;
	
	public ReleaseUserPk() {
		super();
	}
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + releaseId;
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ReleaseUserPk other = (ReleaseUserPk) obj;
		if (releaseId != other.releaseId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
}
