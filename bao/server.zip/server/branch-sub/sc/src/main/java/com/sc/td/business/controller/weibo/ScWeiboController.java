package com.sc.td.business.controller.weibo;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.weibo.ScWeiboService;
import com.sc.td.common.config.SystemConfig;

@Controller
@RequestMapping("/operate/weibo")
public class ScWeiboController {
	
	@Autowired
	private ScWeiboService weiboService;

	@Autowired
	private SystemConfig sysCfg;
	
	/**
	 * 发布微博	
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/publish_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String publish(HttpServletRequest request) throws Exception{
		return weiboService.publish(request, sysCfg.getUserfiles_weibo_url());
	}

	/**
	 * 删除微博
	 * @param request
	 * @param weiboId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/del/{weiboId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String del(HttpServletRequest request,@PathVariable Integer weiboId) throws Exception{
		return weiboService.del(request, weiboId);
	}
	
	/**
	 * 点赞
	 * @param weiboId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/like/{weiboId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String like(@PathVariable Integer weiboId,HttpServletRequest request) throws Exception{
		return weiboService.like(request, weiboId);
	}
	
	/**
	 * 取消点赞
	 * @param weiboId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/cancel/like/{weiboId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String like_cancel(@PathVariable Integer weiboId,HttpServletRequest request) throws Exception{
		return weiboService.like_cancel(request, weiboId);
	}
	
	/**
	 * 收藏
	 * @param weiboId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/store/{weiboId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String store(@PathVariable Integer weiboId,HttpServletRequest request) throws Exception{
		return weiboService.store(request, weiboId);
	}
	
	/**
	 * 取消收藏
	 * @param weiboId
	 * @param request
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/cancel/store/{weiboId}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String store_cancel(@PathVariable Integer weiboId,HttpServletRequest request) throws Exception{
		return weiboService.store_cancel(request, weiboId);
	}
	
	/**
	 * 评论微博
	 * @param request
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/comment_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String comment(HttpServletRequest request,String jsonText) throws Exception{
		return weiboService.comment(request, jsonText);
	}
	
	/**
	 * 删除评论
	 * @param request
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/del/comment/{id}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String delComment(HttpServletRequest request,@PathVariable Integer id) throws Exception{
		return weiboService.delComment(request, id);
	}
	
	/**
	 * 用户所在部落的微博
	 * @param request
	 * @param index
	 * @param size
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/my/tribe/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String myTribeWeibo(HttpServletRequest request,@PathVariable String index,@PathVariable String size) throws Exception{
		return weiboService.myTribeWeibo(request, index, size);
	}
	
	/**
	 * 单个部落内的微博
	 * @param tribeId
	 * @param index
	 * @param size
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/tribe/{tribeId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String tribeWeibo(HttpServletRequest request,@PathVariable Integer tribeId,@PathVariable String index,@PathVariable String size) throws Exception{
		return weiboService.tribeWeibo(request,tribeId, index, size);
	}
	
	/**
	 * 收藏的微博
	 * @param request
	 * @param index
	 * @param size
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/my/store/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String myStore(HttpServletRequest request,@PathVariable String index,@PathVariable String size) throws Exception{
		return weiboService.myStore(request, index, size);
	}
	
	/**
	 * 微博评论
	 * @param request
	 * @param weiboId
	 * @param index
	 * @param size
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/comment/list/{weiboId}/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String commentList(HttpServletRequest request,@PathVariable Integer weiboId,@PathVariable String index,@PathVariable String size) throws Exception{
		return weiboService.commentList(request, weiboId, index, size);
	}
	
	/**
	 * 热门微博
	 * @param request
	 * @param weiboId
	 * @param index
	 * @param size
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/hot/{index}/{size}/_ckt",method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	@ResponseBody
    public String hot(HttpServletRequest request,@PathVariable String index,@PathVariable String size) throws Exception{
		return weiboService.hot(request, index, size);
	}
}
