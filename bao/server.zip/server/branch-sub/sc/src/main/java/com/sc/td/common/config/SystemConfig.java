package com.sc.td.common.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;

@Configuration
@PropertySource({ "classpath:/cfg.properties" })
public class SystemConfig {


	@Value("${protocol}")
	public String protocol;
	
	@Value("${protocolSSL}")
	public String protocolSSL;
	
	@Value("${nginx_path}")
	public String nginx_path;
	
	@Value("${nginx_project_folder}")
	public String nginx_project_folder;

	@Value("${nginx_user_folder}")
	public String nginx_user_folder;

	@Value("${redis_ip}")
	public String redis_ip;

	@Value("${redis_ipforupdate}")
	public String redis_ipforupdate;

	@Value("${redis_port}")
	public String redis_port;

	@Value("${redis_passwd}")
	public String redis_passwd;

	@Value("${redis_database_index}")
	public String redis_database_index;

	@Value("${userfiles_img_url}")
	public String userfiles_img_url;

	@Value("${userfiles_group_url}")
	public String userfiles_group_url;

	@Value("${userfiles_groupexample_url}")
	public String userfiles_groupexample_url;
	
	@Value("${userfiles_tribe_url}")
	public String userfiles_tribe_url;

	@Value("${userfiles_tribeexample_url}")
	public String userfiles_tribeexample_url;

	@Value("${userfiles_weibo_url}")
	public String userfiles_weibo_url;
	
	// TODO


	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	public String getProtocol() {
		return protocol;
	}

	public String getProtocolSSL() {
		return protocolSSL;
	}

	public String getNginx_path() {
		return nginx_path;
	}

	public String getNginx_project_folder() {
		return nginx_project_folder;
	}

	public String getNginx_user_folder() {
		return nginx_user_folder;
	}

	public String getRedis_ip() {
		return redis_ip;
	}

	public String getRedis_ipforupdate() {
		return redis_ipforupdate;
	}

	public String getRedis_port() {
		return redis_port;
	}

	public String getRedis_passwd() {
		return redis_passwd;
	}

	public String getRedis_database_index() {
		return redis_database_index;
	}

	public String getUserfiles_img_url() {
		return userfiles_img_url;
	}

	public String getUserfiles_group_url() {
		return userfiles_group_url;
	}

	public String getUserfiles_groupexample_url() {
		return userfiles_groupexample_url;
	}

	public String getUserfiles_tribe_url() {
		return userfiles_tribe_url;
	}

	public String getUserfiles_tribeexample_url() {
		return userfiles_tribeexample_url;
	}

	public String getUserfiles_weibo_url() {
		return userfiles_weibo_url;
	}

	
}
