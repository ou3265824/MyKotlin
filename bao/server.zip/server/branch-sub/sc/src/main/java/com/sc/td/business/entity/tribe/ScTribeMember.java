package com.sc.td.business.entity.tribe;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import com.sc.td.common.config.DictEnum;
import com.sc.td.common.persistence.BaseEntity;

@Table
@Entity
@IdClass(TribeMemberPk.class)
public class ScTribeMember extends BaseEntity{

	private int tribeId;					//部落Id	
	private int userId;					//用户Id	
	private String weiboLimit;			//是否限制发布微博（T/F）
	private String weiboCommentLimit;	//是否限制微博评论（T/F）
	private String delFlag;				//删除标记（0正常1删除）
	
	@Id
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	@Id
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getWeiboLimit() {
		return weiboLimit;
	}
	public void setWeiboLimit(String weiboLimit) {
		this.weiboLimit = weiboLimit;
	}
	public String getWeiboCommentLimit() {
		return weiboCommentLimit;
	}
	public void setWeiboCommentLimit(String weiboCommentLimit) {
		this.weiboCommentLimit = weiboCommentLimit;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	
	@Override
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setWeiboLimit(DictEnum.negative.value);
		this.setWeiboCommentLimit(DictEnum.negative.value);
		this.setDelFlag(DictEnum.not_del.value);
	}
}
