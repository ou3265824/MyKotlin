package com.sc.td.business.service.user;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sc.td.business.dao.user.ScAccountDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.user.ScAccount;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.utils.MD5Utils;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.json.CreateJson;

@Service
public class ScAccountService {

	@Autowired
	private ScAccountDao accountDao;

	@Autowired
	private ScUserDao userDao;

	/**
	 * 设置密码
	 * @param userId
	 * @param pwd
	 * @return
	 */
	public String setPwd(Integer userId, String pwd) {
		if (StringUtils.isBlank(pwd)) {
			return CreateJson.createObjJson(ReturnMsgEnum.pwdNull.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		ScAccount account = accountDao.findByUserId(userId);
		if (account == null) {
			ScAccount scAccount = newScAccount(userId, pwd);
			scAccount.setPassword(MD5Utils.md5(MD5Utils.salt(pwd, scAccount.getCreateDate())));
			scAccount.setUpdateDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
			accountDao.save(scAccount);
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	public String resetPwd(Integer userId, String oldPwd,String newPwd){
		if(StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)){
			return CreateJson.createObjJson(ReturnMsgEnum.pwdNull.getMessage(), false);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	
	public ScAccount newScAccount(Integer userId, String pwd) {
		ScAccount account = new ScAccount();
		account.setUserId(userId);
		account.setCreateDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
		account.setErrorCount(0);
		account.setLockFlag(DictEnum.notLock.value);
		return account;
	}
}
