package com.sc.td.business.controller.sms;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sc.td.business.service.sms.SmsService;

@Controller
@RequestMapping("/sms")
public class SmsController {

	@Autowired
	private SmsService smsService;
	
	@RequestMapping(value="",method = {RequestMethod.GET,RequestMethod.POST},produces = "application/json; charset=utf-8")
	@ResponseBody
    public String sendsms(String jsonText,HttpServletRequest request) throws Exception{
		return smsService.sendsms(jsonText, request);
	}
}
