package com.sc.td.business.entity.tribe;

import java.io.Serializable;

@SuppressWarnings("serial")
public class TribeUserRolePk implements Serializable{

	private int tribeId;
	private int userId;
	private int roleId;
	public TribeUserRolePk() {
	}
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + roleId;
		result = prime * result + tribeId;
		result = prime * result + userId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TribeUserRolePk other = (TribeUserRolePk) obj;
		if (roleId != other.roleId)
			return false;
		if (tribeId != other.tribeId)
			return false;
		if (userId != other.userId)
			return false;
		return true;
	}
}
