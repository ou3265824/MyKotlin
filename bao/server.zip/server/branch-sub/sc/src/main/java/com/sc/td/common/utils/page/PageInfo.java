package com.sc.td.common.utils.page;

import com.sc.td.common.utils.StringUtils;

public class PageInfo {

	public static final int index = 0;// 索引

	public static final int pageno = 1;// 页码

	public static final int size = 20;// 每页数量

	private int _index;
	private int _pageno;
	private int _size;
	
	public PageInfo(int _index, int _pageno, int _size) {
		super();
		this._index = _index;
		this._pageno = _pageno;
		this._size = _size;
	}

	public int get_index() {
		return _index;
	}

	public void set_index(int _index) {
		this._index = _index;
	}

	public int get_pageno() {
		return _pageno;
	}

	public void set_pageno(int _pageno) {
		this._pageno = _pageno;
	}

	public int get_size() {
		return _size;
	}

	public void set_size(int _size) {
		this._size = _size;
	}

	/**
	 * 获取页码
	 * 
	 * @param strindex
	 * @return
	 */
	public static int getPageNo(String strpageno) {
		try {
			if (StringUtils.isNotBlank(strpageno) && Integer.parseInt(strpageno)>=1) {
				return Integer.parseInt(strpageno);
			}else{
				return pageno;
			}
		} catch (Exception e) {
			return pageno;
		}
	}

	/**
	 * 获取每页数量
	 * 
	 * @param strindex
	 * @return
	 */
	public static int getSize(String strsize) {
		try {
			if (StringUtils.isNotBlank(strsize) && Integer.parseInt(strsize)>=1) {
				return Integer.parseInt(strsize);
			}else{
				return size;
			}
		} catch (Exception e) {
			return size;
		}
	}

	/**
	 * 获取索引
	 * 
	 * @param _pageno
	 * @param _size
	 * @return
	 */
	public static int getIndex(int _pageno, int _size) {
		int _index = 0;
		try {
			_index = (_pageno - 1) * _size;
		} catch (Exception e) {
			return index;
		}
		return _index;
	}
	
	
}
