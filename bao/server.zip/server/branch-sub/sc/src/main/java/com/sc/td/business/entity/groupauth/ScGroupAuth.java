package com.sc.td.business.entity.groupauth;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import com.sc.td.common.persistence.BaseEntity;

@Entity
public class ScGroupAuth extends BaseEntity{

	private int id;
	private String name;
	private String permission;
	private String isAble;
	private String remarks;
	
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPermission() {
		return permission;
	}
	public void setPermission(String permission) {
		this.permission = permission;
	}
	public String getIsAble() {
		return isAble;
	}
	public void setIsAble(String isAble) {
		this.isAble = isAble;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "ScGroupAuth [id=" + id + ", name=" + name + ", permission=" + permission + ", isAble=" + isAble
				+ ", remarks=" + remarks + "]";
	}
}
