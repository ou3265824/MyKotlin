package com.sc.td.business.dao.group;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.group.ScGroupApply;

public interface ScGroupApplyDao extends BaseDao<ScGroupApply>,SpecificationDao<ScGroupApply> {

	ScGroupApply findByGroupIdAndUserIdAndDelFlag(int groupId,int userId,String delFlag);
	
	long countByAuditByAndDelFlagAndReadFlag(int auditBy,String delFlag,String readFlag);
	
	List<ScGroupApply> findByAuditByAndDelFlagAndReadFlag(int auditBy,String delFlag,String readFlag);
}
