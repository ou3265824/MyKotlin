package com.sc.td.business.entity.tribe;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

@Table
@Entity
@IdClass(TribeUserRolePk.class)
public class ScTribeUserRole {

	private int tribeId;	//部落Id
	private int userId;		//用户Id
	private int roleId;		//角色Id
	
	@Id
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	@Id
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	@Id
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	
	
}
