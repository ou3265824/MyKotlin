package com.sc.td.business.entity.release;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.sc.td.common.config.DictEnum;
import com.sc.td.common.persistence.BaseEntity;
import com.sc.td.common.utils.calc.ArithDecimal;

@Table
@Entity
public class ScRelease extends BaseEntity implements Serializable,Comparable<ScRelease>{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int releaseId;
	private String releaseName;
	private String intro;
	private Integer groupId;
	private Integer userId;
	private String status;
	private BigDecimal collectMoney;
	private BigDecimal profit;
	private Float profitRate;
	private String groupImage;
	private String groupName;
	private String userName;
	private String userImage;
	private List<ScReleaseDetails> details;
	private String startDate;
	private String endDate;
	private boolean isRel;//该策略是否与当前用户有关（验证或发布）
	private String delFlag;
	private String hisProfitRate;
	private boolean isBet;
	private String inCondition;
	private String outCondition;
	private String collectCloseDate;
	private Integer producer;
	private String producerName;
	private String producerImage;
	
	@Transient
	public String getProducerImage() {
		return producerImage;
	}
	public void setProducerImage(String producerImage) {
		this.producerImage = producerImage;
	}
	@Transient
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public Integer getProducer() {
		return producer;
	}
	public void setProducer(Integer producer) {
		this.producer = producer;
	}
	public String getCollectCloseDate() {
		return collectCloseDate;
	}
	public void setCollectCloseDate(String collectCloseDate) {
		this.collectCloseDate = collectCloseDate;
	}
	public String getInCondition() {
		return inCondition;
	}
	public void setInCondition(String inCondition) {
		this.inCondition = inCondition;
	}
	public String getOutCondition() {
		return outCondition;
	}
	public void setOutCondition(String outCondition) {
		this.outCondition = outCondition;
	}
	@Transient
	public boolean isBet() {
		return isBet;
	}
	public void setBet(boolean isBet) {
		this.isBet = isBet;
	}
	public String getHisProfitRate() {
		return hisProfitRate;
	}
	public void setHisProfitRate(String hisProfitRate) {
		this.hisProfitRate = hisProfitRate;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	@Transient
	public boolean isRel() {
		return isRel;
	}
	public void setRel(boolean isRel) {
		this.isRel = isRel;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	@OneToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY, mappedBy = "releaseId")
	public List<ScReleaseDetails> getDetails() {
		return details;
	}
	public void setDetails(List<ScReleaseDetails> details) {
		this.details = details;
	}
	@Transient
	public String getGroupImage() {
		return groupImage;
	}
	public void setGroupImage(String groupImage) {
		this.groupImage = groupImage;
	}
	@Transient
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	@Transient
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Transient
	public String getUserImage() {
		return userImage;
	}
	public void setUserImage(String userImage) {
		this.userImage = userImage;
	}
	public Float getProfitRate() {
		return Float.parseFloat(ArithDecimal.roundByScale(profitRate, 4));
	}
	public void setProfitRate(Float profitRate) {
		this.profitRate = profitRate;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}
	public String getReleaseName() {
		return releaseName;
	}
	public void setReleaseName(String releaseName) {
		this.releaseName = releaseName;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public BigDecimal getCollectMoney() {
		return collectMoney;
	}
	public void setCollectMoney(BigDecimal collectMoney) {
		this.collectMoney = collectMoney;
	}
	public BigDecimal getProfit() {
		return profit;
	}
	public void setProfit(BigDecimal profit) {
		this.profit = profit;
	}
	
	@Override
	public String toString() {
		return "ScRelease [releaseId=" + releaseId + ", releaseName=" + releaseName + ", intro=" + intro + ", groupId="
				+ groupId + ", userId=" + userId + ", status=" + status + ", collectMoney=" + collectMoney + ", profit="
				+ profit + ", profitRate=" + profitRate + ", groupImage=" + groupImage + ", groupName=" + groupName
				+ ", userName=" + userName + ", userImage=" + userImage + ", details=" + details + ", startDate="
				+ startDate + ", endDate=" + endDate + ", isRel=" + isRel + ", delFlag=" + delFlag + ", hisProfitRate="
				+ hisProfitRate + ", isBet=" + isBet + ", inCondition=" + inCondition + ", outCondition=" + outCondition
				+ ", collectCloseDate=" + collectCloseDate + "]";
	}
	@Override
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setStatus(DictEnum.moren.value);
		this.setCollectMoney(new BigDecimal(0.00));
		this.setProfit(new BigDecimal(0.00));
		this.setProfitRate(0.00f);
		this.setDelFlag(DictEnum.not_del.value);
	}
	@Override
	public int compareTo(ScRelease o) {
		if(this.toString().equals(o.toString())){
			return 0;
		}
		if(this.getStatus().equals(DictEnum.end.value) && !o.getStatus().equals(DictEnum.end.value)){
			return 1;
		}else if(!this.getStatus().equals(DictEnum.end.value) && o.getStatus().equals(DictEnum.end.value)){
			return -1;
		}else{
			if(o.getStatus().compareTo(this.getStatus())>0){
				return 1;
			}else if(o.getStatus().compareTo(this.getStatus())<0){
				return -1;
			}
			if(this.getProfitRate()>o.getProfitRate()){
				return -1;
			}else if(this.getProfitRate()<o.getProfitRate()){
				return 1;
			}
		}
		return 1;
	}
}
