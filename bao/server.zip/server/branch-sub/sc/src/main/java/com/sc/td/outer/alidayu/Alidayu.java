package com.sc.td.outer.alidayu;

import java.util.HashMap;
import java.util.Map;

import com.sc.td.common.utils.json.JacksonUtil;
import com.taobao.api.ApiException;
import com.taobao.api.DefaultTaobaoClient;
import com.taobao.api.TaobaoClient;
import com.taobao.api.request.AlibabaAliqinFcSmsNumSendRequest;
import com.taobao.api.response.AlibabaAliqinFcSmsNumSendResponse;

public class Alidayu {

	/**
	 * 发送验证码短信
	 * @return
	 * @throws ApiException 
	 */
	public static String sendSms_validateCode(String params,String num,EnumSignName signName,EnumTemplate templateCode) throws ApiException{
		TaobaoClient client = new DefaultTaobaoClient(AlidayuConfig.url, AlidayuConfig.appkey, AlidayuConfig.secret);
		AlibabaAliqinFcSmsNumSendRequest req = new AlibabaAliqinFcSmsNumSendRequest();
		req.setExtend("");
		req.setSmsType(AlidayuConfig.smsType);
		req.setSmsFreeSignName(signName.getName());
		req.setSmsParamString(params);
		req.setRecNum(num);
		req.setSmsTemplateCode(templateCode.getName());
		AlibabaAliqinFcSmsNumSendResponse rsp = client.execute(req);
		return rsp.getBody();
	}
	
	/**
	 * 设置短信参数
	 * @return
	 */
	public static String setParams(String code,String product){		
		Map<String,String> map=new HashMap<String,String>();
		map.put("code", code);
//		map.put("product", product);
		return JacksonUtil.objToJson(map);
	}
	
}
