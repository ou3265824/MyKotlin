package com.sc.td.business.service.tribe;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Path;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.joda.time.DateTime;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.tribe.ScTribeAuthDao;
import com.sc.td.business.dao.tribe.ScTribeDao;
import com.sc.td.business.dao.tribe.ScTribeMemberDao;
import com.sc.td.business.dao.tribe.ScTribeRoleDao;
import com.sc.td.business.dao.tribe.ScTribeUserRoleDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.tribe.ScTribe;
import com.sc.td.business.entity.tribe.ScTribeAuth;
import com.sc.td.business.entity.tribe.ScTribeMember;
import com.sc.td.business.entity.tribe.ScTribeRole;
import com.sc.td.business.entity.tribe.ScTribeUserRole;
import com.sc.td.business.entity.tribe.dto.TribeUserDto;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.Global;
import com.sc.td.common.config.MsgEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.config.SystemConfig;
import com.sc.td.common.utils.FileUtils;
import com.sc.td.common.utils.RandomCode;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.image.ImgBase64;
import com.sc.td.common.utils.image.ImgCreate;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.page.PageInfo;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.easemob.exception.EasemobException;

@Service
public class ScTribeService extends BaseService{

	@Autowired
	private ScTribeDao tribeDao;
	
	@Autowired
	private ScUserDao userDao;
	
	@Autowired
	private RedisService redisService;
	
	@Autowired
	private ScTribeMemberDao tribeMemberDao;
	
	@Autowired
	private ScTribeRoleDao tribeRoleDao;
	
	@Autowired
	private ScTribeUserRoleDao tribeUserRoleDao;
	
	@Autowired
	private ScTribeAuthDao tribeAuthDao;
	
	@Autowired
	private SystemConfig sysCfg;
	
	/**
	 * 创建部落
	 * @param json
	 * @return
	 * @throws IOException
	 */
	@Transactional
	public String create(HttpServletRequest request,String json) throws IOException{
		ScTribe tribe=JacksonUtil.jsonToObj(json, ScTribe.class);
		if(tribe!=null && StringUtils.isNotBlank(tribe.getTribeName())){
			ScUser user = userByToken(request);
			if(user==null){
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			if(StringUtils.isBlank(user.getTribeLimit()) || user.getTribeLimit().equals(DictEnum.positive.value)){
				return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
			}
			List<ScTribe> list=tribeDao.findByTribeName(tribe.getTribeName());
			if(list!=null && list.size()>0){
				return CreateJson.createTextJson(ReturnMsgEnum.tribeNameExist.getMessage(), false);
			}
			tribe.setUserId(user.getUserId());
			tribe.setInitValue(tribe, String.valueOf(tribe.getUserId()));
			if (tribeDao.save(tribe) != null) {
				// 生成部落头像,如果客户端没有传递img，则生成默认图片
				boolean b = true;
				if (StringUtils.isBlank(tribe.getImage())) {
					b = false;
				} else {
					String imageName = tribe.getImage();// 图片名
					// 判断该图片在示例图片中是否存在
					String srcPath = sysCfg.getUserfiles_tribeexample_url() + imageName + DictEnum.picFormat.value;
					File file = new File(srcPath);
					// 如果图片存在，则复制图片至部落头像的文件夹中，并更改图片名（以部落ID为图片名）
					if (file.exists()) {
						FileUtils.copyFileToDirectory(new File(srcPath), new File(sysCfg.getUserfiles_tribe_url()), true);
						File tribeImageFile = new File(sysCfg.getUserfiles_tribe_url() + imageName + DictEnum.picFormat.value);
						if (tribeImageFile.exists()) {
							tribeImageFile.renameTo(new File(sysCfg.getUserfiles_tribe_url() + tribe.getUserId() + "-"
									+ tribe.getTribeId() + DictEnum.picFormat.value));
						}
					} else {
						b = false;
					}
				}
				if (!b) {
					ImgCreate imgCreate = new ImgCreate();
					imgCreate.createImage(sysCfg.getUserfiles_tribe_url(), tribe.getTribeName(),
							String.valueOf(tribe.getTribeId()));
				}
				// 上传成功之后，将时间戳保存至redis中
				long time = System.currentTimeMillis();
				redisService.hset(DictEnum.redisTribeImageTimestampKey.value,
						tribe.getUserId() + "-" + tribe.getTribeId(), String.valueOf(time));
				tribe.setImage(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()));
				// 将该用户加入到群组用户对应表
				ScTribeMember member = new ScTribeMember();
				member.setTribeId(tribe.getTribeId());
				member.setUserId(tribe.getUserId());
				member.setInitValue(member, String.valueOf(member.getUserId()));
				if (tribeMemberDao.save(member) != null) {
					// 部落创建成功之后，将部落创建者设置为超级管理员
					List<ScTribeRole> roleList = tribeRoleDao.findByType(DictEnum.admin.value);
					if (roleList != null && roleList.size() > 0) {
						ScTribeRole role = roleList.get(0);
						ScTribeUserRole sc = new ScTribeUserRole();
						sc.setTribeId(tribe.getTribeId());
						sc.setRoleId(role.getId());
						sc.setUserId(member.getUserId());
						tribeUserRoleDao.save(sc);
					}
					tribe.setUserName(getUserName(user));
					tribe.setUserImg(getUserImagePath(user.getMobile()));
					tribe.setJoin(true);
					return CreateJson.createObjJson(tribe, true);
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 上传头像
	 * 
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 */
	@Transactional
	public String uploadImg(String jsonText, HttpServletRequest request) throws UnknownHostException {
		// 解析json数据
		@SuppressWarnings({ "unchecked", "rawtypes" })
		HashMap<String, String> dataMap = (HashMap) JacksonUtil.jsonToObj(jsonText, Object.class);
		// 得到img的字符串数据
		String imgStr = dataMap.get("img");
		// 部落ID
		String tribeId = dataMap.get("tribeId");
		// 手机号
		String mobile = dataMap.get("mobile");
		if (StringUtils.isBlank(imgStr) || StringUtils.isBlank(tribeId) || StringUtils.isBlank(mobile)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		// 检查该手机号用户是否存在
		ScUser scUser = userDao.findByMobile(mobile);
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(Integer.parseInt(tribeId), DictEnum.not_del.value);
		String fileName = tribe.getUserId() + "-" + tribe.getTribeId() + DictEnum.picFormat.value;
		if (scUser != null && tribe != null) {
			// 判断该用户是否有此权限
			if (scUser.getUserId() != tribe.getUserId()) {
				return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
			}
			// 上传头像
			boolean b = ImgBase64.GenerateImage(imgStr, sysCfg.getUserfiles_tribe_url(), fileName);
			if (b) {
				// 上传成功之后，修改redis内的时间戳
				long time = System.currentTimeMillis();
				redisService.hset(DictEnum.redisTribeImageTimestampKey.value,
						tribe.getUserId() + "-" + tribe.getTribeId(), String.valueOf(time));
				tribe.setImage(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()));
				return CreateJson.createObjJson(tribe, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 修改部落信息
	 * 
	 * @param jsonText
	 * @return
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 * @throws EasemobException
	 */
	@Transactional
	public String modify(String jsonText)
			throws IllegalAccessException, IllegalArgumentException, InvocationTargetException{
		@SuppressWarnings("unchecked")
		HashMap<String, String> map = JacksonUtil.jsonToObj(jsonText, HashMap.class);
		String userId = map.get("userId");// 当前操作用户的ID
		String tribeId = map.get("tribeId");
		String column = map.get("column");
		String value = map.get("value");
		if (StringUtils.isNotBlank(userId) && StringUtils.isNotBlank(tribeId) && StringUtils.isNotBlank(column)
				&& StringUtils.isNotBlank(value)) {
			ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(Integer.parseInt(tribeId), DictEnum.not_del.value);
			if (tribe == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
			}
			if (Integer.parseInt(userId) != tribe.getUserId()) {
				return CreateJson.createTextJson(ReturnMsgEnum.nopermission.getMessage(), false);
			}
			if (column.equals("tribeName")) {
				String tribeName_old = tribe.getTribeName();
				if (StringUtils.isBlank(tribeName_old)
						|| (StringUtils.isNotBlank(tribeName_old) && !tribeName_old.equals(value))) {
					// 判断部落名是否重复
					List<ScTribe> findBytribeName = tribeDao.findByTribeName(value);
					if (findBytribeName != null && findBytribeName.size() > 0) {
						return CreateJson.createTextJson(ReturnMsgEnum.tribeNameExist.getMessage(), false);
					}
				}
			}
			String key = "set" + toUpperKey(column);
			Method[] methods = tribe.getClass().getMethods();
			for (Method method : methods) {
				if (key.equals(method.getName())) {
					method.invoke(tribe, value);
					break;
				}
			}
			if (tribeDao.save(tribe) != null) {
				tribe.setImage(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()));
				return CreateJson.createObjJson(tribe, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	public ScTribe tribe(String tribeId, Integer currentUserId) {
		if (StringUtils.isNotBlank(tribeId)) {
			int gid = Integer.parseInt(tribeId);
			ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(gid, DictEnum.not_del.value);
			if (tribe != null) {
				tribe.setImage(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()));
				ScUser user = userDao.findByUserId(tribe.getUserId());
				if (user == null) {
					return null;
				}
				tribe.setUserName(getUserName(user));
				tribe.setUserImg(getUserImagePath(user.getMobile()));
				tribe.setPeopleCount(
						tribeMemberDao.countByTribeIdAndDelFlag(tribe.getTribeId(), DictEnum.not_del.value));
				ScTribeMember member = tribeMemberDao.findByTribeIdAndUserIdAndDelFlag(tribe.getTribeId(), currentUserId, DictEnum.not_del.value);
				if(member!=null){
					tribe.setJoin(true);
				}
				return tribe;
			}
		}
		return null;
	}

	/**
	 * 根据部落ID获取部落信息
	 * 
	 * @param tribeId
	 * @return
	 */
	public String tribeById(HttpServletRequest request,String tribeId) {
		ScUser currentUser = userByToken(request);
		ScTribe tribe = tribe(tribeId, currentUser.getUserId());
		if (tribe != null) {
			return CreateJson.createObjJson(tribe, true);
		} else {
			return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
		}
	}
	
	/**
	 * 生成邀请码
	 * 
	 * @param tribeId
	 * @return
	 */
	public String generateCode(Integer tribeId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		String oldCode=redisService.get(DictEnum.redisJoinTribeIdPrefix.value + String.valueOf(tribeId));
		if(StringUtils.isNotBlank(oldCode)){
			redisService.del(DictEnum.redisJoinTribeCodePrefix.value + oldCode);
		}
		String code = null;
		try {
			while (true) {
				code = RandomCode.getCode(4);
				if (StringUtils.isBlank(redisService.get(DictEnum.redisJoinTribeCodePrefix.value + code))) {
					break;
				}
			}
			if (StringUtils.isNotBlank(code)) {
				redisService.set(DictEnum.redisJoinTribeCodePrefix.value + code, String.valueOf(tribeId),Global.tribecode_time);
				redisService.set(DictEnum.redisJoinTribeIdPrefix.value + String.valueOf(tribeId), code,Global.tribecode_time);
				return CreateJson.createObjJson(code, true);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 获取邀请码
	 * @param tribeId
	 * @return
	 */
	public String obtainCode(Integer tribeId) {
		String code = redisService.get(DictEnum.redisJoinTribeIdPrefix.value + String.valueOf(tribeId));
		if(StringUtils.isNotBlank(code)){
			return CreateJson.createObjJson(code, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 根据邀请码加入部落
	 * @param userId
	 * @param code
	 * @return
	 */
	public String joinByCode(Integer userId, String code){
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		String tribeId = redisService.get(DictEnum.redisJoinTribeCodePrefix.value + code);
		if (StringUtils.isBlank(tribeId)) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		ScTribeMember member = tribeMemberDao.findByTribeIdAndUserIdAndDelFlag(Integer.parseInt(tribeId), userId, DictEnum.not_del.value);
		if(member!=null){
			return CreateJson.createTextJson(ReturnMsgEnum.alreadyInTribe.getMessage(), false);
		}
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(Integer.parseInt(tribeId), DictEnum.not_del.value);
		if(tribe==null){
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}else{
			ScTribeMember sc=addMember(Integer.parseInt(tribeId), userId);
			if(tribeMemberDao.save(sc)!=null){
				// 创建消息
				String content = setSysContent(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()),
						tribe.getTribeName(), "用户" + getUserName(user) + "加入部落" + tribe.getTribeName(),
						TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
				createNotify(String.valueOf(tribe.getUserId()), MsgEnum.sys.value, MsgEnum.tribe_check.desc, content);
				return CreateJson.createObjJson(tribe, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 部落加入新成员
	 * @param tid
	 * @param uid
	 * @return
	 */
	public ScTribeMember addMember(int tid,int uid){
		ScTribeMember member = new ScTribeMember();
		member.setTribeId(tid);
		member.setUserId(uid);
		member.setInitValue(member, String.valueOf(uid));
		return member;
	}
	
	/**
	 * 退出部落 
	 * @param tribeId
	 * @param userId
	 * @return
	 * @throws EasemobException
	 */
	@Transactional
	public String quit(String tribeId, String userId){
		if (StringUtils.isNotBlank(tribeId) && StringUtils.isNotBlank(userId)) {
			int tid = Integer.parseInt(tribeId);
			int uid = Integer.parseInt(userId);
			ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tid, DictEnum.not_del.value);
			if (tribe == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
			}
			ScUser user = userDao.findByUserId(uid);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			// 判断用户是否为该部落拥有者
			Long count = tribeDao.countByUserIdAndTribeIdAndDelFlag(uid, tid, DictEnum.not_del.value);
			if (count > 0) {
				return CreateJson.createObjJson(ReturnMsgEnum.refuseQuit.getMessage(), false);
			}
			// 3、删除部落内与用户相关的数据
			// a、部落成员表
			ScTribeMember member = tribeMemberDao.findByTribeIdAndUserIdAndDelFlag(tid, uid, DictEnum.not_del.value);
			if (member != null) {       
				member.setDelFlag(DictEnum.del.value);
				member.setUpdateValue(member, String.valueOf(uid));
				tribeMemberDao.save(member);
			}
			return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), true);
	}
	
	/**
	 * 部落成员
	 * @param tid
	 * @param index
	 * @param size
	 * @return
	 */
	public String tribeMember(Integer tid,String index,String size){
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tid, DictEnum.not_del.value);
		if(tribe==null){
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		PageInfo pageInfo = getPageIndexAndSize(index, size);
		List<ScTribeMember> list = findByTidAndDelFlag(tid, DictEnum.not_del.value, pageInfo.get_pageno(), pageInfo.get_size());
		TreeSet<TribeUserDto> set=Sets.newTreeSet();
		if (list != null && list.size() > 0) {
			for (ScTribeMember member : list) {
				ScUser user = userDao.findByUserId(member.getUserId());
				if (user != null) {
					TribeUserDto dto=new TribeUserDto();
					dto.setUserId(user.getUserId());
					dto.setUserName(getUserName(user));
					dto.setImage(getUserImagePath(user.getMobile()));
					dto.setJoinTime(member.getCreateDate());
					//是否管理员
					Long countAdmin = tribeUserRoleDao.countByTribeIdAndUserIdAndType(tid, user.getUserId(), DictEnum.admin.value);
					Long countManager = tribeUserRoleDao.countByTribeIdAndUserIdAndType(tid, user.getUserId(), DictEnum.manager.value);
					if(countAdmin>0){
						dto.setAdmin(true);
					}
					if(countManager>0){
						dto.setManager(true);
					}
					set.add(dto);
				}
			}
		}
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * "我"加入的部落
	 * @param userId
	 * @return
	 * @throws NumberFormatException
	 */
	public String my(String userId) throws NumberFormatException {
		if (StringUtils.isNotBlank(userId)) {
			int id = Integer.parseInt(userId);
			ScUser user = userDao.findByUserId(id);
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			List<ScTribeMember> list = tribeMemberDao.findByUserIdAndDelFlagOrderByUpdateDateDesc(id, DictEnum.not_del.value);
			List<ScTribe> dataList = Lists.newArrayList();
			if (list != null) {
				for (ScTribeMember sc : list) {
					ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(sc.getTribeId(), DictEnum.not_del.value);
					if (tribe != null) {
						ScUser tribeUser = userDao.findByUserId(tribe.getUserId());
						if (tribeUser != null) {
							tribe.setUserName(getUserName(tribeUser));
							tribe.setUserImg(getUserImagePath(tribeUser.getMobile()));
						}
						tribe.setImage(getTribeImagePath(tribe.getUserId() + "-" + tribe.getTribeId()));
						tribe.setPeopleCount(
								tribeMemberDao.countByTribeIdAndDelFlag(tribe.getTribeId(), DictEnum.not_del.value));
						dataList.add(tribe);
					}
				}
			}
			if (dataList != null && dataList.size() > 0) {
				return CreateJson.createObjJson(dataList, true);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	
	/**
	 * 获取部落内的所有管理员
	 * 
	 * @param tribeId
	 * @return
	 */
	public String getAllManager(Integer tribeId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		List<ScTribeMember> list = tribeMemberDao.findByTribeIdAndRoleType(tribeId, DictEnum.manager.value);
		Set<ScUser> set = Sets.newHashSet();
		if (list != null && list.size() > 0) {
			for (ScTribeMember member : list) {
				ScUser user = userDao.findByUserId(member.getUserId());
				if (user != null) {
					user.setImage(getUserImagePath(user.getMobile()));
					user.setUserName(getUserName(user));
					set.add(user);
				}
			}
		}
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	
	/**
	 * 获取部落内的所有非管理员
	 * 
	 * @param tribeId
	 * @return
	 */
	public String getAllNotManager(Integer tribeId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		List<ScTribeMember> list = tribeMemberDao.findByTribeIdAndRoleType(tribeId, DictEnum.manager.value,
				DictEnum.admin.value);
		Set<ScUser> set = Sets.newHashSet();
		if (list != null && list.size() > 0) {
			for (ScTribeMember member : list) {
				ScUser user = userDao.findByUserId(member.getUserId());
				if (user != null) {
					user.setImage(getUserImagePath(user.getMobile()));
					user.setUserName(getUserName(user));
					set.add(user);
				}
			}
		}
		if (set != null && set.size() > 0) {
			return CreateJson.createObjJson(set, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	
	/**
	 * 获取用户在部落内的权限
	 * 
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	public String getAllUserAuth(Integer tribeId, Integer userId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		List<ScTribeAuth> list = tribeAuthDao.findByTribeIdAndUserIdAndIsAble(DictEnum.enable.value, tribeId, userId);
		if (list != null && list.size() > 0) {
			return CreateJson.createObjJson(list, true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.nondata.getMessage(), false);
	}
	
	/**
	 * 分配管理员权限
	 * 
	 * @param tribeId
	 * @param userIds
	 * @return
	 */
	public String allotManager(Integer tribeId, Integer userId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}

		List<ScTribeRole> list = tribeRoleDao.findByType(DictEnum.manager.value);
		if (list != null && list.size() > 0) {
			ScTribeRole role = list.get(0);
			List<ScTribeUserRole> userRole = tribeUserRoleDao.findByTribeIdAndUserIdAndType(tribeId, userId,
					DictEnum.manager.value);
			if (userRole != null && userRole.size() > 0) {
				return CreateJson.createObjJson(ReturnMsgEnum.isManager.getMessage(), false);
			}
			ScTribeUserRole sc = new ScTribeUserRole();
			sc.setTribeId(tribeId);
			sc.setRoleId(role.getId());
			sc.setUserId(userId);
			tribeUserRoleDao.save(sc);
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
	
	/**
	 * 移除管理员
	 * 
	 * @param tribeId
	 * @param userId
	 * @return
	 */
	public String removeManager(Integer tribeId, Integer userId) {
		ScTribe tribe = tribeDao.findByTribeIdAndDelFlag(tribeId, DictEnum.not_del.value);
		if (tribe == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.tribeNotExist.getMessage(), false);
		}
		ScUser user = userDao.findByUserId(userId);
		if (user == null) {
			return CreateJson.createObjJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		List<ScTribeUserRole> userRole = tribeUserRoleDao.findByTribeIdAndUserIdAndType(tribeId, userId,
				DictEnum.manager.value);
		if (userRole != null && userRole.size() > 0) {
			for (ScTribeUserRole sc : userRole) {
				tribeUserRoleDao.delete(sc);
			}
			return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}
////////////////////////////////////////////////////////JPA动态查询接口实现//////////////////////////////////////////////////////////////////
	
	public List<ScTribeMember> findByTidAndDelFlag(int tid,String delFlag,int pageno,int size){
		Specification<ScTribeMember> specification = new Specification<ScTribeMember>() {
			@Override
			public Predicate toPredicate(Root<ScTribeMember> root, CriteriaQuery<?> query, CriteriaBuilder cb) {
				Path<String> _tid = root.get("tribeId");
				Path<String> _delFlag = root.get("delFlag");
				List<Predicate> predicates = Lists.newArrayList();
				predicates.add(cb.equal(_tid, tid));
				predicates.add(cb.equal(_delFlag, delFlag));
				return cb.and(predicates.toArray(new Predicate[] {}));
			}

		};
		Sort sort = new Sort(Direction.ASC, "createDate");
		Pageable pageable = new PageRequest(pageno - 1, size, sort);
		return tribeMemberDao.findAll(specification, pageable).getContent();
	}
}
