package com.sc.td.business.service.user;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Maps;
import com.sc.td.business.base.BaseService;
import com.sc.td.business.dao.release.ScReleaseUserDao;
import com.sc.td.business.dao.user.ScUserDao;
import com.sc.td.business.entity.release.ScReleaseUser;
import com.sc.td.business.entity.user.ScUser;
import com.sc.td.common.config.DictEnum;
import com.sc.td.common.config.ReturnMsgEnum;
import com.sc.td.common.config.SystemConfig;
import com.sc.td.common.utils.BeanUtils;
import com.sc.td.common.utils.MD5Utils;
import com.sc.td.common.utils.StringUtils;
import com.sc.td.common.utils.datetime.TimeUtil;
import com.sc.td.common.utils.encrypt.Des3Encrypt;
import com.sc.td.common.utils.image.ImgBase64;
import com.sc.td.common.utils.image.ImgCreate;
import com.sc.td.common.utils.json.CreateJson;
import com.sc.td.common.utils.json.JacksonUtil;
import com.sc.td.common.utils.redis.RedisService;
import com.sc.td.easemob.api.UserApi;
import com.sc.td.easemob.model.User;

@Service
public class ScUserService extends BaseService {

	private static Logger log = org.slf4j.LoggerFactory.getLogger(ScUserService.class);

	@Autowired
	private ScUserDao scUserDao;

	@Autowired
	private RedisService redisService;

	@Autowired
	private UserApi userApi;

	@Autowired
	private ScReleaseUserDao releaseUserDao;

	@Autowired
	private SystemConfig sysCfg;
	
	///////////////////////////////////////// V1.1////////////////////////////////////////////////////////////

	/**
	 * 注册
	 * 
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public String register_v1_1(String jsonText) throws Exception {
		ScUser scUser = null;
		// 解析json数据，看是否正确返回ScUser对象
		scUser = JacksonUtil.jsonToObj(jsonText, ScUser.class);
		if (scUser == null || StringUtils.isBlank(scUser.getMobile()) || StringUtils.isBlank(scUser.getValidCode())
				|| StringUtils.isBlank(scUser.getValidCodeType()) || StringUtils.isBlank(scUser.getPassword())) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		} else {
//			if (!(scUser.getMobile().equals("18721000000") && scUser.getValidCode().equals("8888"))) {
//				// 判断验证码是否过期
//				String validCode = redisService.get(scUser.getValidCodeType() + "-validCode-" + scUser.getMobile());
//				if (StringUtils.isBlank(validCode)) {
//					return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
//				} else {
//					// 判断验证码是否正确
//					if (!validCode.equals(scUser.getValidCode())) {
//						return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
//					}
//				}
//			}
			ScUser user = scUserDao.findByMobile(scUser.getMobile());
			if (user != null) {
				return CreateJson.createTextJson(ReturnMsgEnum.mobileExist.getMessage(), false);
			} else {
				// 第一次使用
				scUser.setGender(DictEnum.secret.value);
				scUser.setAmount(new BigDecimal(0.00));
				scUser.setAbleAmount(new BigDecimal(0.00));
				scUser.setCostAmount(new BigDecimal(0.00));
				scUser.setFirstLogin(DictEnum.negative.value);
				String now = TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat);
				scUser.setCreateDate(now);
				scUser.setUpdateDate(now);
				scUser.setGroupLimit(DictEnum.positive.value);
				scUser.setTribeLimit(DictEnum.positive.value);
				scUser.setPassword(MD5Utils.md5(MD5Utils.salt(scUser.getPassword(), scUser.getCreateDate())));
				if (scUserDao.save(scUser) != null) {
					ScUser newUser = handlerScUser(scUser);
					return CreateJson.createObjJsonWithToken(createToken(newUser), newUser);
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 用户登录
	 * 
	 * @param jsonText
	 * @return
	 * @throws Exception
	 * @throws UnknownHostException
	 * @throws UnsupportedEncodingException
	 *
	 */
	@Transactional
	public String login_v1_1(String jsonText) throws Exception {
		ScUser scUser = null;
		// 解析json数据，看是否正确返回ScUser对象
		scUser = JacksonUtil.jsonToObj(jsonText, ScUser.class);
		if (scUser == null || StringUtils.isBlank(scUser.getMobile()) || StringUtils.isBlank(scUser.getPassword())) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		// 判断手机号是否存在
		ScUser userByMobile = scUserDao.findByMobile(scUser.getMobile());
		if (userByMobile == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
		ScUser user = scUserDao.findByMobileAndPassword(scUser.getMobile(),
				MD5Utils.md5(MD5Utils.salt(scUser.getPassword(), userByMobile.getCreateDate())));
		if (user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.notPass.getMessage(), false);
		} else {
			if (StringUtils.isNotBlank(user.getFirstLogin()) && user.getFirstLogin().equals(DictEnum.positive.value)) {
				user.setFirstLogin(DictEnum.negative.value);
				scUserDao.save(user);
			}
			user.setUserName(getUserName(user));
			user.setImage(getUserImagePath(user.getMobile()));
			// 获取环信的用户信息
			String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value,
					String.valueOf(user.getUserId()));
			if (StringUtils.isNotBlank(easeUserName)) {
				user.setEaseName(easeUserName);
				user.setEasePassword(Des3Encrypt.encode(scUser.getMobile()));
			} else {
				user = checkEaseUser(user);
			}
			return CreateJson.createObjJsonWithToken(createToken(user), user);
		}
	}

	/**
	 * 重置密码
	 * 
	 * @param jsonText
	 * @return
	 */
	public String resetPwd_v1_1(String jsonText) {
		@SuppressWarnings("unchecked")
		Map<String, String> map = JacksonUtil.jsonToObj(jsonText, Map.class);
		if (map != null && map.size() > 0) {
			String mobile = map.get("mobile");
			String oldPwd = map.get("oldPwd");
			String newPwd = map.get("newPwd");
			// 判断手机号是否存在
			ScUser sc = scUserDao.findByMobile(mobile);
			if (sc == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			ScUser user = scUserDao.findByMobileAndPassword(mobile,
					MD5Utils.md5(MD5Utils.salt(oldPwd, sc.getCreateDate())));
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.oldPwdError.getMessage(), false);
			} else {
				user.setPassword(MD5Utils.md5(MD5Utils.salt(newPwd, user.getCreateDate())));
				scUserDao.save(user);
				return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
			}
		}
		return CreateJson.createObjJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 忘记密码
	 * 
	 * @param jsonText
	 * @return
	 */
	public String fgtPwd_v1_1(String jsonText) {
		ScUser scUser = null;
		// 解析json数据，看是否正确返回ScUser对象
		scUser = JacksonUtil.jsonToObj(jsonText, ScUser.class);
		if (scUser == null || StringUtils.isBlank(scUser.getMobile()) || StringUtils.isBlank(scUser.getValidCode())
				|| StringUtils.isBlank(scUser.getValidCodeType()) || StringUtils.isBlank(scUser.getPassword())) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		// 判断手机号是否存在
		ScUser user = scUserDao.findByMobile(scUser.getMobile());
		if (user == null) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
		}
//		// 判断验证码是否过期
//		String validCode = redisService.get(scUser.getValidCodeType() + "-validCode-" + scUser.getMobile());
//		if (StringUtils.isBlank(validCode)) {
//			return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
//		} else {
//			// 判断验证码是否正确
//			if (!validCode.equals(scUser.getValidCode())) {
//				return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
//			}
//		}
		user.setPassword(MD5Utils.md5(MD5Utils.salt(scUser.getPassword(), user.getCreateDate())));
		user.setUpdateDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
		scUserDao.save(user);
		return CreateJson.createObjJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
	}

	////////////////////////////////////////////////////////////////////////////////////////////////////
	/**
	 * 绑定环信用户
	 * 
	 * @param easeUserName
	 * @param userId
	 * @return
	 */
	@Deprecated
	public String bindEaseUser(String userId, String easeUserName, String easePwd) {
		if (StringUtils.isBlank(easeUserName) || StringUtils.isBlank(userId) || StringUtils.isBlank(easePwd)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		User user = new User();
		user.setUname(easeUserName);
		user.setPassword(easePwd);
		redisService.hset(DictEnum.redisEaseAppUserKey.value, easeUserName, userId);
		redisService.hset(DictEnum.redisAppEaseUserKey.value, userId, JacksonUtil.objToJson(user));
		return CreateJson.createTextJson(ReturnMsgEnum.operateSuccess.getMessage(), true);
	}

	/**
	 * 用户登录/注册 用户第一次登录时即为注册
	 * 
	 * @param jsonText
	 * @return
	 * @throws Exception
	 * @throws UnknownHostException
	 * @throws UnsupportedEncodingException
	 *
	 */
	@Transactional
	public String login(String jsonText) throws Exception {
		ScUser scUser = null;
		// 解析json数据，看是否正确返回ScUser对象
		scUser = JacksonUtil.jsonToObj(jsonText, ScUser.class);
		if (scUser == null || StringUtils.isBlank(scUser.getMobile()) || StringUtils.isBlank(scUser.getValidCode())
				|| StringUtils.isBlank(scUser.getValidCodeType())) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		} else {
			if (!(scUser.getMobile().equals("18721000000") && scUser.getValidCode().equals("8888"))) {
				// 判断验证码是否过期
				String validCode = redisService.get(scUser.getValidCodeType() + "-validCode-" + scUser.getMobile());
				if (StringUtils.isBlank(validCode)) {
					return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
				} else {
					// 判断验证码是否正确
					if (!validCode.equals(scUser.getValidCode())) {
						return CreateJson.createTextJson(ReturnMsgEnum.validCodeError.getMessage(), false);
					}
				}
			}

			// 判断手机号是否存在（如果存在直接登录，不存在的话新建一个用户）
			ScUser user = scUserDao.findByMobile(scUser.getMobile());
			if (user != null) {
				if (StringUtils.isNotBlank(user.getFirstLogin())
						&& user.getFirstLogin().equals(DictEnum.positive.value)) {
					user.setFirstLogin(DictEnum.negative.value);
					scUserDao.save(user);
				}
				user.setUserName(getUserName(user));
				user.setImage(getUserImagePath(user.getMobile()));
				// 获取环信的用户信息
				String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value,
						String.valueOf(user.getUserId()));
				if (StringUtils.isNotBlank(easeUserName)) {
					user.setEaseName(easeUserName);
					user.setEasePassword(Des3Encrypt.encode(scUser.getMobile()));
				} else {
					user = checkEaseUser(user);
				}
				return CreateJson.createObjJsonWithToken(createToken(user), user);
			} else {
				// 第一次使用
				scUser.setGender(DictEnum.secret.value);
				scUser.setAmount(new BigDecimal(0.00));
				scUser.setAbleAmount(new BigDecimal(0.00));
				scUser.setFirstLogin(DictEnum.negative.value);
				String now = TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat);
				scUser.setCreateDate(now);
				scUser.setUpdateDate(now);
				scUser.setGroupLimit(DictEnum.positive.value);
				scUser.setTribeLimit(DictEnum.positive.value);
				if (scUserDao.save(scUser) != null) {
					ScUser newUser = handlerScUser(scUser);
					return CreateJson.createObjJsonWithToken(createToken(newUser), newUser);
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 获取用户资产情况
	 * 
	 * @param userId
	 * @return
	 */
	public String getUserAsset(String userId) {
		if (StringUtils.isNotBlank(userId)) {
			ScUser user = scUserDao.findByUserId(Integer.parseInt(userId));
			if (user == null) {
				return CreateJson.createTextJson(ReturnMsgEnum.userNotExist.getMessage(), false);
			}
			// 1、已投资金。获取所有投注且正在进行中的策略的总投注
			BigDecimal betAmount = new BigDecimal(0.00);
			// 2、冻结资金。获取所有已投注但未开始的策略总投注
			BigDecimal frozenAmount = new BigDecimal(0.00);
			// 3、浮动盈亏。获取所有正在进行中的策略的总收益
			BigDecimal totalProfit = new BigDecimal(0.00);
			List<ScReleaseUser> list = releaseUserDao.findByUserIdAndDelFlagAndStatusNot(Integer.parseInt(userId),
					DictEnum.not_del.value, DictEnum.end.value);
			if (list != null && list.size() > 0) {
				for (ScReleaseUser releaseUser : list) {
					if (releaseUser.getStatus().equals(DictEnum.ing.value)) {
						betAmount = betAmount.add(releaseUser.getAmount());
						totalProfit = totalProfit.add(releaseUser.getProfit());
					} else if (releaseUser.getStatus().equals(DictEnum.moren.value)) {
						frozenAmount = frozenAmount.add(releaseUser.getAmount());
					}
				}
			}
			Map<String, Object> map = Maps.newHashMap();
			BigDecimal userAmount = betAmount.add(frozenAmount).add(user.getAbleAmount());
			user.setAmount(userAmount);
			scUserDao.save(user);
			map.put("amount", userAmount);
			map.put("usedAmount", betAmount.add(frozenAmount));
			map.put("ableAmount", user.getAbleAmount());
			map.put("totalProfit", totalProfit);
			map.put("costAmount", user.getCostAmount());
			return CreateJson.createObjJson(map, true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.nondata.getMessage(), false);
	}

	public ScUser handlerScUser(ScUser user) throws Exception {
		ScUser sc = new ScUser();
		BeanUtils.copyBeanNotNull2Bean(user, sc);
		// 创建环信用户
		try {
			sc = checkEaseUser(sc);
		} catch (Exception e) {
			log.error(e.getMessage());
		} finally {
			// 生成默认头像，并设置头像路径，头像的文件名为用户手机号.jpg(路径为项目的实际部署路径)
			ImgCreate imgCreate = new ImgCreate();
			imgCreate.createImage(sysCfg.getUserfiles_img_url(), "", sc.getMobile());
			// 将当前时间戳加到image的URL中,并保存至redis(以图片名作为key)
			long time = System.currentTimeMillis();
			redisService.hset(DictEnum.redisUserImageTimestamp.value, sc.getMobile(), String.valueOf(time));
			sc.setImage(getUserImagePath(sc.getMobile()));
			sc.setFirstLogin(DictEnum.positive.value);
			sc.setUserName(getUserName(sc));
			String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value, String.valueOf(sc.getUserId()));
			if (StringUtils.isNotBlank(easeUserName)) {
				sc.setEaseName(easeUserName);
				sc.setEasePassword(Des3Encrypt.encode(sc.getMobile()));
			}
		}
		return sc;
	}

	/**
	 * 修改用戶信息
	 * 
	 * @param jsonText
	 * @return
	 * @throws Exception
	 */
	@Transactional
	public String modify(String jsonText, HttpServletRequest request) throws Exception {
		String token = request.getHeader("token");
		ScUser sc = JacksonUtil.jsonToObj(jsonText, ScUser.class);
		if (!checkToken(token, sc.getMobile())) {
			return CreateJson.createTextJson(ReturnMsgEnum.tokenIllegal.getMessage(), false);
		}
		if (StringUtils.isBlank(sc.getUserName())) {
			return CreateJson.createTextJson(ReturnMsgEnum.userNameNull.getMessage(), false);
		}

		if (sc != null && StringUtils.isNotBlank(String.valueOf(sc.getUserId()))) {
			ScUser user = scUserDao.findByUserId(sc.getUserId());
			if (user != null) {
				String userName_old = getUserName(user);
				if (StringUtils.isBlank(userName_old)
						|| (StringUtils.isNotBlank(userName_old) && !userName_old.equals(sc.getUserName()))) {
					// 判断昵称是否重复
					List<ScUser> findByUserName = scUserDao.findByUserName(sc.getUserName());
					if (findByUserName != null && findByUserName.size() > 0) {
						return CreateJson.createTextJson(ReturnMsgEnum.userNameExist.getMessage(), false);
					}
				}
				BeanUtils.copyBeanNotNull2Bean(sc, user);
				user.setUpdateDate(TimeUtil.dateTime2Str(DateTime.now(), TimeUtil.DSPdaytimeFormat));
				if (scUserDao.save(user) != null) {
					// 修改环信昵称
					try {
						String easeUserName = redisService.hget(DictEnum.redisAppEaseUserKey.value,
								String.valueOf(user.getUserId()));
						userApi.modifyNickName(easeUserName, getUserName(user));
					} catch (Exception e) {
						log.error(e.getMessage());
					}
					user.setImage(getUserImagePath(user.getMobile()));
					user.setUserName(getUserName(user));
					return CreateJson.createObjJsonWithToken(createToken(user), user);
				}
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 上传头像
	 * 
	 * @param jsonText
	 * @return
	 * @throws UnknownHostException
	 */
	@Transactional
	public String uploadImg(String jsonText, HttpServletRequest request) throws UnknownHostException {
		String token = request.getHeader("token");
		// 解析json数据
		@SuppressWarnings({ "unchecked", "rawtypes" })
		HashMap<String, String> dataMap = (HashMap) JacksonUtil.jsonToObj(jsonText, Object.class);
		// 得到img的字符串数据
		String imgStr = dataMap.get("img");
		// 得到手机号
		String mobile = dataMap.get("mobile");
		if (StringUtils.isBlank(imgStr) || StringUtils.isBlank(mobile)) {
			return CreateJson.createTextJson(ReturnMsgEnum.paramsNull.getMessage(), false);
		}
		if (!checkToken(token, mobile)) {
			return CreateJson.createTextJson(ReturnMsgEnum.tokenIllegal.getMessage(), false);
		}
		// 检查该手机号用户是否存在
		ScUser scUser = scUserDao.findByMobile(mobile);
		String fileName = mobile + DictEnum.picFormat.value;
		if (scUser != null) {
			// 上传头像
			boolean b = ImgBase64.GenerateImage(imgStr, sysCfg.getUserfiles_img_url(), fileName);
			if (b) {
				// 修改保存在redis中的图片的时间戳
				long time = System.currentTimeMillis();
				redisService.hset(DictEnum.redisUserImageTimestamp.value, scUser.getMobile(), String.valueOf(time));
				scUser.setImage(getUserImagePath(scUser.getMobile()));
				return CreateJson.createObjJsonWithToken(createToken(scUser), scUser);
			}
		}
		return CreateJson.createTextJson(ReturnMsgEnum.operateFail.getMessage(), false);
	}

	/**
	 * 用户登出
	 * 
	 * @param token
	 * @return
	 * @throws UnknownHostException
	 * 
	 */
	@SuppressWarnings("unchecked")
	public String logout(String token, String jsonText) throws UnknownHostException {
		HashMap<String, String> map = JacksonUtil.jsonToObj(jsonText, HashMap.class);
		if (map != null) {
			String userId = map.get("userId");
			redisService.hset("token", userId, "");
			return CreateJson.createTextJson(ReturnMsgEnum.logout.getMessage(), true);
		}
		return CreateJson.createTextJson(ReturnMsgEnum.logoutException.getMessage(), true);
	}

}
