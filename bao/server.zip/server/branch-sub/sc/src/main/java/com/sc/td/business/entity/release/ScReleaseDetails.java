package com.sc.td.business.entity.release;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import com.sc.td.common.persistence.BaseEntity;
import com.sc.td.common.utils.calc.ArithDecimal;

@Entity
@Table
public class ScReleaseDetails extends BaseEntity{

	private int id;
	private int releaseId;
	private String type;
	private String code;
	private String name;
	private String direct;
	private int volume;
	private BigDecimal costPrice;
	private BigDecimal nowPrice;
	private BigDecimal profit;
	private Float profitRate;
	private BigDecimal totalCost;
	private Float costRatio;
	private String closeFlag;
	
	
	public String getCloseFlag() {
		return closeFlag;
	}
	public void setCloseFlag(String closeFlag) {
		this.closeFlag = closeFlag;
	}
	public BigDecimal getTotalCost() {
		return totalCost;
	}
	public void setTotalCost(BigDecimal totalCost) {
		this.totalCost = totalCost;
	}
	public Float getCostRatio() {
		return costRatio;
	}
	public void setCostRatio(Float costRatio) {
		this.costRatio = costRatio;
	}
	@Id
	@GeneratedValue
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}

	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDirect() {
		return direct;
	}
	public void setDirect(String direct) {
		this.direct = direct;
	}
	public int getVolume() {
		return volume;
	}
	public void setVolume(int volume) {
		this.volume = volume;
	}
	public BigDecimal getCostPrice() {
		return new BigDecimal(ArithDecimal.roundByScale(costPrice==null?new BigDecimal(0.00):costPrice, 4));
	}
	public void setCostPrice(BigDecimal costPrice) {
		this.costPrice = costPrice;
	}
	public BigDecimal getNowPrice() {
		return new BigDecimal(ArithDecimal.roundByScale(nowPrice==null?new BigDecimal(0.00):nowPrice, 4));
	}
	public void setNowPrice(BigDecimal nowPrice) {
		this.nowPrice = nowPrice;
	}
	public BigDecimal getProfit() {
		return new BigDecimal(ArithDecimal.roundByScale(profit==null?new BigDecimal(0.00):profit, 4));
	}
	public void setProfit(BigDecimal profit) {
		this.profit = profit;
	}
	public Float getProfitRate() {
		return Float.parseFloat(ArithDecimal.roundByScale(profitRate==null?0.00:profitRate, 4));
	}
	public void setProfitRate(Float profitRate) {
		this.profitRate = profitRate;
	}
}
