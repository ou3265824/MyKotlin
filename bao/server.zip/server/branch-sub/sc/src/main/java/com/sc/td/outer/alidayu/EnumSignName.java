package com.sc.td.outer.alidayu;

public enum EnumSignName {
	
	appName("干货部落");
	
	private EnumSignName(String name){
		this.name=name;
	}

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return this.name;
	}
}
