package com.sc.td.business.entity.tribe.dto;

import com.sc.td.common.utils.datetime.TimeUtil;

public class TribeUserDto implements Comparable<TribeUserDto>{

	private int userId;
	private String userName; // 用户名
	private String image;//头像
	private boolean isAdmin;//是否是部落超级管理员
	private boolean isManager;//是否是部落管理员
	private String joinTime;//加入部落的时间
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	public boolean isAdmin() {
		return isAdmin;
	}

	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}

	public boolean isManager() {
		return isManager;
	}

	public void setManager(boolean isManager) {
		this.isManager = isManager;
	}

	public String getJoinTime() {
		return joinTime;
	}

	public void setJoinTime(String joinTime) {
		this.joinTime = joinTime;
	}

	@Override
	public int compareTo(TribeUserDto o) {
		if(this.isAdmin || (this.isManager && !o.isAdmin)){
			return -1;
		}else{
			if(TimeUtil.compare(TimeUtil.str2DateTime(this.joinTime, TimeUtil.DSPdaytimeFormat), TimeUtil.str2DateTime(o.joinTime, TimeUtil.DSPdaytimeFormat))>0){
				return 1;
			}
		}
		return -1;
	}

}
