package com.sc.td.business.entity.weibo;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import org.apache.commons.lang3.StringUtils;

@Table
@Entity
public class ScWeibo {

	private int id;				//主键Id
	private int userId;			//用户Id
	private int tribeId;		//部落Id
	private String content;		//内容
	private String img;		//图片名称（多个以“,”分割）
	private String type;		//类型（0原创1转发2评论）
	private Timestamp createTime;	//发布时间
	private int nanosecond;			//毫微秒
	private String delFlag;			//删除标记（0正常1删除）
	private String likeCount;		//点赞数
	private String commentCount;	//评论数
	private String storeCount;		//收藏数
	private String thumbImg;		//缩略图
	private String userName;		//发布人名称
	private String userImg;			//发布人头像
	private String tribeName;		//部落名称
	private boolean isLike;			//当前用户是否点赞
	private boolean isStore;		//当前用户是否收藏
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public int getTribeId() {
		return tribeId;
	}
	public void setTribeId(int tribeId) {
		this.tribeId = tribeId;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Timestamp getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}
	@Transient
	public int getNanosecond() {
		return nanosecond;
	}
	public void setNanosecond(int nanosecond) {
		this.nanosecond = nanosecond;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	@Transient
	public String getLikeCount() {
		return StringUtils.isBlank(likeCount)?"0":likeCount;
	}
	public void setLikeCount(String likeCount) {
		this.likeCount = likeCount;
	}
	@Transient
	public String getCommentCount() {
		return StringUtils.isBlank(commentCount)?"0":commentCount;
	}
	public void setCommentCount(String commentCount) {
		this.commentCount = commentCount;
	}
	@Transient
	public String getStoreCount() {
		return StringUtils.isBlank(storeCount)?"0":storeCount;
	}
	public void setStoreCount(String storeCount) {
		this.storeCount = storeCount;
	}
	@Transient
	public String getThumbImg() {
		return thumbImg;
	}
	public void setThumbImg(String thumbImg) {
		this.thumbImg = thumbImg;
	}
	@Transient
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Transient
	public String getUserImg() {
		return userImg;
	}
	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}
	@Transient
	public String getTribeName() {
		return tribeName;
	}
	public void setTribeName(String tribeName) {
		this.tribeName = tribeName;
	}
	@Transient
	public boolean isLike() {
		return isLike;
	}
	public void setLike(boolean isLike) {
		this.isLike = isLike;
	}
	@Transient
	public boolean isStore() {
		return isStore;
	}
	public void setStore(boolean isStore) {
		this.isStore = isStore;
	}
	
}
