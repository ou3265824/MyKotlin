package com.sc.td.common.config;

public enum DictEnum {
	
	admin("超级管理员","admin"),
	manager("管理员","manager"),
	del("数据逻辑删除","1"),
	not_del("数据正常","0"),
	apply("申请中","0"),
	audit_pass("审核通过","1"),
	audit_refuse("审核拒绝","2"),
	ignore("忽略","1"),
	not_ignore("不忽略","0"),
	free("免费","0"),
	charge("收费","1"),
	ispublic("公开","0"),
	isprivate("不公开","1"),
	moren("默认","D"),
	ing("进行中","I"),
	end("结束","E"),
	all("所有","A"),
	positive("是","T"),
	negative("否","F"),
	secret("保密","0"),
	male("男","1"),
	female("女","2"),
	picFormat("JPG格式",".jpg"),
	thumb_prevfix("缩略图格式","thumb_"),
	thumb_w("缩略图宽","152"),
	thumb_h("缩略图高","152"),
	my("我的","0"),
	success("成功","success"),
	join("加入","join"),
	quit("退出","quit"),
	open("开启","0"),
	close("关闭","1"),
	buy("买","1"),
	sell("卖","2"),
	enable("可用","0"),
	disable("不可用","1"),
	lock("锁定","1"),
	notLock("解锁","0"),
	temp("临时","temp"),
	releaseProfitRatio("策略收益分配系数","0.8"),
	releaseRewardRatio("策略收益奖励系数","0.1"),
	releaseManagerRatio("策略管理费系数","0.1"),
	redis_market_prefix("REDIS内存储的行情基本数据的前缀","market_!@#sc"),
	redisUserImageTimestamp("Redis内用户头像时间戳","userImage-timestamp"),
	redisExampleGroupImageKey("Redis内示例圈子头像名","example-group-image"),
	redisGroupImageTimestampKey("Redis内圈子头像时间戳","groupImage-timestamp"),
	redisTribeImageTimestampKey("Redis内部落头像时间戳","tribeImage-timestamp"),
	redisExampleGroupImageTimestampKey("Redis内示例圈子头像时间戳","example-groupImage-timestamp"),
	redisAppEaseUserKey("Redis内APP与环信的用户映射","app-ease-user"),
	redisAppEaseGroupKey("Redis内APP与环信的群组映射","app-ease-group"),
	redisEaseAppUserKey("Redis内环信与APP的用户映射","ease-app-user"),
	redisEaseAppGroupKey("Redis内环信与APP的群组映射","ease-app-group"),
	redisRegisterExceptionKey("创建环信用户异常","register-ease-exception"),
	redisCreateExceptionKey("创建环信群组异常","create-group-exception"),
	redisJoinExceptionKey("加入环信群组异常","join-group-exception"),
	redisQuitExceptionKey("退出环信群组异常","quit-group-exception"),
	redisJoinGroupCodePrefix("邀请码-圈子ID","joinGroup-:code-groupId-"),
	redisJoinGroupIdPrefix("圈子ID-邀请码","joinGroup-:groupId-code-"),
	redisJoinTribeCodePrefix("邀请码-部落ID","joinTribe-:code-tribeId-"),
	redisJoinTribeIdPrefix("部落ID-邀请码","joinTribe-:tribeId-code-"),
	redisWeiboLikeCountKey("微博点赞数","weibo-like-count"),
	redisWeiboCommentCountKey("微博转发数","weibo-comment-count"),
	redisWeiboStoreCountKey("微博收藏数","weibo-store-count");
	
	public String desc;
	public String value;
	
	private DictEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	
	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
	
	public static void main(String[] args) {
		System.out.println(DictEnum.del.value);
	}
}
