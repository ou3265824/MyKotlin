package com.sc.td.business.dao.release;

import java.util.List;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.release.ScReleaseDetails;

public interface ScReleaseDetailsDao extends BaseDao<ScReleaseDetails> {

	Long countByReleaseIdAndCloseFlag(int releaseId,String closeFlag);
	
	List<ScReleaseDetails> findByReleaseId(int releaseId);
	
	ScReleaseDetails findById(int id);
}
