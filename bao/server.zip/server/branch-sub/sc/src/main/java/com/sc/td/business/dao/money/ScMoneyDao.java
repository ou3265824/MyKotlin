package com.sc.td.business.dao.money;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.dao.SpecificationDao;
import com.sc.td.business.entity.money.ScMoney;

public interface ScMoneyDao extends BaseDao<ScMoney>,SpecificationDao<ScMoney> {

}
