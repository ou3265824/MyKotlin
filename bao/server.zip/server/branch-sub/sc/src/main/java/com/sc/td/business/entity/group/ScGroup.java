package com.sc.td.business.entity.group;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.sc.td.common.config.DictEnum;
import com.sc.td.common.persistence.BaseEntity;

@Table
@Entity
public class ScGroup extends BaseEntity implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int groupId;
	private String groupName;
	private int userId;
	private String intro;
	private String joinType;
	private Double joinFee;
	private String groupImg;
	private Long peopleCount;
	private Long releaseCount;
	private String userName;
	private Boolean isJoin;
	private String userImg;
	private String easeGroupId;
	private String delFlag;
	private String releaseLimit;
	
	@Transient
	public String getReleaseLimit() {
		return releaseLimit;
	}
	public void setReleaseLimit(String releaseLimit) {
		this.releaseLimit = releaseLimit;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	@Transient
	public String getEaseGroupId() {
		return easeGroupId;
	}
	public void setEaseGroupId(String easeGroupId) {
		this.easeGroupId = easeGroupId;
	}
	@Transient
	public String getUserImg() {
		return userImg;
	}
	public void setUserImg(String userImg) {
		this.userImg = userImg;
	}
	@Transient
	public Boolean getIsJoin() {
		return isJoin;
	}
	public void setIsJoin(Boolean isJoin) {
		this.isJoin = isJoin;
	}
	@Transient
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	@Transient
	public Long getPeopleCount() {
		return peopleCount;
	}
	public void setPeopleCount(Long peopleCount) {
		this.peopleCount = peopleCount;
	}
	@Transient
	public Long getReleaseCount() {
		return releaseCount;
	}
	public void setReleaseCount(Long releaseCount) {
		this.releaseCount = releaseCount;
	}
	@Transient
	public String getGroupImg() {
		return groupImg;
	}
	public void setGroupImg(String groupImg) {
		this.groupImg = groupImg;
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	public int getGroupId() {
		return groupId;
	}
	public void setGroupId(int groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getJoinType() {
		return joinType;
	}
	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}
	public Double getJoinFee() {
		return joinFee;
	}
	public void setJoinFee(Double joinFee) {
		this.joinFee = joinFee;
	}
	
	@Override
	public String toString() {
		return "ScGroup [groupId=" + groupId + ", groupName=" + groupName + ", userId=" + userId + ", intro=" + intro
				+ ", joinType=" + joinType + ", joinFee=" + joinFee + ", groupImg=" + groupImg + ", peopleCount="
				+ peopleCount + ", releaseCount=" + releaseCount + ", userName=" + userName + ", isJoin=" + isJoin
				+ ", userImg=" + userImg + ", easeGroupId=" + easeGroupId + ", delFlag=" + delFlag + "]";
	}
	public void setInitValue(BaseEntity t, String userId) {
		super.setInitValue(t, userId);
		this.setDelFlag(DictEnum.not_del.value);
	}
}
