package com.sc.td.business.dao.notify;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.notify.ScNotify;

public interface ScNotifyDao extends BaseDao<ScNotify> {

}
