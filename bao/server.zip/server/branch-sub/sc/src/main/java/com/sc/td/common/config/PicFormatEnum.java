package com.sc.td.common.config;

public enum PicFormatEnum {

	BMP,JPG,JPEG,PNG,GIF
}
