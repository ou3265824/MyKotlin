package com.sc.td.business.dao;

import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;

public interface SpecificationDao<T> {
	//分页查询
	Page<T> findAll(Specification<T> specification,Pageable pageable);
	//不分页查询
	Set<T> findAll(Specification<T> specification);
}
