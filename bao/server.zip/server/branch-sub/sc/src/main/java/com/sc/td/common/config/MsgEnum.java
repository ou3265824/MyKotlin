package com.sc.td.common.config;

public enum MsgEnum {

	sys("系统消息","1"),
	group_check("圈子验证消息","2"),
	tribe_check("部落验证消息","3"),
	draft("草稿","0"),
	publish("发布","1"),
	read("已读","1"),
	not_read("未读","0");
	
	public String desc;
	public String value;
	
	private MsgEnum(String desc,String value){
		this.desc=desc;
		this.value=value;
	}

	@Override
	public String toString() {
		return this.desc + "_" + this.value;
	}
}
