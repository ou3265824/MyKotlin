package com.sc.td.business.task;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Controller;
import com.sc.td.business.service.BusinessTaskService;
import com.sc.td.easemob.exception.EasemobException;


/**
 * 定時任務,加载基本信息
 * 
 * @author Administrator
 *
 */
@Controller
public class BusinessTask {
	
	@Autowired
	private BusinessTaskService taskService;
	
	@Scheduled(initialDelay=1000*5,fixedRate=1000*60*5)
	public void unifyApp2Ease() throws EasemobException{
		taskService.unifyApp2Ease();
	}
}
