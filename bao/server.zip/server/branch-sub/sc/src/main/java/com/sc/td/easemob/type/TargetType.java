package com.sc.td.easemob.type;

/**
 * 目标类型
 * 
 * @className TargetType
 * @author jinyu(foxinmy@gmail.com)
 * @date 2015年3月18日
 * @since JDK 1.6
 * @see
 */
public enum TargetType {
	users, // 发给用户
	chatgroups; // 发给群组
}
