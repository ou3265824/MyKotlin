package com.sc.td.business.entity.release.dto;

import java.math.BigDecimal;

public class ReleaseUserDto {

	private int releaseId;
	private int userId;
	private String userName;
	private String realName;
	private String mobile;
	private BigDecimal amount;
	private BigDecimal ableAmount;
	public BigDecimal getAbleAmount() {
		return ableAmount;
	}
	public void setAbleAmount(BigDecimal ableAmount) {
		this.ableAmount = ableAmount;
	}
	public int getReleaseId() {
		return releaseId;
	}
	public void setReleaseId(int releaseId) {
		this.releaseId = releaseId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getRealName() {
		return realName;
	}
	public void setRealName(String realName) {
		this.realName = realName;
	}
	
}
