package com.sc.td.business.dao.release;

import java.math.BigDecimal;
import java.util.List;
import java.util.Set;

import org.springframework.data.jpa.repository.Query;

import com.sc.td.business.base.BaseDao;
import com.sc.td.business.entity.release.ScReleaseUser;

public interface ScReleaseUserDao extends BaseDao<ScReleaseUser> {

	List<ScReleaseUser> findByUserIdAndDelFlagAndStatusNot(int userId,String delFlag,String status);
	
	List<ScReleaseUser> findByUserIdAndGroupIdAndDelFlagAndStatusNot(int userId,int groupId,String delFlag,String status);
	
	Long countByReleaseIdAndUserIdAndGroupIdAndDelFlagAndAmountGreaterThan(int releaseId,int userId,int groupId,String delFlag,BigDecimal amount);
	
	Set<ScReleaseUser> findByUserIdAndGroupIdAndDelFlag(int userId,int groupId,String delFlag);
	
	Set<ScReleaseUser> findByUserIdAndDelFlagAndStatus(int userId,String delFlag,String status);
	
	ScReleaseUser findByUserIdAndReleaseIdAndDelFlag(int userId,int releaseId,String delFlag);
	
	List<ScReleaseUser> findByReleaseIdAndDelFlag(int releaseId,String delFlag);
	
	@Query(value="select count(t1.release_id) from sc_release_user t1 join sc_release t2 on t1.release_id=t2.release_id "
			+" join sc_user t3 on t1.user_id=t3.user_id where t1.release_id=?1 and t3.able_amount<0 ",nativeQuery=true)
	Long countByReleaseIdAndUserAbleAmountLessZero(int releaseId);
}
